###
### itkasm misc subroutines
###
### Licensed under GNU General Public License v2 - See EOF
###

#=====================================================
###
### Footer Sig at the bottom over every page
### 
sub footer_sig
{
  if ( ! $META ) 
  {
    print qq~
      $hr_line 
      <table width=100%><td align=left><font $fsn>IT KASM &copy 2007-2018 All Rights Reserved. Version:$VERSION</font></td>
        <td align=center valign=bottom><font size=3><img src=$IMAGES/itkasmATmail_com.png height=12></td>
      <td align=right><font $fsn>Licensed under <a href="https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html" target=gnu class="hoverlink"> GNU General Public License v2</font></td>
    ~;
  }
}

###
### GET HELP
###
sub get_help
{
  if ( $form{act} eq "modset" && $form{sact} eq "attention" ) { $HLP="Attention Banner"; $HLPDESC="Setting the Attention Banner";}
  if ( $form{wp} eq "SETTINGS-MAIN" ) { $HLP="settings"; $HLPDESC="Settings";}
  if ( ($form{act} eq "modset" && $form{sact} =~ "asm\." ) || $form{wp} eq "SETTINGS-ASM" ) { $HLP="asset settings"; $HLPDESC="Asset Management Settings";}
  if ( $form{act} eq "modset" && ( $form{sact} eq "bcklists" || $form{sact} eq "retlists") ) { $HLP="checklist settings"; $HLPDESC="Checklist Settings";}
  if ( $form{act} eq "settings" && $form{sact} eq "users" ) { $HLP="settings users"; $HLPDESC="User Settings";}
  if ( $form{act} eq "groups" ) { $HLP="settings users"; $HLPDESC="User Settings";}
  if ( $form{act} eq "sysconfigs" ) { $HLP="settings configurations"; $HLPDESC="IT KASM Configuration Settings";}
  if ( $form{act} eq "sysconfigs" ) { $HLP="settings configurations"; $HLPDESC="IT KASM Configuration Settings";}
  if ( $form{act} eq "catlog" ) { $HLP="settings logs"; $HLPDESC="Logs";}
  if ( $form{act} eq "listfree" ) { $HLP="mine freeform"; $HLPDESC="Freeform Mine";}
  if ( $form{act} eq "listoc" ) { $HLP="mine on-call"; $HLPDESC="On-Call Mine";}
  if ( $form{act} eq "listres" ) { $HLP="mine resource"; $HLPDESC="Resource Mine";}
  if ( $form{act} eq "listsearch" ) { $HLP="mine search"; $HLPDESC="Search Mine";}
  if ( $form{act} eq "listtsk" ) { $HLP="mine task"; $HLPDESC="Task Mine";}
  if ( $form{act} eq "listtrk" ) { $HLP="mine tracker"; $HLPDESC="Tracker Mine";}
  if ( $form{act} eq "listkaves" ) { $HLP="kave settings"; $HLPDESC="Kave Settings";}
  if ( $form{act} eq "ckave" ) { $HLP="kave"; $HLPDESC="Create Various Kaves";}
  if ( $form{act} eq "listpages" ) { $HLP="settings list pages"; $HLPDESC="List Pages";}
  if ( $form{act} eq "ckpage" ) { $HLP="settings create pages"; $HLPDESC="Create/Edit Pages";}
}

###
### WRITE LAST ACCESS
###
sub last_access
{
  if ( $WHOAMI) 
  {
    if ( -d "$USERDIR/$WHOAMI" )
    {
      open(OUT, ">$USERDIR/$WHOAMI/lastaccess") || print "Cannot write to Last Access file: $USERDIR/$WHOAMI/lastaccess";
      print OUT "$TDATE\t${whereami}?${buffer}\n";
      close(OUT);  
    }
    else 
    {
      $message="[${WHOAMI}] ITKASM-Last_Access: Error - could write last access"; &write_log;
    }
  }
}

###
### GET MINE PROFILE DATA
### Need to pass mineid and MINEDIR
### minetype ("asm","freeform","knowledgebase","oncall","resource","search","task","tracker")
###
sub get_mine_profile
{
  
  if ( -f "$DPATH/$minetype/$mineid/${mineid}.pro" )
  {
    open(MNPRO, "$DPATH/$minetype/$mineid/${mineid}.pro" ) || print "CANNOT READ KAVE PROFILE $DPATH/$minetype/$mineid/${mineid}.pro";
    while(<MNPRO>)
    {
      chomp;
      if (/^name\t/ ) { ($d, $minename) = split(/\t/, $_); }
      if (/^desc\t/ ) { ($d, $minedesc) = split(/\t/, $_); }
    }
   close(MNPRO);
  }
  else 
  {
      $ERRORLOG="Mine $mineid profile not available."; 
  }
}


###
### GET KAVE PROFILE
###      ERRORLOG is returned if there are any issues
###
sub get_kave_profile
{
  @fields=(); @OCWHO=();
  if ( -f "$KAVES/${kaveid}.pro" )
  {
    open(KVPRO, "$KAVES/${kaveid}.pro" ) || print "CANNOT READ KAVE PROFILE $KAVES/${kaveid}.pro";
    while(<KVPRO>)
    {
      chomp;
      if (/^kavename\t/ ) { ($d, $kavename) = split(/\t/, $_); }
      if (/^kavedesc\t/ ) { ($d, $kavedesc) = split(/\t/, $_); }
      if (/^ktype\t/ ) { ($d, $ktype) = split(/\t/, $_); }
      if (/^ktypeid\t/ ) { ($d, $ktypeid) = split(/\t/, $_); }
      if (/^kave\t/ ) { ($d, $kave) = split(/\t/, $_); }
      if (/^kgroup\t/ ) { ($d, $kgroup) = split(/\t/, $_); }
      if (/^ktag\t/ ) { ($d, $ktag) = split(/\t/, $_); }
      if (/^kwho\t/ ) { ($d, $kwho) = split(/\t/, $_); }
      if (/^knrec\t/ ) { ($d, $knrec) = split(/\t/, $_); }
      if (/^kdispnam\t/ ) { ($d, $kdispnam) = split(/\t/, $_); }
      if (/^kstag\t/ ) { ($d, $kstag) = split(/\t/, $_); }
      if (/^trckpat\t/ ) { ($d, $trckpat) = split(/\t/, $_); }
      if (/^kbdisp\t/ ) { ($d, $kbdisp) = split(/\t/, $_); }
      if (/^vdrdisp\t/ ) { ($d, $vdrdisp) = split(/\t/, $_); }
      if (/^vdrsrch\t/ ) { ($d, $vdrsrch) = split(/\t/, $_); }
      if (/^ocdisp\t/ ) { ($d, $ocdisp) = split(/\t/, $_); }
      if (/^octiming\t/ ) { ($d, $octiming) = split(/\t/, $_); }
      if (/^ocdates\t/ ) { ($d, $ocdates) = split(/\t/, $_); }
      if (/^field\t/ ) { ($d, $field) = split(/\t/, $_); push (@fields, $field); }
      if (/^ocwho\t/ ) { ($d, $ocwho) = split(/\t/, $_); push (@OCWHO, $ocwho); }
    }
    close(KVPRO);
  }
  else 
  {
      $ERRORLOG="Kave profile not available."; 
  }


}

###
### GET PAGE PROFILE
### PASS $pageid 
###
sub get_page_profile
{
  open(PGPRO, "$KPGDIR/$pageid/${pageid}.pro" ) || print "CANNOT READ PAGE PROFILE $KPDIR/$pageid/${pageid}.pro";
  while(<PGPRO>)
  {
    chomp;
    if (/^name\t/ ) { ($d, $pgname) = split(/\t/, $_); }
    if (/^desc\t/ ) { ($d, $pgdesc) = split(/\t/, $_); }
    if (/^layout\t/ ) { ($d, $pglayout) = split(/\t/, $_); }
    if (/^active\t/ ) { ($d, $pgactive) = split(/\t/, $_); }
  }
  close(PGPRO);
}



####
#### WRITE TO Operations Activity LOG
####
sub write_opsact
{
      open(OCNT, "$OANUM") || print "ERROR: Cannot read OANUM $OANUM";
      while(<OCNT>) { chomp; if ( "$_" ) { $orecnum="$_"; } }
      close(OCNT);
      open(OPRO, "$OAPRO") || print "ERROR: Cannot read OAPRO $OAPRO";
      while(<OPRO>) { chomp; if ( /^recname\t/ ) { ($d, $orecname) = split(/\t/, $_);  } }
      close(OPRO);
      $orecnum++;
      $onewnum="${orecname}${orecnum}";
      open(CNT, "> $OANUM") || print "ERROR: Cannot write OANUM $OANUM";
       print CNT "$orecnum";
      close(CNT);

      open(LOGIT, ">> $OAFILE" ) || print "CANNOT WRITE OpsActivity: $OAFILE";
      print LOGIT "$onewnum\t$TDATE\t$WHOAMI\t$identity\t$message\n";
      close(LOGIT);
}

###
### WRITE TO GLOBAL IT IT KASM LOG
###
sub write_log
{
    $TIMESTAMP="$TDATE"; 
    $TIMESTAMP =~ tr /T/ /;
    ($MOYRDY, $d) = split(/ /, $TIMESTAMP);
    ($yy, $mm, $dd) = split(/-/, $MOYRDY);
    $MOYRDY="$yy$mm$dd";

    if ( ! -d "$LOGDIR" ) { `mkdir -p $LOGDIR`; }
    open(LOGIT, ">> $LOGDIR/itkasm-${MOYRDY}" ) || print "CANNOT WRITE: $LOGDIR/itkasm.${MOYRDY}";
    print LOGIT "$TIMESTAMP\t$message\n";
    close(LOGIT);
}


###
### WRITE TO ASSET MGR PROFILE LOG
###
sub write_lifecycle
{
   if ( -d "$DEVICES/$device/life.log" ) 
   {
      $MOYR=`date +%y%m`; chomp($MOYR);
      $TIMESTAMP=`date "+%x - %X"`; chomp($TIMESTAMP);
      open(LOGIT, ">> $DEVICES/$device/life.log" )|| print "can't write $DEVICES/$device/life.log";
      print LOGIT "$TIMESTAMP $life\n";
      close(LOGIT);
   }
}


###
###
### WRITE TO PERSONAL JOURNAL
###
sub write_journal
{
    $JRDIR="$USERDIR/$WHOAMI/journal";
    if ( ! -d "$JRDIR" ) { `mkdir -p $JRDIR`; }

    open(JRIT, ">> $JRDIR/$DT");
    print JRIT "$TDATE\t$journal\n";
    close(JRIT);
}


###
### Attention Line
###
sub get_attentionline
{
  $lines=0;
  open(ATT, "$ATTENTION" ); 
  $lines++ while (<ATT>) ;
  close(ATT);
  $rnum = int(rand($lines))+1;  
  if ( $rnum eq 0 ) { $rnum=1; }

  open(ATT, "$ATTENTION" );
  while(<ATT>)
  {
    next unless $. == $rnum;
      $ATTLINE="$_";
    last;
  }
  close(ATT);
}




###
###  Logout of the itkasm
###
sub kill_cookie
{

        $query = new CGI;
        $cookie = $query->cookie(-name=>'ITKASM',
                         -value=>"",
                         -expires=>'now',
                         -path=>'/');

        print $query->header(-cookie=>$cookie);
        print " <META HTTP-EQUIV=\"Refresh\" CONTENT=\"0;URL=$PROG\">";
        exit;
}



sub get_token
{
        my $length_of_randomstring=shift;# the length of
                         # the random string to generate

        my @chars=('a'..'z','A'..'Z','0'..'9');
        my $random_string;
        foreach (1..$length_of_randomstring)
        {
                # rand @chars will generate a random
                # number between 0 and scalar @chars
                $random_string.=$chars[rand @chars];
        }
        return $random_string;
}

###
### CONVERT USER ID TO REAL NAME
###
### PASS $userID and returns $ulname and $ufname
###
sub convert_user
{
  $ufname=""; $ulname=""; $found1="";
  # FIRST CHECK THE USER PASSWORD FILE
  open(USR, "$USERS") || print "Cannot find $USERS";
  while (<USR>)
  {
    chomp;
    if ( /^$userID\t/ )
    { ($UUID, $UPWD, $ufname, $ulname) = split (/\t/, $_); $found1="1";}
  }
  close(USR);
  # IF NOT IN THE PASSWORD FILE, CHECK THE USER PROFILES
  if ( ! $UUID ) 
  {
    if ( -f "$USERDIR/$userID/profile" )
    {
      open (PROF, "$USERDIR/$userID/profile");
      while (<PROF>)
      { chomp; ($UUID, $UPWD, $ufname, $ulname) = split (/\t/, $_); }
      close(PROF);
    }
  }
  if ( ! $found1 ) 
  { 
    if ( $mail_prog )
    {
      open (MAIL, "|$mail_prog -s \"IT KASM: ERROR $userID does not exist or corrupted\" $itkasmadmin") || die "Could not open $mail_prog";
      print MAIL "From: IT KASM\n";
      print MAIL "ERROR: $userID does not exist or corrupted in IT KASM password file\n";
      print MAIL "\n";
      print MAIL "To fix any issues, run the following: /opt/itkasm/bin/rebuild_user_profiles\n";
      close(MAIL);
    }
  }
}


###
### Process the freeform input
### This should be the default for all freeforms
###
sub freeform_process
{
#print "$FreeFormFile";
  @FFORM=();
  open (FFF, $FreeFormFile) || print "CANNOT OPEN $FreeFormFile";
  while (<FFF>)
  {
        $_ =~ s/\r//g;
        #$_ =~ s/\{/\</g;
        #$_ =~ s/\}/\>/g;
        #$_ =~ s/\:/\=/g;
        push (@FFORM, $_);
  }
  close(FFF);
}


###
### Display Denial of access
### Pass the $accessTYPE and $accessID
sub access_denied
{
  print qq~
	<p><font $fsberr>Acccess is denied. <i>A security event has been recorded.</i><p>
	If you feel this is an error, contact the IT KASM Administrator with<br> 
	<ul><b>Access Denied - Error Code:</b> ${accessTYPE}-$accessID </ul>
  ~;
  if ( ! $WHOAMI ) { $WHOAMI = "UNKNOWN" } 
  if ( -f "$DPATH/$accessTYPE/$accessID/${accessID}.pro" ) 
  { 
    open(PRO, "$DPATH/$accessTYPE/$accessID/${accessID}.pro");
    while (<PRO>)
    { 
	chomp; 
	if ( /^name\t/ ) { ($dd, $mineNAME) = split(/\t/, $_); } 
    }
    close(PRO);
    if ( $mineNAME ) { $mineNAME=" on $mineNAME"; }
  }
  $message="[${WHOAMI}]\tIT KASM ACCESS DENIED : $accessTYPE Mine\tACCESS ATTEMPT $mineNAME at $accessID"; &write_log;
  exit;
}


###
### DETERMINE THE ACCESS LEVEL AND 
### BY PASSING $WHOAMI, $accessTYPE, $accessID 
### RETURNS $ACCESSLEVEL (DENY,RW,RO) FOR THE MINE OR AREA
###
### IF ON A SETTING PAGE, ONLY ADMIN HAS ACCESS!
###
sub determine_access
{
  #
  # Get all the groups with access
  #
  @grplist=();
  if ( $accessTYPE eq "assets" ) { $accessTYPE="asm"; $accessID="default"}
  if ( $NOTWHOAMI ) { $USERID="$NOTWHOAMI"; }
  else { $USERID="$WHOAMI"; } 
  if ( ! $WHOAMI ) { $USERID="XXXXXXXXXX";}
  if ( -d "$DPATH/$accessTYPE/$accessID/access")
  {
##print "$DPATH/$accessTYPE/$accessID/access<br> ";
    opendir(DIR, "$DPATH/$accessTYPE/$accessID/access") or die $!;
    while ($gfile = readdir(DIR))
    { 
	next if ($gfile =~ m/^\./); 
	($gtype, $gid, $gaccess) = split(/-/, $gfile);
	if ( $gtype eq "GROUP" ) { push (@grplist, "$gaccess\t$gid"); }
    }
    closedir(DIR);
    @grplist = sort @grplist;
  }

  # 
  # Check if an ADMIN, If so go no further
  #
  if ( -f "$USERDIR/$USERID/ADMIN" || $USERID eq "admin" ) { $DEBUG="ADMIN"; $ACCESSLEVEL="admin"; }
  else
  {
    #
    # Check initial mine access first
    #
    if ( -f "$DPATH/$accessTYPE/$accessID/access/DEFAULT-ro" ) { $ACCESSLEVEL="ro"; $DEBUG="Default-ro";}
    elsif ( -f "$DPATH/$accessTYPE/$accessID/access/DEFAULT-rw" ) { $ACCESSLEVEL="rw"; $DEBUG="Default-rw"; }
    elsif ( -f "$DPATH/$accessTYPE/$accessID/access/DEFAULT-deny" ) { $ACCESSLEVEL="deny"; $DEBUG="Default-deny";}
    else { $ACCESSLEVEL="deny"; $DEBUG="NOTHING-Default-deny";}
    #
    # Is the user in any groups, if get access level
    #
    if ( @grplist ) 
    {
      foreach $group (@grplist)
      {
        ($gaccess, $gid) = split(/\t/, $group);
     	open(GRP, "$GRPDIR/$gid");
        while (<GRP>)
  	{
          if ( /$USERID\t/ )  {$ACCESSLEVEL="$gaccess"; $DEBUG="$gaccess"; } 
 	}
	close(GRP);
      }
    }

    #
    # Finally Check User access, if exists override all other access
    #
    if ( -f "$DPATH/$accessTYPE/$accessID/access/USER-${USERID}-ro" ) {  $DEBUG="User-ro"; $ACCESSLEVEL="ro";}
    elsif ( -f "$DPATH/$accessTYPE/$accessID/access/USER-${USERID}-rw" ) {  $DEBUG="User-rw"; $ACCESSLEVEL="rw";}
    elsif ( -f "$DPATH/$accessTYPE/$accessID/access/USER-${USERID}-deny" ) {  $DEBUG="user-deny"; $ACCESSLEVEL="deny";}
  }
#$ttt=`ls $DPATH/$accessTYPE/$accessID/access/`; print "**** access=$ACCESSLEVEL / $accessTYPE / $accessID / file=$ttt / @grplist<br>";
#print "**** access=$ACCESSLEVEL / $USERID /$accessTYPE / $accessID / @grplist<br>";
}


###
### DISPLAY MINE ACCESS
###
sub display_mineaccess
{
   if ( ! -d "$MINEDIR/access" ) { `mkdir -p $MINEDIR/access`; `touch "$MINEDIR/access/DEFAULT-ro"`;}
   @acclist=();
   opendir(DIR, "$MINEDIR/access") or die $!;
   while ($ugfile = readdir(DIR))
   { 
	next if ($ugfile =~ m/^\./); 
	($ugtype, $ugid, $ugaccess) = split(/-/, $ugfile);
        if ( $ugtype eq "USER" ) { $userID="$ugid"; &convert_user; $ugid="$ulname, $ufname"; }
	if ( $ugtype eq "DEFAULT" ) { push (@acclist, "$ugtype\t\t$ugid"); }
        else { push (@acclist, "$ugtype\t$ugid\t$ugaccess"); }
   }
   closedir(DIR);
   @acclist = sort @acclist;
  print "<table border=0 cellpadding=3>\n";
  $prevType=""; $COUNT=0;
  foreach (@acclist)
  {
    ($ugtype,$ugid,$ugaccess) = split(/\t/,$_);
    chomp($ugaccess);
    if ( "$ugaccess" eq "ro" ) { $ugaccess="Read Only"; }
    if ( "$ugaccess" eq "rw" ) { $ugaccess="Read/Write"; }
    if ( "$ugaccess" eq "deny" ) { $ugaccess="DENY"; }
    if ( $prevType ne $ugtype) 
    { 
        if (  "$ugtype" eq "DEFAULT" ) { $new_ugaccess="$ugaccess"; }
        else { $new_ugaccess="$hr_line"; }
	$prevType="$ugtype";
        if ( $COUNT > 0 ) { $br="<br>";}
        else { $br=""; }
   	print "<tr><td valign=top colspan=2 align=center>${br}<font $fsn><b>$ugtype Access:</b><br>$new_ugaccess</font></td></tr>\n";
	$COUNT++;
    }
      if ( $ugtype ne "DEFAULT") {print "<tr><td><font $fsn>$ugid</font></td><td><font $fsn>${ugaccess}</font></td>\n"; }
  }   
  print "</table>";
}


###
### SET ACCESS CONTROLS USER AND GROUPS FOR MINES IN PERSPECTIVE DATA DIRS
###
sub mine_access
{
#print "$buffer";
   if ( ! -d "$MINEDIR/access" ) { `mkdir -p $MINEDIR/access`; `touch "$MINEDIR/access/DEFAULT-ro"`;}
  #
  # MAKE CHANGES/DELETE TO GROUP/USER IF IT WAS SELECTED
  #
  # Add user access
  if ( $form{selusr} ) { $file="$MINEDIR/access/USER-$form{selusr}-ro"; `touch $file`; `chmod 600 $file`;}
  # Add group access
  if ( $form{selgrp} ) { $file="$MINEDIR/access/GROUP-$form{selgrp}-ro"; `touch $file`; `chmod 600 $file`; } 
  # Remove Access
  if ( $form{del} ) { `rm $MINEDIR/access/$form{ug}-$form{ugid}-$form{pv}`;} 
  # Change access leveL
  if ( $form{nl} ) 
  { 
	`rm $MINEDIR/access/$form{ug}-$form{ugid}-$form{pv}`; 
	`touch $MINEDIR/access/$form{ug}-$form{ugid}-$form{nl}`;
        `chmod 600 $MINEDIR/access/$form{ug}-$form{ugid}-$form{nl}`;
  }
  if ( $form{ndl} ) 
  { 
	`rm $MINEDIR/access/DEFAULT-$form{pv}`; 
	`touch $MINEDIR/access/DEFAULT-$form{ndl}`;
        `chmod 600 $MINEDIR/access/DEFAULT-$form{ndl}`;
  }

  # COLLECT THE LIST OF FILES IN ACCESS DIR
   @files=();
   opendir(DIR, "$MINEDIR/access") or die $!;
   while ($ugfile = readdir(DIR))
   { next if ($ugfile =~ m/^\./); push(@files, "$ugfile");  }
   closedir(DIR);
  # COLLECT THE GROUPS
   @grplist=();
   if ( -d "$GRPDIR" )
   {
     opendir(GRP, "$GRPDIR") or die $!;
     while ($grpfile = readdir(GRP))
     { next if ($grpfile =~ m/^\./); push(@grplist, "$grpfile\t$grpfile");  } 
     closedir(DIR);
     @grplist = sort @grplist;
   }
  # COLLECT THE LIST OF USERS
   @userlist =();
   open(USR, "$USERS") || print "Cannot find $USERS";
   while (<USR>)
  { 
    chomp; 
    ($UUID, $UPWD, $ufname, $ulname) = split (/\t/, $_); 
    push @userlist, "$ulname, $ufname\t$UUID"; 
  }
  close(USR);
  @userlist = sort @userlist;
  @UG=("GROUP", "USER");
  #
  # SET THE DEFAULT MINE ACCESS LEVEL
  #
  $argline="";
  $default="";
  foreach $f (@files) 
  { 
        ($d, $daccess) = split(/-/, $f);
	if ( $d eq "DEFAULT" ) { $default="$daccess"; }
  }
  if (! $default ) { $dlevel="ro"; }
  else {$dlevel="$default"; }
  if ( $dlevel eq "rw" ) { $nextdlevel="deny"; $dltext="Read/Write"; $ndltext="DENY"; }
  if ( $dlevel eq "ro" ) { $nextdlevel="rw"; $dltext="Read Only"; $ndltext="Read/Write";}
  if ( $dlevel eq "deny" ) { $nextdlevel="ro"; $dltext="DENY";  $ndltext="Read Only";}
  foreach $arg (@MINEARGS) { $argline="${argline}&$arg"; }
  print qq~
    <table border=0 width=100%>
    <tr><td colspan=4 valign=top align=center ><font fsb><b>Default Access Level: </font<font $fsbl>
    <a href="${ITKASM}?$argline&pv=${dlevel}&ndl=${nextdlevel}" class="hoverlink" title="Change default to $ndltext" style=\"color:$lnkcolor\">$dltext</a></font><br></b>&nbsp;</td>
    </td></tr>
  ~;

  # END SET DEFAULT ACCESS 

  foreach $ug (@UG)
  {
    if ( $ug eq "GROUP" ) { @list = @grplist; $selname="selgrp"; $uglink="$ITKASM?act=groups";}
    if ( $ug eq "USER" ) { @list = @userlist; $selname="selusr"; $uglink="$ITKASM?act=settings&sact=users&hd=Users";}
    print qq~
     <td> &nbsp; &nbsp; &nbsp; &nbsp; </td>
     <!-- ADD $ug PERMISSION -->
      <form method=get action=$ITKASM>
    ~;
    $argline="";
    foreach $arg (@MINEARGS) 
    {
      ($argact, $argval) = split(/\=/, $arg);
      $argline="${argline}&$arg";
      print "<input type=hidden name=${argact} value=${argval}>\n";
    }
    print qq~
        <td valign=top><table border=0 cellpadding=5 bgcolor=$gbxbg1>
        <tr>
        <td valign=top align=center nowrap>
          <font $fsn><b>Add <a href="$uglink" class="hoverlink" style=\"color:$lnkcolor\" title="Go to $ug to configure permissions">$ug</a> Permissions</b></font><br>
      <select name="$selname" onchange='this.form.submit()'>
      <option value=\"\" selected></option>
    ~;
    foreach (@list)
    {
          ($flname, $UUID) = split (/\t/, $_);
          print "<option value=\"$UUID\" >${flname}</option>\n";
    }
    print "</select></form>$hr_line</center>";
    print qq~
        <!-- LIST ${ug}s WITH ACCESS -->
        <table border=0 width=100%>
    ~;
    #
    # COLLECT WHAT IS IN THE DIRECTORY WITH ACCESS   
    # USER-ID-{RO|RW|DENY}
    # GROUP-ID-{RO|RW|DENY}
    #
#print "$MINEDIR/access/${ug}*";
   @ugers=();
   foreach $file (@files)
   {
#print "$ug - $file<br>";
      if ( $file =~ /^${ug}\-/ ) 
      {
        ($ugtype,$ugid,$ugaccess) = split(/-/, $file);
        if ( $ug eq "USER" ) { $userID="$ugid"; convert_user; $ugname="$ulname, $ufname"; }
        else { $ugname="$ugid"; }
        push @ugers, "$ugname\t$ugid\t$ugaccess";
      }
    }
    @ugers = sort @ugers;
    foreach (@ugers)
    {
      ($uglfname, $ugid, $uglevel) = split(/\t/, $_);
      if ( $uglevel eq "rw" ) { $nextlevel="deny";  $ugtext="Read/Write"; $nugtext="DENY";}
      if ( $uglevel eq "ro" ) { $nextlevel="rw";    $ugtext="Read Only";  $nugtext="Read/Write";}
      if ( $uglevel eq "deny" ) { $nextlevel="ro"; $ugtext="DENY";        $nugtext="Read Only";}
      if ( $ug eq "USER" ) { $UGLINK="$ITKASM?act=accpro&pro=$ugid&tog=account"; }
      elsif ( $ug eq "GROUP" ) { $UGLINK="$ITKASM?act=groups&grp=$uglfname&adu=1"; }
      print qq~
	<tr><td valign=center nowrap><font $fsnl><a href="$UGLINK" class="hoverlink" style=\"color:$lnkcolor\" title="Go to $uglfname Group" target=ug>$uglfname</a></font></td>
	<td valign=center align=center nowrap><font $fsnl>: <a href="${ITKASM}?$argline&ug=${ug}&pv=${uglevel}&nl=${nextlevel}&ugid=${ugid}" class="hoverlink" style=\"color:$attcolor\" title="Change to $nugtext">$ugtext</font></td>
        <td valign=center align=center>&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="${ITKASM}?${argline}&ug=${ug}&pv=${uglevel}&ugid=${ugid}&del=1" class="hoverlink" title="Delete $uglfname"><img src=$IMAGES/trashcan.png height=15 border=0></td>
	</tr>
      ~;
    }
    print qq~ 
       </table>
        </td>
        </tr>
      </table>
      </td>
    ~;
  }
  print "</table>";

}

###
### Show who is logged in on the top
### right of the screen
###
sub show_login
{
  get_attentionline;
  chomp($ATTLINE); 
  $chgpwd="";
  if ( "$WHOAMI" ) { $chgpwd="<font $fsnl><a href=\"${ITKASM}?act=respwd&who=$WHOAMI\" class=\"hoverlink\" title=\"Change Password\" style=\"color:$lnkcolor\">&copy</a></font>"; }
  if ( ! "$WHOAMI" ) { $username="Visitor";}
  else { $userID="$WHOAMI"; &convert_user; $username="$ufname $ulname"; }
  print qq~

<style type="text/css">
a.hoverlink:link {text-decoration: none; color:lnkcolor}
a.hoverlink:visited {text-decoration: none; color:vlnkcolor}
a.hoverlink:active {text-decoration: none; color:alnkcolor}
a.hoverlink:hover {text-decoration: underline; color:lnkcolor}
</style>
   <!--          -->
   <!-- TOP LINE -->
   <!--          -->
   <table border=0 width=100% bgcolor=$hdrcolor cellpadding=3>
    <td bgcolor="#ffffff" align=center width=65%><font $fsberr ><b>$ATTLINE</b></font></td> 
~;
   if ( ! $HIDELOGIN )
   {
    print "<td align=right valign=center nowrap>${chgpwd}<font $fsn>Login: <b>$username</b></font></td><td valign=center align=right>\n";
   }
print qq~
  ~;
  if ( "$username" eq "Visitor" )
  {
    if ( -f "$INSTDAT" )
    {
      if ( ! "$HIDELOGIN" ) 
      { 
        print qq~
	   <td align=right valign=center>
	   <a href=\"$ITKASMLOGIN\" class="hoverlink" style=\"color:$lnkcolor\"><font $fsbl><b>LOGIN</b></font></a></td>
	~;
      }
    }
  }
  else 
  { 
	print qq~
          <td valign=center align=left><font $fsnl><a href="$ITKASMSLEJ?show7=1" class="hoverlink" title="Open Personal Journal" style=\"color:$lnkcolor\">Journal</font></a>
          <a id="popup" href="$ITKASMSLEJ?pop=1" title="Pop-Out Journal"><img src="/itkasm/images/popout.png" height=12 border=0></a></td><td align=right valign=center width=40>

	  <a href=\"$ITKASM?act=logoutpage\" title="Logout of IT KASM" class="hoverlink" style=\"color:$lnkcolor\"><font $fsnl>Logout</font></a>
        ~;
#
# SET UP THE POPUP
#
print qq~
<script type="text/javascript">
window.onload=function() {
 document.getElementById('popup').onclick=function() {
   var w = window.open(this.href, this.target,
       'width=400,height=20,scrollbars=0,addressbar=0,toolbar=0, menubar=0,location=0');
    return (!w); // opens in new window/tab if allowed
  }
}
</script>
~;

    ###
    ### ONLY ADMIN LEVEL ACCESS CAN SEE THIS
    ###
    $accessTYPE=""; $accessID=""; &determine_access;
    if ( $ACCESSLEVEL eq "admin" || $WHOAMI eq "admin" ) 
    {
       print qq~
    	  </td><td valign=center align=right><font $fsn>
	   <a href=$ITKASM?wp=SETTINGS-MAIN title="Manage IT KASM Settings" class="hoverlink" style=\"color:$lnkcolor\"><font $fsnl>Settings</font>
	  </font>
  	~;
   }
  }
  print qq~
    <td align=right valign=center>
    <a href="http://www.itkasm.com/exec/itkasm-kbase?ID=help&s=${HLP}" title="Help $HLPDESC" class="hoverlink" style=\"color:$lnkcolor\" target=help><font $fsnl>Help</font></a>
    </td>
  ~;
print "</td></table>";

}


###
### PERFORM THE ACTUAL CHANGE OF THE PASSWORD
### change the password in the users account profile
### change the password in the user database.
###
sub writerpwd
{
#print "$buffer";
  $who="$form{who}"; &get_user_profile;
  $WEBFILE="$ETC/itkasm-header.dat"; &display_webpage; print "$hr_line";
  if ( $ACCESSLEVEL eq "admin" || $WHOAMI eq "admin" )
  {
    print qq~
        <table width=100% bgcolor=$hdrcolor cellpadding=3>
        <td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
        | <a href=$ITKASM?act=groups title="Go To Group Settings" style=\"color:$lnkcolor\">Groups</a>
        | <a href=$ITKASM?act=settings&sact=users&hd=Users title="Go To User Settings" style=\"color:$lnkcolor\">Users</a>
        | <a href=$ITKASM?act=cracct title="Create A User" style=\"color:$lnkcolor\">Create User</a>
        </font>
        <font $fsb>
        | <b>User: $proFNAME $proLNAME</b>
        </font>
	</td></table>
        $hr_line
    ~;
    $who="";
  }
  #
  # If changed by a user and not an ADMIN
  #
  if ( $form{tkn} )
  {
    # get current the account info from the token
    open(TK, "$TMP/$form{tkn}.tkn");
    while (<TK>) { chomp; $who="$_"; }
    close(TK);
  }
  else { $who="$form{who}"; }
  #
  # change the user account passwd
  #
  open(USR, "$USERDIR/$who/profile");
  while (<USR>)
  {
         chomp;
         ($Owho,$Opasswd, $Ofname, $Olname, $Oemail, $Ophone) = split(/\t/, "$_");
  }
  close(USR);

  $passwd = encrypt($form{nwpasswd});
  open(WUSR, "> $USERDIR/$who/profile");
  print WUSR "$Owho\t$passwd\t$Ofname\t$Olname\t$Oemail\t$Ophone";
  close(WUSR);

  #
  # Change the user database file
  #
  open(WUSR, "> ${USERS}.tmp");
  open(USR, "$USERS");
  while (<USR>)
  {
       chomp;
       ($Cid, $Cpwd, $Cfname, $Clname, $Cemail, $Cphone) = split(/\t/, $_);
       if ( "$Cid" ne "$who" ) {  print WUSR "$_\n"; }
       else { print WUSR "$Owho\t$passwd\t$Ofname\t$Olname\t$Oemail\t$Ophone\n"; }
  }
  close(USR);
  close(WUSR);
  `mv  ${USERS}.tmp $USERS`;
  `rm -f $TMP/$form{tkn}.tkn`;

     $message="[${WHOAMI}] ITKASM-LOGIN: $who : Password Changed : Completed"; &write_log;


  if ( $ACCESSLEVEL eq "admin" || $WHOAMI eq "admin" )
  { $HREF="$ITKASM?act=accpro&pro=$who"; $CONTINUE="Return to ${proFNAME}\'s profile";}
  else { $HREF="$ITKASMLOGIN"; $CONTINUE="Return to Login Page"; }
  print qq~
    &nbsp;<p>
    <center>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor >
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
        <tr><td colspan=2 align=center><font $fsn>&nbsp;<br>
    	Password changed for $proFNAME $proLNAME </font><p>
	<font $fsnl><a href="$HREF">$CONTINUE</a></font><p>&nbsp;
	</td></tr>
      </table>
   </table>
   </center>
  ~;
}


###
### DISPLAY PASSWORD RESET PAGE
###
sub pwdreset_page
{
  if ( $form{sact} eq "evalidate" ) { &email_pwdreset; exit; }
  #
  # ADMIN IS CHANGING A PASSWORD
  #
  if ( $form{who} ) { $who="$form{who}"}
  if ( $who ) { &get_user_profile; }
  print "$hr_line";
  if ( $ACCESSLEVEL eq "admin" || $WHOAMI eq "admin" )
  {
    print qq~
        <table width=100% bgcolor=$hdrcolor cellpadding=3>
        <td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" class="hoverlink" style=\"color:$lnkcolor\">Settings</a>
        | <a href=$ITKASM?act=groups title="Go To Group Settings" class="hoverlink" style=\"color:$lnkcolor\">Groups</a>
        | <a href=$ITKASM?act=settings&sact=users&hd=Users class="hoverlink" title="Go To User Settings" style=\"color:$lnkcolor\">Users</a>
        | <a href=$ITKASM?act=cracct title="Create A User" class="hoverlink" style=\"color:$lnkcolor\">Create User</a>
        </font>
        <font $fsbl>
        | <b>User: </b><a href=$ITKASM?act=accpro&pro=$form{who} title="Create A User" class="hoverlink" style=\"color:$lnkcolor\">$proFNAME $proLNAME</a>
        </font>
	</td></table>
        $hr_line
    ~;
  }

  if ( "$form{tkn}" )
  { 
      if ( -f "$TMP/$form{tkn}.tkn" )
      {
        open(PROF, "$TMP/$form{tkn}.tkn");
        while (<PROF>) { chomp; $who="$_"; }
        close(PROF);
        &get_user_profile;
      }
      if ( ! -f "$TMP/$form{tkn}.tkn" )
      {
#print "$buffer";
        print qq~
          &nbsp;<p>
          <center>
          <table border=1 cellspacing=3 cellpadding=20 bgcolor=$bgcolor2 >
          <td>
            <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
              <tr><td colspan=2><font $fsberr>&nbsp;<br>
              Link is invalid, already used, or expired.<p>
	      </font><font $fsn>Try to</font> <font $fsnl><a href=$ITKASMLOGIN class="hoverlink" style="color:$lnkcolor">Login</a> </font>
	      <font $fsn>or Create the account again.
 	      <p>Contact the </font><font $fsnl> <a href="mailto:$itkasmadmin" class="hoverlink" style="color:$lnkcolor">IT KASM Administrator</a> </font>
	      <font $fsn>if issue persist.<p>&nbsp;</font>
      
              </td></tr>
            </table>
         </table>
         </center>
        ~;
      } # if token file exists
  } # if token is passed

  #
  # NOT ADMIN: WHO IS THE PASSWORD TO BE CHANGED FOR
  # 
  if ( ! $form{tkn} && $ACCESSLEVEL ne "admin" && $WHOAMI ne "admin" && $mail_prog && ! $who )
  {
    print qq~
      <center>
      <p>
      <font $fsb>Reset Password</font><p>
      <form action=$ITKASM method=post>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor >
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
      <tr><td colspan=2><font $fserr>$ERRORLOG</font></td></tr> 
      <tr>
        <td align=right><font $fsn><b>Login ID:</b></font></td>
        <td><input type=username size=15 name=who value="" pattern="[^' ''@']+" title="Alpha-numeric only, No Spaces or email address allowed." autofocus required></td>
      </tr>
      <tr>
        <td colspan=2 align=center>
        <input type=hidden name="act" value="respwd">
        <input type=hidden name="sact" value="evalidate">
        &nbsp;<br> <Input TYPE="submit" VALUE="Send Validation Email">
        </form>
      </td>
      </tr>
      </table>
     </table>
    ~;
  }
  #
  # ADMIN CHANGING PASSWORD OR HAVE A TOKEN
  #
  if ( ( $who && $form{tkn} ) || ( $who eq $WHOAMI ) || $ACCESSLEVEL eq "admin" || $WHOAMI eq "admin" )
  {
#print "( $who && $form{tkn}) || ( $who eq $WHOAMI ) || $ACCESSLEVEL eq admin || $WHOAMI eq admin ";
    if ( $who )
    {
    print qq~
      <center>
      <p>
      <font $fsberr>NEVER USE YOUR NETWORK PASSWORD ON IT KASM<p>

      <form action="$ITKASM" method=post>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor >
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
      <tr>
        <td align=right><font $fsn><b>Login ID:</b></font></td> 
        <td><font $fsn>$who</font></td>
      </tr>
      <tr>
        <td align=right valign=top><font $fsn><b>New Password</b>:</font></td> 
        <td><input type=password size=16 name=nwpasswd id="myInput" value="" autofocus>
	  <br><input type="checkbox" onclick="myFunction()"><font $fsn>Show Password</font>
	</td>
      </tr>
      <tr>
        <td colspan=2 align=center>
        <input type=hidden name="act" value="writerpwd">
        <input type=hidden name="who" value="$who">
        <input type=hidden name="tkn" value="$form{tkn}">
        &nbsp;<br> <Input TYPE="submit" VALUE="Reset Password">
        </form>
      </td>
      </tr>
      </table>
     </table>
       <script>
       function myFunction() {
           var x = document.getElementById("myInput");
           if (x.type === "password") {
               x.type = "text";
           } else {
               x.type = "password";
           }
       }
       </script>
    ~;
    }
   }
}


### CREATE A NEW USER WHEN AN ADMIN
### NEW USERS TRYING FROM LOGIN GO THROUGH itkasm-login
###
sub create_newuser
{
#print "$buffer";
  if ( $ACCESSLEVEL eq "admin" || $WHOAMI eq "admin" )
  {
    $VAL="wrnacct";
    print qq~
       $hr_line
        <table width=100% bgcolor=$hdrcolor cellpadding=3>
        <td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" class="hoverlink" style=\"color:$lnkcolor\">Settings</a>
        | <a href=$ITKASM?act=groups title="Go To Group Settings" class="hoverlink" style=\"color:$lnkcolor\">Groups</a>
        | <a href=$ITKASM?act=settings&sact=users&hd=Users class="hoverlink" title="Go To User Settings" style=\"color:$lnkcolor\">Users</a>
        | <b>Create New User</b>
        </font>
        </td></table>
    ~;
  }
  else { $VAL="wrnacctv"; }
  print qq~
       $hr_line
    <center>
    <p>
    <font $fsberr>NEVER USE A NETWORK PASSWORD ON IT KASM<p>
    <p><font $fsb><b>Create New User</b></font><p>
    <form action="$ITKASM" method=post>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor >
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
      <tr><td colspan=2><font $fserr>$ERRORLOG</font></td></tr>
      <tr>
        <td align=right><font $fsn> <b>Login ID:</b></font></td><td>
          <input type=username size=20 name=lid value="" pattern="^[a-z0-9_-]{3,20}" title="At least 3-20 lowercase alpha-numeric characters only. No spaces or email addresses allowed." autofocus required> </td></tr>
      <tr><td valign=top align=right><font $fsn><b>Password:</font></b> </td><td>
          <input type=password size=25 name=passwd value="" id="myInput" pattern=".{8,}" title="Password should contain 8 or more characters that are of at least one number, and one uppercase and lowercase letters" required>
	  <br><input type="checkbox" onclick="myFunction()"><font $fsn>Show Password</font>
</td></tr>
      <tr> <td colspan=2><hr size=1></td></tr>
      <tr><td align=right valign=top><font $fsn><b>First Name:</b></font></td><td>
          <input type=text size=25 name=fname value="$form{fname}" autofocus required> </td></tr>
      <tr><td align=right valign=top><font $fsn><b>Last Name:</b></font></td><td>
          <input type=text size=25 name=lname value="$form{lname}" required> </td></tr>
      <tr><td align=right valign=top><font $fsn><b>Email:</b></font></td><td>
          <input type=email size=25 name=email value="$form{email}" placeholder="me\@email.com" required></td></tr>
      <tr><td align=right valign=top><font $fsn><b>Phone:</b></font></td><td>
          <input type=phone size=12 name=phone value="$form{phone}" placeholder="000-000-0000" required></td></tr>
        <tr>
        <td></td><td>
        <input type=hidden name="act" value="$VAL">
        &nbsp;<br> <Input TYPE="submit" VALUE="Create Account">
        </form>
      </td>
      </tr>
      </table>
   </table>

   <script>
   function myFunction() {
       var x = document.getElementById("myInput");
       if (x.type === "password") {
           x.type = "text";
       } else {
           x.type = "password";
       }
   }
   </script>
  ~;
}


###
### Email link is confirmed here
###
sub email_confirm
{
  #
  # IF TOKEN EXISTS / FINISH ACCOUNT CREATION
  #
  $created="";
  if ( -f "$TMP/$form{tkn}" )
  {
    open(PROF, "$TMP/$form{tkn}");
    while (<PROF>)
    {
      chomp;
      ($proID, $proPWD, $proFNAME, $proLNAME, $proEMAIL, $proPHONE) = split(/\t/, $_);
    }
    close(PROF);
    #
    #   IF TOKEN IS RE-USED OR ANOTHER EMAIL LINK IS USED AFTER-THE-FACT
    #
    if ( -d "$USERDIR/$proID" && -f "$USERDIR/$proID/profile" )
    {  $ERRORLOG="User Account has already been validated."; $created="1"; }
    else
    {
      # 
      # MOVE USER ACCOUNT INTO PLACE
      #
      `mkdir -p $USERDIR/$proID`;
      `mv $TMP/$form{tkn} $USERDIR/$proID/profile`;
      `cat $USERDIR/$proID/profile >> $USERS`;
      $ERRORLOG="Account has been verified and created";
      $created="1";
    }
  }
  else
  {
    #
    # TOKEN NO LONGER EXISTS AND ACCOUNT MUST BE RECREATED
    #
    $ERRORLOG="<font $fserr>Link is invalid, already used, or expired.<p>Try to </font><font $fsnl><a href=$ITKASMLOGIN class=\"hoverlink\" >Login</a> </font><font $fsn>or Create the account again.<p>Contact the </font><font $fsnl><a href=mailto:$itkasmadmin class=\"hoverlink\" >IT KASM Administrator</a> </font><font $fsn>if issue persist.<p>&nbsp;</font>";
  }
  $WEBFILE="$ETC/itkasm-header.dat"; &display_webpage; print "$hr_line";
#print "$buffer"; 
  print qq~
    &nbsp;<p>
    <center>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$bgcolor2 >
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
        <tr><td colspan=2>&nbsp;<br>$ERRORLOG</td></tr>
  ~;
  if ( $created )
  {
    print qq~
	<tr><td colspan=2>$hr_line</td></tr> 
	<tr><td align=right><b><font $fsn>Login:</font></b></td><td><font $fsn>$proID</font></td></tr> 
	<tr><td align=right><b><font $fsn>Name:</font></b></td><td><font $fsn>$proFNAME $proLNAME</font></td></tr> 
	<tr><td align=right><b><font $fsn>Email:</font></b></td><td><font $fsn>$proEMAIL</font></td></tr> 
	<tr><td align=right><b><font $fsn>Phone:</font></b></td><td><font $fsn>$proPHONE</font></td></tr> 
	<tr><td colspan=2>$hr_line</td></tr> 
	<tr><td align=center colspan=2><font $fsnl><a href="$ITKASMLOGIN" class="hoverlink">Login to IT KASM</a></font></td></tr> 
    ~;
  }
  print qq~
      </table>
   </table>
   </center>
  ~;

exit;
}


###
### EMAIL VALIDATION LINK
###
sub email_pwdreset
{
  my $random_string=&get_token(25);
  &get_token;
  $token="$random_string";
  $who="$form{who}"; &get_user_profile;
#print "$buffer - $token<p>";  
  if ( ! "$proID" ) { $form{sact}=""; $ERRORLOG="Login ID $ID does not exist"; pwdreset_page; exit;}
 
  
  $emailaddr="$proEMAIL";
  print qq~
   $hr_line
    <center>
    <p><font size=4><b>Reset Password Verification</b></font><p>

    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$bgcolor2>
    <td>
      <table border=0 cellpadding=3 bgcolor=$bgcolor1>
      <td>
        A password reset link has been sent to <b>$emailaddr</b>
        <p>
        Please click on the link in then email you were sent. 
        <p>

        <p> <center><a href=$ITKASM class="hoverlink">Return to Home Page</a></center><br>
      </td></table>
   </td></table>
   </center>
  ~;
    open(TK, "> $TMP/${token}.tkn") || print "Cannot write to $TMP/${token}.tkn";
    print TK "$form{who}";
    close(TK);

    # TO TEST WHEN MAIL ISNT CONFIGURED
    #open (MAIL, "> $TMP/email.tmp") || die "Could not open $mail_prog to reset password";
    open (MAIL, "|$mail_prog -s \"IT KASM Password Reset\" $emailaddr") || die "Could not open $mail_prog to reset password";

    print MAIL "From: IT KASM\n";
    print MAIL "Subject: IT KASM: Reset Password\n";
    print MAIL "\n";
    print MAIL "To reset your IT KASM password click on the following link\n \n ${HTTP}${ITKASM}?act=respwd&tkn=$token\n";
    print MAIL ".\n";
    close(MAIL);
}

###
### EMAIL TOKEN TO VERIFY ACCOUNT AND EMPLOYEE
###
sub email_verify
{
  my $random_string=&get_token(25);
  &get_token;
  $token="$random_string";
  $passwd = encrypt($form{passwd});
#print "$buffer - token=$token<p>";
  #
  # MAKE SURE AN ACCOUNT DOESN'T ALREADY EXIST
  #
  open(USR, "$USERS") || print "CANNOT FIND THE $USERS file";
  while(<USR>)
  {
    if ( /^$form{lid}\t/ ) 
    { $ERRORLOG="User $form{lid} already exists."; create_newuser; exit; }
  }
  close(USR);
  if ( -f "$USERDIR/$form{lid}/profile" )     
  { $ERRORLOG="User $form{lid} already exists."; create_newuser; exit; }

  open(OUT, "> $TMP/$token") || print "Cannot write to $TMP/$token";
  print OUT "$form{lid}\t$passwd\t$form{fname}\t$form{lname}\t$form{email}\t$form{phone}\n";
  close(OUT);

  $emailaddr="$form{email}";
 
#print "<p>$mail_prog -v -s \"IT KASM: Verify Login\" $emailaddr";
  open (MAIL, "|$mail_prog -s \"IT KASM: Verify Login\" $emailaddr") || die "Could not open $mail_prog";

  print MAIL "From: IT KASM\n";
  print MAIL "Subject: IT KASM: Verify Login\n";
  print MAIL "\n";
  print MAIL "To active your IT KASM account click on the following link\n \n ${HTTP}$ITKASM?act=verify&tkn=$token\n";
  print MAIL ".\n";
  close(MAIL);

  ###
  ### SEND TO IT KASM ADMINS
  ###
  $emailaddr="root";
  open (MAIL, "|$mail_prog -s \"IT KASM: $form{fname} $form{lname} Created Account\" $itkasmadmin") || die "Could not open $mail_prog";

    print MAIL "From: IT KASM\n";
    print MAIL "Subject: IT KASM: $form{fname} $form{lname} Created Account\n";
    print MAIL "\n";
    print MAIL "ID: $form{lid}\n";
    print MAIL "Name: $form{fname} $form{lname}\n";
    print MAIL "Email: $form{email}\n";
    print MAIL "Phone: $form{phone}\n";
    #print MAIL ".\n";
    close(MAIL);

  $WEBFILE="$ETC/itkasm-header.dat"; &display_webpage; print "$hr_line";
  print qq~
    &nbsp;<p>
    <center>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$bgcolor2 >
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
        <tr><td colspan=2><font $fsn>
    You have been sent a verlification link to the email provided. <p>
    <b>Please follow the link in the email you were sent. </b>
    <p> <center><a href=$ITKASM class="hoverlink">Continue...</a></center>
	</font></td></tr>
      </table>
   </table>
   </center>
  ~;
  $message="[$form{lid}] ITKASM-LOGIN: $who : IT KASM Account Creation attempted - Waiting on validation"; &write_log;

}


###
### WRITE OUT NEW USER IF ADMIN
###
sub write_newuser
{
  if ( $ACCESSLEVEL eq "admin" || $WHOAMI eq "admin" )
  {
    $passwd = encrypt($form{passwd});
    $form{fname}=ucfirst($form{fname});
    $form{lname}=ucfirst($form{lname});
    open(USR, "$USERS") || print "CANNOT FIND THE $USERS file";
    while(<USR>)
    {
      if ( /^$form{lid}\t/)
      {
         $ERRORLOG="User $form{lid} already exists."; create_newuser; exit;
      }
    }
    close(USR);
    if ( ! -d "$USERDIR/$form{lid}" ) { `mkdir -p $USERDIR/$form{lid}`; }
    open(WUSR, "> $USERDIR/$form{lid}/profile") || print "CANNOT WRITE TO $USERDIR/$form{lid}/profile";
    print WUSR "$form{lid}\t$passwd\t$form{fname}\t$form{lname}\t$form{email}\t$form{phone}";
    close(WUSR);
    open(WUSR, ">> $USERS") || print "CANNOT WRITE TO $USERS";
    print WUSR "$form{lid}\t$passwd\t$form{fname}\t$form{lname}\t$form{email}\t$form{phone}\n";
    close(WUSR);
    print qq~
      <META HTTP-EQUIV="Refresh" CONTENT="0;URL=$ITKASM?act=accpro&pro=$form{lid}">
    ~;
    $META="1";
    exit;
  }
}


###
### Display the checklist r/o to view updates
###
sub display_checklist
{
  open(CKLST,"$MODFILE") || print "$MODFILE not found";
  while (<CKLST>)
  {
   if ( $form{h} ) { s/%%%DEVICENAME%%%/\<b\>$form{h}\<\/b\>/g; } 
   $frag=substr $_, 0,1;
    if ( $frag eq "<" ) { print "$_";   }
    else
    {
      if ( /^xx/ )
      {
        ($ctype, $cdesc) = split(/\t/, $_);
        ($cxx,$cbit) = split(/:/,$ctype);
        print "<img src=\"$IMAGES/checkbox-blank.png\" height=15 width=15 border=0>";
         print " $cdesc<br>\n";

      }
      else { print "$_&nbsp;<br>"; }
    }
  }
  close(CKLST);
  print "<p>&nbsp;<p>";
}


1;


#
#
# 		    GNU GENERAL PUBLIC LICENSE
# 		       Version 2, June 1991
# 
#  Copyright (C) 1989, 1991 Free Software Foundation, Inc.
#                        59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#  Everyone is permitted to copy and distribute verbatim copies
#  of this license document, but changing it is not allowed.
# 
# 			    Preamble
# 
#   The licenses for most software are designed to take away your
# freedom to share and change it.  By contrast, the GNU General Public
# License is intended to guarantee your freedom to share and change free
# software--to make sure the software is free for all its users.  This
# General Public License applies to most of the Free Software
# Foundation's software and to any other program whose authors commit to
# using it.  (Some other Free Software Foundation software is covered by
# the GNU Library General Public License instead.)  You can apply it to
# your programs, too.
# 
#   When we speak of free software, we are referring to freedom, not
# price.  Our General Public Licenses are designed to make sure that you
# have the freedom to distribute copies of free software (and charge for
# this service if you wish), that you receive source code or can get it
# if you want it, that you can change the software or use pieces of it
# in new free programs; and that you know you can do these things.
# 
#   To protect your rights, we need to make restrictions that forbid
# anyone to deny you these rights or to ask you to surrender the rights.
# These restrictions translate to certain responsibilities for you if you
# distribute copies of the software, or if you modify it.
# 
#   For example, if you distribute copies of such a program, whether
# gratis or for a fee, you must give the recipients all the rights that
# you have.  You must make sure that they, too, receive or can get the
# source code.  And you must show them these terms so they know their
# rights.
# 
#   We protect your rights with two steps: (1) copyright the software, and
# (2) offer you this license which gives you legal permission to copy,
# distribute and/or modify the software.
# 
#   Also, for each author's protection and ours, we want to make certain
# that everyone understands that there is no warranty for this free
# software.  If the software is modified by someone else and passed on, we
# want its recipients to know that what they have is not the original, so
# that any problems introduced by others will not reflect on the original
# authors' reputations.
# 
#   Finally, any free program is threatened constantly by software
# patents.  We wish to avoid the danger that redistributors of a free
# program will individually obtain patent licenses, in effect making the
# program proprietary.  To prevent this, we have made it clear that any
# patent must be licensed for everyone's free use or not licensed at all.
# 
#   The precise terms and conditions for copying, distribution and
# modification follow.
# 
# 		    GNU GENERAL PUBLIC LICENSE
#    TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
# 
#   0. This License applies to any program or other work which contains
# a notice placed by the copyright holder saying it may be distributed
# under the terms of this General Public License.  The "Program", below,
# refers to any such program or work, and a "work based on the Program"
# means either the Program or any derivative work under copyright law:
# that is to say, a work containing the Program or a portion of it,
# either verbatim or with modifications and/or translated into another
# language.  (Hereinafter, translation is included without limitation in
# the term "modification".)  Each licensee is addressed as "you".
# 
# Activities other than copying, distribution and modification are not
# covered by this License; they are outside its scope.  The act of
# running the Program is not restricted, and the output from the Program
# is covered only if its contents constitute a work based on the
# Program (independent of having been made by running the Program).
# Whether that is true depends on what the Program does.
# 
#   1. You may copy and distribute verbatim copies of the Program's
# source code as you receive it, in any medium, provided that you
# conspicuously and appropriately publish on each copy an appropriate
# copyright notice and disclaimer of warranty; keep intact all the
# notices that refer to this License and to the absence of any warranty;
# and give any other recipients of the Program a copy of this License
# along with the Program.
# 
# You may charge a fee for the physical act of transferring a copy, and
# you may at your option offer warranty protection in exchange for a fee.
# 
#   2. You may modify your copy or copies of the Program or any portion
# of it, thus forming a work based on the Program, and copy and
# distribute such modifications or work under the terms of Section 1
# above, provided that you also meet all of these conditions:
# 
#     a) You must cause the modified files to carry prominent notices
#     stating that you changed the files and the date of any change.
# 
#     b) You must cause any work that you distribute or publish, that in
#     whole or in part contains or is derived from the Program or any
#     part thereof, to be licensed as a whole at no charge to all third
#     parties under the terms of this License.
# 
#     c) If the modified program normally reads commands interactively
#     when run, you must cause it, when started running for such
#     interactive use in the most ordinary way, to print or display an
#     announcement including an appropriate copyright notice and a
#     notice that there is no warranty (or else, saying that you provide
#     a warranty) and that users may redistribute the program under
#     these conditions, and telling the user how to view a copy of this
#     License.  (Exception: if the Program itself is interactive but
#     does not normally print such an announcement, your work based on
#     the Program is not required to print an announcement.)
# 
# These requirements apply to the modified work as a whole.  If
# identifiable sections of that work are not derived from the Program,
# and can be reasonably considered independent and separate works in
# themselves, then this License, and its terms, do not apply to those
# sections when you distribute them as separate works.  But when you
# distribute the same sections as part of a whole which is a work based
# on the Program, the distribution of the whole must be on the terms of
# this License, whose permissions for other licensees extend to the
# entire whole, and thus to each and every part regardless of who wrote it.
# 
# Thus, it is not the intent of this section to claim rights or contest
# your rights to work written entirely by you; rather, the intent is to
# exercise the right to control the distribution of derivative or
# collective works based on the Program.
# 
# In addition, mere aggregation of another work not based on the Program
# with the Program (or with a work based on the Program) on a volume of
# a storage or distribution medium does not bring the other work under
# the scope of this License.
# 
#   3. You may copy and distribute the Program (or a work based on it,
# under Section 2) in object code or executable form under the terms of
# Sections 1 and 2 above provided that you also do one of the following:
# 
#     a) Accompany it with the complete corresponding machine-readable
#     source code, which must be distributed under the terms of Sections
#     1 and 2 above on a medium customarily used for software interchange; or,
# 
#     b) Accompany it with a written offer, valid for at least three
#     years, to give any third party, for a charge no more than your
#     cost of physically performing source distribution, a complete
#     machine-readable copy of the corresponding source code, to be
#     distributed under the terms of Sections 1 and 2 above on a medium
#     customarily used for software interchange; or,
# 
#     c) Accompany it with the information you received as to the offer
#     to distribute corresponding source code.  (This alternative is
#     allowed only for noncommercial distribution and only if you
#     received the program in object code or executable form with such
#     an offer, in accord with Subsection b above.)
# 
# The source code for a work means the preferred form of the work for
# making modifications to it.  For an executable work, complete source
# code means all the source code for all modules it contains, plus any
# associated interface definition files, plus the scripts used to
# control compilation and installation of the executable.  However, as a
# special exception, the source code distributed need not include
# anything that is normally distributed (in either source or binary
# form) with the major components (compiler, kernel, and so on) of the
# operating system on which the executable runs, unless that component
# itself accompanies the executable.
# 
# If distribution of executable or object code is made by offering
# access to copy from a designated place, then offering equivalent
# access to copy the source code from the same place counts as
# distribution of the source code, even though third parties are not
# compelled to copy the source along with the object code.
# 
#   4. You may not copy, modify, sublicense, or distribute the Program
# except as expressly provided under this License.  Any attempt
# otherwise to copy, modify, sublicense or distribute the Program is
# void, and will automatically terminate your rights under this License.
# However, parties who have received copies, or rights, from you under
# this License will not have their licenses terminated so long as such
# parties remain in full compliance.
# 
#   5. You are not required to accept this License, since you have not
# signed it.  However, nothing else grants you permission to modify or
# distribute the Program or its derivative works.  These actions are
# prohibited by law if you do not accept this License.  Therefore, by
# modifying or distributing the Program (or any work based on the
# Program), you indicate your acceptance of this License to do so, and
# all its terms and conditions for copying, distributing or modifying
# the Program or works based on it.
# 
#   6. Each time you redistribute the Program (or any work based on the
# Program), the recipient automatically receives a license from the
# original licensor to copy, distribute or modify the Program subject to
# these terms and conditions.  You may not impose any further
# restrictions on the recipients' exercise of the rights granted herein.
# You are not responsible for enforcing compliance by third parties to
# this License.
# 
#   7. If, as a consequence of a court judgment or allegation of patent
# infringement or for any other reason (not limited to patent issues),
# conditions are imposed on you (whether by court order, agreement or
# otherwise) that contradict the conditions of this License, they do not
# excuse you from the conditions of this License.  If you cannot
# distribute so as to satisfy simultaneously your obligations under this
# License and any other pertinent obligations, then as a consequence you
# may not distribute the Program at all.  For example, if a patent
# license would not permit royalty-free redistribution of the Program by
# all those who receive copies directly or indirectly through you, then
# the only way you could satisfy both it and this License would be to
# refrain entirely from distribution of the Program.
# 
# If any portion of this section is held invalid or unenforceable under
# any particular circumstance, the balance of the section is intended to
# apply and the section as a whole is intended to apply in other
# circumstances.
# 
# It is not the purpose of this section to induce you to infringe any
# patents or other property right claims or to contest validity of any
# such claims; this section has the sole purpose of protecting the
# integrity of the free software distribution system, which is
# implemented by public license practices.  Many people have made
# generous contributions to the wide range of software distributed
# through that system in reliance on consistent application of that
# system; it is up to the author/donor to decide if he or she is willing
# to distribute software through any other system and a licensee cannot
# impose that choice.
# 
# This section is intended to make thoroughly clear what is believed to
# be a consequence of the rest of this License.
# 
#   8. If the distribution and/or use of the Program is restricted in
# certain countries either by patents or by copyrighted interfaces, the
# original copyright holder who places the Program under this License
# may add an explicit geographical distribution limitation excluding
# those countries, so that distribution is permitted only in or among
# countries not thus excluded.  In such case, this License incorporates
# the limitation as if written in the body of this License.
# 
#   9. The Free Software Foundation may publish revised and/or new versions
# of the General Public License from time to time.  Such new versions will
# be similar in spirit to the present version, but may differ in detail to
# address new problems or concerns.
# 
# Each version is given a distinguishing version number.  If the Program
# specifies a version number of this License which applies to it and "any
# later version", you have the option of following the terms and conditions
# either of that version or of any later version published by the Free
# Software Foundation.  If the Program does not specify a version number of
# this License, you may choose any version ever published by the Free Software
# Foundation.
# 
#   10. If you wish to incorporate parts of the Program into other free
# programs whose distribution conditions are different, write to the author
# to ask for permission.  For software which is copyrighted by the Free
# Software Foundation, write to the Free Software Foundation; we sometimes
# make exceptions for this.  Our decision will be guided by the two goals
# of preserving the free status of all derivatives of our free software and
# of promoting the sharing and reuse of software generally.
# 
# 			    NO WARRANTY
# 
#   11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
# FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
# OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
# PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
# OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
# TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
# PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
# REPAIR OR CORRECTION.
# 
#   12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
# WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
# REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
# INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
# OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
# TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
# YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
# PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGES.
# 
# 		     END OF TERMS AND CONDITIONS
# 
# 	    How to Apply These Terms to Your New Programs
# 
#   If you develop a new program, and you want it to be of the greatest
# possible use to the public, the best way to achieve this is to make it
# free software which everyone can redistribute and change under these terms.
# 
#   To do so, attach the following notices to the program.  It is safest
# to attach them to the start of each source file to most effectively
# convey the exclusion of warranty; and each file should have at least
# the "copyright" line and a pointer to where the full notice is found.
# 
#     <one line to give the program's name and a brief idea of what it does.>
#     Copyright (C) 19yy  <name of author>
# 
#     This program is free software; you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation; either version 2 of the License, or
#     (at your option) any later version.
# 
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
# 
#     You should have received a copy of the GNU General Public License
#     along with this program; if not, write to the Free Software
#     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# 
# 
# Also add information on how to contact you by electronic and paper mail.
# 
# If the program is interactive, make it output a short notice like this
# when it starts in an interactive mode:
# 
#     Gnomovision version 69, Copyright (C) 19yy name of author
#     Gnomovision comes with ABSOLUTELY NO WARRANTY; for details type `show w'.
#     This is free software, and you are welcome to redistribute it
#     under certain conditions; type `show c' for details.
# 
# The hypothetical commands `show w' and `show c' should show the appropriate
# parts of the General Public License.  Of course, the commands you use may
# be called something other than `show w' and `show c'; they could even be
# mouse-clicks or menu items--whatever suits your program.
# 
# You should also get your employer (if you work as a programmer) or your
# school, if any, to sign a "copyright disclaimer" for the program, if
# necessary.  Here is a sample; alter the names:
# 
#   Yoyodyne, Inc., hereby disclaims all copyright interest in the program
#   `Gnomovision' (which makes passes at compilers) written by James Hacker.
# 
#   <signature of Ty Coon>, 1 April 1989
#   Ty Coon, President of Vice
# 
# This General Public License does not permit incorporating your program into
# proprietary programs.  If your program is a subroutine library, you may
# consider it more useful to permit linking proprietary applications with the
# library.  If this is what you want to do, use the GNU Library General
# Public License instead of this License.
#
#
