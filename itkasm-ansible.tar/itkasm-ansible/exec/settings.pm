###
### itkasm Settings 
###
### Licensed under GNU General Public License v2 - See EOF
###

#==============================================
###
### Display Settings front page
###
sub display_usermatrix
{
 print qq~
        $hr_line
        <table width=100% bgcolor=$hdrcolor cellpadding=3>
        <td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
        | <a href=$ITKASM?act=groups class=\"hoverlink\" title="Go To Group Settings" style=\"color:$lnkcolor\">Groups</a>
        | <b>Users</b> | 
        <a href=$ITKASM?act=cracct class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Create New User</a>
        </font>
	</td></table>
        $hr_line

	<table border=0 cellspacing=4 cellpadding=4>
    	<tr>
	<td></td>
	<td align=center><font $fsb><b>Name</b></font></td>
	<td align=center><font $fsn><b>ID</b></font></td>
	<td align=center><font $fsn><b>Access</b></font></td>
	<td align=center><font $fsn><b>Groups</b></font></td>
	<td align=center><font $fsn><b>Status</b></font></td>
	<td align=center><font $fsn><b>Last Access</b></font></td>
  ~;
  	print qq~
        <tr><td colspan=15>$hr_line</td></tr>
	</tr>
        ~;
 @userlist=(); $cnt=0;
 open(IN, "sort -k 3,3 $USERS|");
  while (<IN>)
  {
     push(@userlist,$_);
  }
  $lastDT="";
  foreach $_ (@userlist)
  {
    ($setID, $setPWD, $setFNAME, $setLNAME, $setACC) = split(/\t/, $_);
    if ( -f "$USERDIR/$setID/lastaccess" ) 
    { 
	open(LACC, "$USERDIR/$setID/lastaccess");
        while (<LACC>)
  	{
	  ($lastacc,$lastcmd)=split(/\t/,$_); 
	  ($lastDT,$lastTM)=split(/ /, $lastacc); 
 	}
	close(LACC);
    }
    if ( ! -f "$USERDIR/$setID/ADMIN" ) { $setACC="User"; }
    else { $setACC="ADMIN"; }
    $cnt++;
    if ( -f "$USERDIR/$setID/DISABLED") { $setSTAT="<b>Disabled</b>"; $color="color=ff0000"; }
    else {$setSTAT="Enabled"; $color="ffffff"; }
    print qq~
    	<tr>
	<td align=right><font $fsn>$cnt:</font></td>
	<td nowrap><font $fsnl><a href="$ITKASM?act=accpro&pro=$setID" class=\"hoverlink\" style=\"color:$lnkcolor\">${setFNAME} $setLNAME</a></font></td>
	<td><font $fsn>$setID</font></td>
	<td><font $fsn>$setACC</font></td>
	<td><font $fsn>$setGRP</font></td>
	<td><font $fsn $color>$setSTAT</font></td>
	<td nowrap><font $fsn>$lastDT : $lastcmd<font></td>
    ~;
  $lastacc="";$lastcmd="";$lastDT="";
  }
  close(IN);
	print qq~
	</tr></table>
	<p>
        $hr_line
	~;
}




###
### Display the Settings Profile
### for a user
###
sub access_profile
{
#print "$buffer";
  if ( $form{stat} eq "e" ) 
  { 
	if ( -f "$USERDIR/$form{pro}/DISABLED" ) { `rm -f $USERDIR/$form{pro}/DISABLED`; } 
  }
  if ( $form{stat} eq "d" ) 
  { 
	`touch $USERDIR/$form{pro}/DISABLED`; 
  } 

  $who="$form{pro}"; &get_user_profile;

  if ( $form{updemail} || $form{updphone} )
  {
    #
    # UPDATE PROFILE IF EMAIL OR PHONE IS CHANGED
    #
    if ( $form{updemail} ) { $proEMAIL="$form{updemail}"; }
    if ( $form{updphone} ) { $proPHONE="$form{updphone}"; }
    open(OUT, "> $USERDIR/$form{pro}/profile");
    print OUT "$proID\t$proPWD\t$proFNAME\t$proLNAME\t$proEMAIL\t$proPHONE";
    close(OUT);

    # UPDATE ETC/USERS FILE IF EMAIL OR PHONE IS CHANGED
    @LST=();@NEWLST=();
    tie @LST, 'Tie::File', "$USERS" or die;
    $NEWLINE="";
    foreach (@LST)
    {
      if ( /^$form{pro}\t/) 
      {
        $NEWLINE="$proID\t$proPWD\t$proFNAME\t$proLNAME\t$proEMAIL\t$proPHONE\n"; 
        push@NEWLST, "$NEWLINE";
      } 
      else { push@NEWLST, "$_";}
    }
    @NEWLST=sort @LST;
    @LST=@NEWLST;
    untie(@LST);
  }
  #
  # IF PASSED A NEW GROUP THEN WRITE THE CHANGE
  #
  $proLNAME=~tr/\r\n//;
  $proLNAME=~s/\s+//g;

  if ( ! -d "$USERDIR/$proID/access" && $proID ) { `mkdir -p $USERDIR/$proID/access`; }
    if ( "$form{tog}" eq "ADMIN") 
    {
	if ( -f "$USERDIR/$proID/ADMIN" ) 
	{ 
	  `rm -f $USERDIR/$proID/ADMIN`; 
 	  $message="[${WHOAMI}]\tSettings\tremove : ADMIN : access from $proID"; &write_log;
	}
	else 
 	{ 
	  `touch $USERDIR/$proID/ADMIN`; 
 	  $message="[${WHOAMI}]\tSettings\tgrant : ADMIN : access to $proID"; &write_log;
	}
    }
  if ( ! -f "$USERDIR/$proID/ADMIN" ) { $proACC="User"; }
  else { $proACC="ADMIN"; }
  if ( ! -s "$USERDIR/$form{pro}/lastaccess") { `touch "$USERDIR/$form{pro}/lastaccess"`; $lastacc="Never";}


  # CHECK IF USER ENABLED/DISABLED }
  if ( -f "$USERDIR/$proID/DISABLED" ) { $status_D="<b><font $fserr>DISABLED</font></b>"; $status_E="<a href=\"$PROG?act=accpro&pro=$form{pro}&tog=account&stat=e\" class=\"hoverlink\">Enable</a>"; }
  if ( ! -f "$USERDIR/$proID/DISABLED" ) { $status_D="<a href=\"$PROG?act=accpro&pro=$form{pro}&tog=account&stat=d\" class=\"hoverlink\">Disable</a>"; $status_E="<b>Enabled</b>"; }
  print qq~
        $hr_line
        <table width=100% bgcolor=$hdrcolor cellpadding=3>
        <td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
        | <a href=$ITKASM?act=groups class=\"hoverlink\" title="Go To Group Settings" style=\"color:$lnkcolor\">Groups</a>
        | <a href=$ITKASM?act=settings&sact=users&hd=Users class=\"hoverlink\" title="Go To User Settings" style=\"color:$lnkcolor\">Users</a>
        | <a href=$ITKASM?act=cracct class=\"hoverlink\" title="Create A User" style=\"color:$lnkcolor\">Create New User</a>
	</font>
	<font $fsb>
	| <b>User: $proFNAME $proLNAME</b>
        </font>
	</td></table>
        $hr_line
       	<table border=0 width=75%>
	<td valign=top>
  	  <table border=0 cellpadding=3 cellspacing=3 width=325>
 	  <tr><td></td><td valign=top><font $fsn><b>ID:</b></font></td><td><font $fsn>$proID</font></td></tr> 
 	  <tr><td></td><td valign=top><font $fsn><b>Name:</b></font></td><td><font $fsn>$proFNAME $proLNAME</font></td></tr> 

 	  <tr><td></td><td><font $fsn><b>Password:</font><br>
		<td valign=top><font $fsnl><a href="$ITKASM?act=respwd&who=$form{pro}" class=\"hoverlink\" style=\"color:$lnkcolor\">Change</a> </font></center></b></td></tr> 
 	  <tr><td align=right valign=top><a href=$ITKASM?act=accpro&pro=$form{pro}&edit=email title="Edit Email address"><img src=$IMAGES/edit.png height=12 border=0></a></td>
        ~;
	if ( $form{edit} eq "email" ) { $EMAIL="
        <form method=post action=$ITKASM>
        <input type=hidden name=act value=accpro>
        <input type=hidden name=pro value=$form{pro}>
        <td><input type=email size=25 name=updemail value=\"$proEMAIL\" required></td>
        <td><input type=\"submit\" value=\"Update\">
        </form></td>";
        }
	else { $EMAIL="<td><font $fsn>$proEMAIL</font></td>"; }
        print qq~
            <td valign=top><font $fsn><b>Email:</b></font></td>$EMAIL</tr>
          </tr> 
 	  <tr><td align=right valign=top><a href=$ITKASM?act=accpro&pro=$form{pro}&edit=phone title="Edit Phone Number"><img src=$IMAGES/edit.png height=12 border=0></a></td>
        ~;
	if ( $form{edit} eq "phone" ) { $PHONE="
        <form method=post action=$ITKASM>
        <input type=hidden name=act value=accpro>
        <input type=hidden name=pro value=$form{pro}>
        <td><input type=phone size=12 name=updphone value=\"$proPHONE\" required></td>
        <td><input type=\"submit\" value=\"Update\">
        </form></td>";
        }
	else { $PHONE="<td><font $fsn>$proPHONE</font></td>"; }
        print qq~
            <td valign=top><font $fsn><b>Phone:</b></font></td>$PHONE</tr> 
 	  <tr><td></td><td nowrap><font $fsn><b>Access Level:</font></b></td>
	  <td><font $fsnl><b>
	  <a href="$PROG?act=accpro&pro=$form{pro}&tog=ADMIN" class=\"hoverlink\" style=\"color:$lnkcolor\">$proACC</a></b></font></td></tr> 
    	  <tr><td></td><td valign=top nowrap><font $fsn><b>Last Access:</font></b></td>
	  <td valign=top><font $fsn> $lastacc</font></td></tr>
 	  <tr><td></td><td valign=top><font $fsn><b>Account:</font></b></td>
	  <td valign=top><font $fsn>$status_E <br>
	  $status_D <br> 
	  <!-- <a href="$PROG?act=accpro&pro=$form{pro}&tog=account">Remove</a></font> NOT IMPLEMENTED YET -->
	  </td></tr> 
	  </table>
  	</td>
       </td>
  ~;

  ###
  ### LIST USER ACCESS
  ###
  print qq~
        <td valign=top><hr width=1 size=500></td>
	<td valign=top><table border=0 cellpadding=3>
	<tr><td colspan=3 align=center><font $fsb><b>User Access</b></font><br>
        $hr_line
	</td></tr>
  ~;
  foreach $m (@minelist)
  { 
    print "<tr><td><font $fsn><u><b>$m</b></u></font></td></tr>\n";
    $lcmine= lc($m); 
    if ( $lcmine eq "asm" ) { $mdfile = "$ASMDIR/default/asm.dat"; }
    else { $mdfile="$ETC/${lcmine}.dat"; }
    open (MN, "$mdfile" ) || print "Cannot find mine file: $mdfile";
    while(<MN>)
    {
      chomp;
      if ( ! /SETTINGS/ ||  $GOD ) 
      {
        ($mname, $mid) = split(/\t/, $_); $ACCESSLEVEL=""; $NOTWHOAMI="$proID";
        $ACCESSLEVEL=""; $accessTYPE="$lcmine"; $accessID="$mid"; &determine_access;
    	if ( "$ACCESSLEVEL" eq "ro" ) { $al="Read Only"; }
    	if ( "$ACCESSLEVEL" eq "rw" ) { $al="Read/Write"; }
    	if ( "$ACCESSLEVEL" eq "deny" ) { $al="DENY"; }
    	if ( "$ACCESSLEVEL" eq "admin" ) { $al="Admin"; }
        if ( $lcmine eq "asm" ) { $arg="wp=SETTINGS-ASM"; }
        if ( $lcmine eq "freeform" ) { $arg="act=cfree&FreeID=${mid}&sact=1"; }
        if ( $lcmine eq "knowledgebase" ) { $arg="act=ckbase&kbid=${mid}&from=1"; }
        if ( $lcmine eq "oncall" ) { $arg="act=concall&ID=${mid}&from=1"; }
        if ( $lcmine eq "resource" ) { $arg="act=crlist&ResID=${mid}&from=1"; }
        if ( $lcmine eq "search" ) { $arg="act=crsearch&srchid=${mid}&from=1"; }
        if ( $lcmine eq "task" ) { $arg="act=ctask&taskid=${mid}&sact=1"; }
        if ( $lcmine eq "tracker" ) { $arg="act=modtrk&ID=${mid}"; }
        print qq~
	  <tr><td>&nbsp;&nbsp;&nbsp;<font $fsn><a href=${ITKASM}?${arg} class=\"hoverlink\" style=\"color:$lnkcolor\" title="Go To $mname to change access">$mname</a></ul></font></td>
	  <td><font $fsn>$al</font></td></tr>
        ~;
      }
    }
    close(MN)
  }
	print "</table></td>";

  ###
  ### LIST GROUP ACCESS
  ###
  print qq~
        <!-- DONE LISTING USER ACCESS -->
	<td valign=top><table border=0 width=100% cellpadding=3>
        <tr><td colspan=3 align=center><font fsn><b>Group Access</b></font><br>
        $hr_line
        </td></tr>
~;
  opendir(GRP, "$GRPDIR") or die $!;
  while ($grpfile = readdir(GRP))
  { 
    $gfound="";
    next if ($grpfile =~ m/^\./); 
    open(GPF, "$GRPDIR/$grpfile");
    while (<GPF>) { if ( /^$proID\t/ ) {$gfound="1"; } }
    close(GPF);
    if ($gfound ) 
    { 
        print "<tr><td><font $fsn><b>$grpfile</b></font></td></tr>\n";
    }
  }
  closedir(DIR);
  print qq~ 
	</table>
	<!-- DONE LISTING GROUP ACCESS -->
  ~;
  if ( ! -f "$USERDIR/$form{pro}/lastaccess") { `touch "$USERDIR/$form{pro}/lastaccess"`; }
  open(LACC, "$USERDIR/$form{pro}/lastaccess") || print "ERROR: Cannot read $USERDIR/$form{pro}/lastaccess"; 
  while (<IN>)
  {
    chomp;
    $lastacc="$_";
  }
  close(IN);
  if ( ! -f "$USERDIR/$form{pro}/lastaccess" ) { `touch $USERDIR/$form{pro}/lastaccess`; }
  print qq~
    </td></table>
    </table>
    <p>
    $hr_line
  ~;
}


###
### BUILD A PULLDOWN CONFIGURATION LIST
sub build_pulldown
{
#print "$buffer / $MODFILE<p>";
  # Delete if selected
  if ( $form{del} ) { print ""; $FILE="$MODFILE"; &delete_task_gta; }

  #
  # Add to the list
  #
  if ( "$form{modname}" )
  {
      `touch $MODFILE`;

      # Check if ENTRY is duplicate
      $found="";
      open(LST, "$MODFILE" )|| print "CANNOT FIND $MODFILE";
      while(<LST>) { chomp; if ( /^$form{modname}\t/) { $found="1"; }  }
      close(LST);
      if ( ! "$found" )
      {
        open(LST, ">> $MODFILE" )|| print "CANNOT WRITE $MODFILE";
 	if ( $form{sact} eq "bcklists" ) 
	  { ($bckname="$form{sact}-$form{modname}") =~ s/ /\-/g; $bckname=lc($bckname); print LST "$form{modname}\t$bckname\n"; }
 	elsif ( $form{sact} eq "retlists" ) 
	  { ($retname="$form{sact}-$form{modname}") =~ s/ /\-/g;  $retname=lc($retname);print LST "$form{modname}\t$retname\n"; }
        else { print LST "$form{modname}\n"; }
        close(LST);
	# SORT THE LIST
        tie @LST, 'Tie::File', "$MODFILE" or die;
        @NEWLST=sort @LST;
        @LST=@NEWLST;
        untie(@LST);
      }
  } # End Write group

  ($ltitle,$current) = split(/:/, $sTITLE); 
  if ( "$ltitle" eq "Asset Management" ) { $backlink="<font $fsbl> | <a href=$ITKASM?wp=SETTINGS-ASM class=\"hoverlink\" title=\"Go To Asset Management\" style=\"color:$lnkcolor\">$ltitle</a> | </font>"; }
  else { $backlink="<font $fsb><b>$stitle</b></font>"; $current="";}
  print qq~
        $hr_line
	<table width=100% bgcolor=$hdrcolor cellpadding=3><td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> 
	</font>
        $backlink  <b>$current</b>
	</td></table>
        $hr_line

        <form method=post action=$ITKASM>
        <input type=hidden name=act value=modset>
        <input type=hidden name=sact value=$form{sact}>
	<br>
        <table width=30% border=0 cellpadding=3 cellspacing=0>
        <tr><td align=left colspan=2><font $fsn><b>Name </b></font>
        <select name='modname' onchange='this.form.submit()' title="Select a user">
        <option value="" ></option>
  ~;
  open(USR, "sort -k 3,3 $USERS|");
  while (<USR>)
  {
     chomp;
     ($pUID,$ppp,$pFNAME,$pLNAME) = split(/\t/,$_);
     print "<option value=\"$pUID\">$pFNAME $pLNAME</option>\n";
  }
  close(USR);
  print qq~
        </select>
        <!-- <input type=text size=25 name="modname" value="" title="$iTITLE"> -->
    	<!-- <Input type=submit name=ksave value="Save"> -->
	<br>&nbsp;</td></tr>
        <tr><td colspan=2><hr size=1></td></tr>
  ~;

  $reccnt=0; $cflip="";
  open(BFILE, "$MODFILE" ) || print "CANNOT read dat: $MODFILE";
  while (<BFILE>)
  {
      $reccnt++;
      chomp;
      # EDIT A CHECKLIST HAS 2 FIELDS
      if ( $form{sact} eq "bcklists" || $form{sact} eq "retlists") 
      { 
       ($line, $lfile) = split(/\t/, $_); $cklname=$line; 
	$line="<a href=\"$ITKASM?act=modset&sact=$form{sact}&stitle=${line}&cklfile=$lfile\" class=\"hmverlink\" title=\"Edit ${line}\">$line</a>"; 
      }
      else { $line="$_"; }
      if ( ! $cflip ) { $bgc="$gbxbg1"; $cflip="1"; }
      else { $bgc="$gbxbg2";  $cflip=""; }
     $who="$line"; &get_user_profile;
      print qq~
        <tr><td valign=top bgcolor="$bgc"><font $fsn>$proFNAME $proLNAME </font></td>
        <td bgcolor="$bgc">
          <a href="$ITKASM?act=modset&sact=$form{sact}&del=1&num=$reccnt" title="Delete $cklname"><img src=$IMAGES/trashcan.png height=15 border=0></a>
        </td></tr>
      ~;
  }
  close(BFILE);
  print "</table>\n";
  print "<p>$hr_line";
}

###
### BUILD A CONFIGURATION LIST
sub build_list
{
#print "$buffer / $MODFILE<p>";
  # Delete if selected
  if ( $form{del} ) { print ""; $FILE="$MODFILE"; &delete_task_gta; }

  #
  # Add to the list
  #
  if ( "$form{modname}" )
  {
      `touch $MODFILE`;

      # Check if ENTRY is duplicate
      $found="";
      open(LST, "$MODFILE" )|| print "CANNOT FIND $MODFILE";
      while(<LST>) { chomp; if ( /^$form{modname}\t/) { $found="1"; }  }
      close(LST);
      if ( ! "$found" )
      {
        open(LST, ">> $MODFILE" )|| print "CANNOT WRITE $MODFILE";
 	if ( $form{sact} eq "bcklists" ) 
	  { ($bckname="$form{sact}-$form{modname}") =~ s/ /\-/g; $bckname=lc($bckname); print LST "$form{modname}\t$bckname\n"; }
 	elsif ( $form{sact} eq "retlists" ) 
	  { ($retname="$form{sact}-$form{modname}") =~ s/ /\-/g;  $retname=lc($retname);print LST "$form{modname}\t$retname\n"; }
        else { print LST "$form{modname}\n"; }
        close(LST);
	# SORT THE LIST
        tie @LST, 'Tie::File', "$MODFILE" or die;
        @NEWLST=sort @LST;
        @LST=@NEWLST;
        untie(@LST);
      }
  } # End Write group

  ($ltitle,$current) = split(/:/, $sTITLE); 
  if ( "$ltitle" eq "Asset Management" ) { $backlink="<font $fsbl> | <a href=$ITKASM?wp=SETTINGS-ASM class=\"hoverlink\" title=\"Go To Asset Management\" style=\"color:$lnkcolor\">$ltitle</a> | </font>"; }
  else { $backlink="<font $fsb><b>$stitle</b></font>"; $current="";}
  print qq~
        $hr_line
	<table width=100% bgcolor=$hdrcolor cellpadding=3><td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> 
	</font>
        $backlink  <font $fsb><b>$current</b></font>
	</td></table>
        $hr_line

        <form method=post action=$ITKASM>
        <input type=hidden name=act value=modset>
        <input type=hidden name=sact value=$form{sact}>
	<br>
        <table width=30% border=0 cellpadding=3 cellspacing=0>
        <tr><td align=left colspan=2><font $fsn><b>Name </b></font>
        <input type=text size=25 name="modname" value="" title="$iTITLE">
    	<Input type=submit name=ksave value="Save">
	<br>&nbsp;</td></tr>
        <tr><td colspan=2><hr size=1></td></tr>
  ~;

  $reccnt=0; $cflip="";
  open(BFILE, "$MODFILE" ) || print "CANNOT read dat: $MODFILE";
  while (<BFILE>)
  {
      $reccnt++;
      chomp;
      # EDIT A CHECKLIST HAS 2 FIELDS
      if ( $form{sact} eq "bcklists" || $form{sact} eq "retlists") 
      { 
       ($line, $lfile) = split(/\t/, $_); $cklname=$line; 
	$line="<a href=\"$ITKASM?act=modset&sact=$form{sact}&stitle=${line}&cklfile=$lfile\" class=\"hmverlink\" title=\"Edit ${line}\">$line</a>"; 
      }
      else { $line="$_"; }
      if ( ! $cflip ) { $bgc="$gbxbg1"; $cflip="1"; }
      else { $bgc="$gbxbg2";  $cflip=""; }
      print qq~
        <tr><td valign=top bgcolor="$bgc"><font $fsn>$line</font></td>
        <td bgcolor="$bgc">
          <a href="$ITKASM?act=modset&sact=$form{sact}&del=1&num=$reccnt" title="Delete $cklname"><img src=$IMAGES/trashcan.png height=15 border=0></a>
        </td></tr>
      ~;
  }
  close(BFILE);
  print "</table>\n";
  print "<p>$hr_line";
}

###
### DELETE A PAGE
###
sub delete_page
{
#print "$buffer";
  #
  # DOUBLE CHECK ARE NO KAVES IN THE PAGE
  # (POSSIBLE HACK IF TRIED TO PASTE A PAGE INTO DELETE URL)
  #
  $found="";
  opendir(PGD, "$KPGDIR/$form{pageid}") || die "CANT OPEN PAGEID DIRECTORY: $KPGDIR/$form{pageid}";
  while ( $_ = readdir(PGD))
  {
    if ( ! m/^\./ && /\.dat/ )
    {
#print "$form{pageid} - $KPGDIR/$form{pageid} / $_<br>";
      if ( -s "$KPGDIR/$form{pageid}/$_" ) { $found="1"; }
     }
 }
 close(PGD);
  if ( $found ) { print "<font $fsberr>ERROR: This page ID=$form{pageid} cannot be deleted. Kaves Exists.</font>";exit; }
  # get_page_profile 
  $pageid="$form{pageid}"; &get_page_profile; 
  if ( -f "$KPGDIR/$form{pageid}/$form{pageid}.pro" ) { $PAGELINK="<font $fsbl><a href=\"$ITKASM?act=ckpage&pageid=$pageid\" class=\"hoverlink\" title=\"Back to '$pgname' Page\" style=\"color:$lnkcolor\">$pgname Page</a></font> |"; }
  else { $PAGELINK=""; }
  print qq~
         <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
        <font $fsbl><a href="$ITKASM?wp=SETTINGS-MAIN" class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\" >Settings</a></font>
        <font $fsb> | </font>
        <font $fsbl><a href=$ITKASM?act=listpages class=\"hoverlink\" title="List available Pages" style=\"color:$lnkcolor\">List Pages</a></font> |
        $PAGELINK
        <font $fsbl><a href=$ITKASM?act=ckpage class=\"hoverlink\" title="Create a New Page" style=\"color:$lnkcolor\">Create New Page</a></font>
        <font $fsb> | </font>
	<font $fsb><b>Delete $pgname</b></font>
        </td>
        </table>
        $hr_line
  ~;

  if ( ! $form{con} )
  {
    print qq~
    <p>&nbsp;
    <center>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
       <tr>
      <tr><td align=center colspan=2><font $fsb>Confirm deletion of the Page</font><p>
	<font $fsberr><b>$pgname</b></font><br>
	<font $fsberr>$pgdesc</font><p>
	$hr_line
      <tr><td align=center>
      <form method=post action=$ITKASM>
      <input type=hidden name="act" value="delpage">
      <input type=hidden name="pageid" value="$form{pageid}">
      <input type=hidden name="con" value="confirm">
      <input type=submit value="CONFIRM">
      </form>
	</td><td align=center>
      <form method=post action=$ITKASM>
      <input type=hidden name="act" value="ckpage">
      <input type=hidden name="pageid" value="$form{pageid}">
      <input type=submit value="CANCEL">
      </form>
	</td></tr>
      </td> </tr>
     </table>
     </td></table>
     </center>
    ~;
  }
  elsif ( $form{con} eq "confirm" )
  {
    #
    # DELETE PAGE ENTRY
    #
    $results="";
    if ( -d "$KPGDIR/$form{pageid}" && $form{pageid}) { $results = system("rm -rf $KPGDIR/$form{pageid}"); }
    if ( $results == 0) 
    {
      # REMOVE THE PAGE FROM THE INDEX FILE
      @LST=(); @NEWLST=();
      tie @LST, 'Tie::File', "$ITKASMPAGE" or die;
      foreach (@LST)
      { if ( ! /\t$pageid/) { push(@NEWLST, "$_"); } }
      @LST=@NEWLST;
      untie(@LST);

      # REMOVE THE PAGE FROM THE TABS INDEX FILE
      @LST=(); @NEWLST=();
      tie @LST, 'Tie::File', "$ETC/itkasmpage-tabs.dat" or die;
      foreach (@LST)
      { if ( ! /\t$pageid/) { push(@NEWLST, "$_"); } }
      @LST=@NEWLST;
      untie(@LST);

      # REMOVE THE PAGE FROM THE VISITORS TABS INDEX FILE
      @LST=(); @NEWLST=();
      tie @LST, 'Tie::File', "$ETC/itkasmpage-visitor.dat" or die;
      foreach (@LST)
      { if ( ! /\t$pageid/) { push(@NEWLST, "$_"); } }
      @LST=@NEWLST;
      untie(@LST);

      print qq~
      <p>&nbsp;
      <center>
      <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
      <td>
        <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
         <tr>
        <tr><td align=center colspan=2><font $fsb><b>$pgname</b><br>has been deleted</font><p>
          $hr_line
        </td> </tr>
        <tr><td align=center>
          <form method=post action=$ITKASM>
          <input type=hidden name="act" value="listpages">
          <input type=hidden name="con" value="done">
          <input type=submit value="CONTINUE">
          </form>
        </td></tr>
       </table>
       </td></table>
       </center>
      ~;
    }
    else
    { 
      print qq~
        <p>&nbsp;
        <center>
        <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
        <td>
          <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
           <tr>
          <tr><td colspan=2><font $fsberr><center>
      	    Could not Delete Page ($form{pageid}). Possible issues: <p>Permission or already deleted
	    </center></font><font $fsb>
	    <p>If issues persist: <br>
 		1. '$KPGDIR/$form{pageid}' should be deleted<br>
	    	2. $form{pageid} should be removed from $ITKASMPAGE<p>
            </font><p>
          </td> </tr>
       </table>
       </td></table>
       </center>
    ~;
    }
  }
}

###
### DELETE A MINE
###
sub delete_mine
{
#print "$buffer";
  # get_kave_profile returns $ERRORLOG if there is problem
  $mineid="$form{mineid}"; $minetype="$form{minetype}"; &get_mine_profile; 
  $MINETYPE = ucfirst($minetype);
  @HIDname=();@HIDval=();
  if ( $minetype eq "tracker" ) { 
	$LARGS="act=listtrk"; $CONT="listtrk"; $MARGS="act=modtrk&ID=$mineid"; 
	@HIDname=("act","ID"); @HIDval=("modtrk","$form{mineid}"); }

  if ( $minetype eq "freeform" ) { 
	$LARGS="act=listfree"; $CONT="listfree"; $MARGS="act=cfree&FreeID=$mineid&sact=1"; 
	@HIDname=("act","FreeID","sact"); @HIDval=("cfree","$form{FreeID}","1"); }

  if ( $minetype eq "oncall" ) { 
	$LARGS="act=listoc"; $CONT="listoc"; $MARGS="act=concall&ID=$mineid&from=1"; 
	@HIDname=("act","ID","from"); @HIDval=("concall","$form{ID}","1"); }

  if ( $minetype eq "resource" ) { 
	$LARGS="act=listres"; $CONT="listres"; $MARGS="act=crlist&ResID=$mineid&from=1"; 
	@HIDname=("act","ResID","from"); @HIDval=("crlist","$form{ResID}","1"); }

  if ( $minetype eq "search" ) { 
	$LARGS="act=listsearch"; $CONT="listsearch"; $MARGS="act=crsearch&srchid=$mineid&from=1"; 
	@HIDname=("act","srchid","from"); @HIDval=("crsearch","$form{srchid}","1"); }

  if ( $minetype eq "task" ) { 
	$LARGS="act=listtsk"; $CONT="listtsk"; $MARGS="act=ctask&taskid=$mineid&sact=1"; 
	@HIDname=("act","taskid","sact"); @HIDval=("ctask","$form{taskid}","1"); }


  if ( -f "$DPATH/$minetype/$mineid/${mineid}.pro" ) { $MINELINK="<font $fsbl><a href=\"$ITKASM?act=delmine&mineid=$mineid&from=1\" class=\"hoverlink\" title=\"Back to '$minename' Kave\" style=\"color:$lnkcolor\">$minename Mine</a></font> |"; }
  else { $MINELINK=""; }
  print qq~
         <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
        <font $fsbl><a href="$ITKASM?wp=SETTINGS-MAIN" class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\" >Settings</a></font>
        <font $fsb> | </font>
        <font $fsbl><a href=\"${ITKASM}?${LARGS}\" class=\"hoverlink\" title="List available Mines" style=\"color:$lnkcolor\">List $MINETYPE</a></font> |
        $KAVELINK
        <font $fsbl><a href=\"${ITKASM}?${MARGS}\" class=\"hoverlink\" title="Go to '$minename'" style=\"color:$lnkcolor\">$minename</a></font>
        <font $fsb> | </font>
	<font $fsb><b>Delete $minename</b></font>
        </td>
        </table>
        $hr_line
  ~;

  if ( ! $form{con} )
  {
    print qq~
    <p>&nbsp;
    <center>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
       <tr>
      <tr><td align=center colspan=2><font $fsb>Confirm deletion of the Mine</font><p>
	<font $fsberr><b>$minename</b></font><br>
	<font $fsberr>$minedesc</font><p>
	$hr_line
      <tr><td align=center>
      <form method=post action=$ITKASM>
      <input type=hidden name="act" value="delmine">
      <input type=hidden name="mineid" value="$form{mineid}">
      <input type=hidden name="minetype" value="$form{minetype}">
      <input type=hidden name="con" value="confirm">
      <input type=submit value="CONFIRM">
      </form>
	</td><td align=center>
      <form method=post action=$ITKASM>
     ~;
     $cnt=0;
     foreach $h (@HIDname)
     {
        print "<input type=hidden name=\"@HIDname[$cnt]\" value=\"@HIDval[$cnt]\">\n";
        $cnt++;
     }
     print qq~
      <input type=submit value="CANCEL">
      </form>
	</td></tr>
      </td> </tr>
     </table>
     </td></table>
     </center>
    ~;
  }
  elsif ( $form{con} eq "confirm" )
  {
    #
    # DELETE MINE ENTRY
    #
    $success="";
    if ( -d "$DPATH/$minetype/$mineid") 
    {  
      # ARCHIVE THE DATA
      if ( ! "$DPATH/archive/$minetype" ) { `mkdir -p $DPATH/archive/$minetype`; }
      `mkdir -p $DPATH/archive/$minetype/$mineid`; 
      #print "<p>mkdir -p $DPATH/archive/$minetype/$mineid"; 
      `mv $DPATH/$minetype/$mineid $DPATH/archive/$minetype/`; 

      # REMOVE THE MINE FROM THE INDEX FILE
      @LST=(); @NEWLST=();
      tie @LST, 'Tie::File', "$ETC/${minetype}.dat" or die;
      foreach (@LST)
      {
        if ( ! /\t$mineid/)
        {
           push(@NEWLST, "$_");
        }
      }
      @LST=@NEWLST;
      untie(@LST);
 
       $success="1";
      
    }
    if ( ! $success ) 
    { 
      print qq~
        <p>&nbsp;
        <center>
        <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
        <td>
          <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
           <tr>
          <tr><td align=center colspan=2><font $fsberr>
      	    Could not Delete Mine. Possible issues: <p>Permission or already deleted
            </font><p>
          </td> </tr>
       </table>
       </td></table>
       </center>
    ~;
    }
    else
    {
      print qq~
      <p>&nbsp;
      <center>
      <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
      <td>
        <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
         <tr>
        <tr><td align=center colspan=2><font $fsb><b>$minename</b><br>has been archived</font><p>
          $hr_line
        </td> </tr>
        <tr><td align=center>
          <form method=post action=$ITKASM>
          <input type=hidden name="act" value="$CONT">
          <input type=submit value="CONTINUE">
          </form>
        </td></tr>
       </table>
       </td></table>
       </center>
      ~;
    }
  }
}

###
### LIST KAVES THAT HAVE DEFINED MINES
###
sub list_kaves_def
{
    print qq~
	<!-- LIST KAVES THAT HAVE DEFINED MINES -->
	<table border=0 width=100% cellpadding=3>
	<td valign=top align=center width=33%>
	<table border=0 >
        <tr>
          <td valign=top align=left nowrap>
	  <font $fsn><b>Kaves Defined:</b></font>
	  </td><td valign=top align=left no wrap>
      ~;
      $cant_delete="None"; 
      #
      # GET ITKASM PAGES THAT THE KAVE IS PUBLISHED IN
      #
          opendir(KAV, "$KAVES") || die "CANT OPEN DIRECTORY: $KAVES";
          while ( $_ = readdir(KAV))
          {
            if ( ! m/^\./ && /\.pro/)
            {
              chomp;
              $profile="$_";
              ($kaveid, $value) = split(/\./, $profile);
#print "- $profile / $kaveid<br>";
	      # GET ALL KAVE PROFILES 
 	      open(KFILE, "$KAVES/$profile") || print "CANNOT OPEN $KAVES/$profile";
	      while (<KFILE>)
	      {
		if (/$mineid/) 
    		{
		  &get_kave_profile;
 		  print "<font $fsnl><a href=\"$ITKASM?act=ckave&kaveid=$kaveid&from=kavelist\" class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"Go to '${kavename}' KAVE to remove Mine\">$kavename</a></font><br>";
		  $cant_delete="";
		}
	      }
	      close(kFILE);
	    }
 	  }
	  close(KAV);
      print "<font $fserr>${cant_delete}</font></td>\n";
     ###
     ### MAKE SURE A SETTING MINE CANNOT BE DELETED
     ###
     if ( "${minename}" =~ "SETTINGS" || "${minename}" =~ "Vendors" || "${minename}" =~ "Operations Activity" ) {  }
     else 
     { 
      if ( ! $cant_delete ) 
      { 
	 print "<td valign=top >&nbsp;&nbsp;&nbsp;&nbsp;<img src=$IMAGES/trashcan-x.png height=20 title=\"Remove '${minename}' from all KAVES to delete this Mine.\"></td>\n";
      }
      else
      {
 	print qq~
	  <td valign=top>&nbsp;&nbsp;&nbsp;&nbsp;
 	    <a href=\"$ITKASM?act=delmine&mineid=${mineid}&minetype=$minetype\" class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"Delete '$minename' forever\"><img src=$IMAGES/trashcan.png border=0 height=20 title=\"Delete '$minename' forever\">
	  </td>
	~;
      } 
     }
      print qq~ 
	</table> 
	</tr>
	<tr><td colspan=3>$hr_line</td><tr>
        </td> </table>
       ~;
}


###
### DISPLAY A SETTING TO MODIFY
###
sub modify_setting
{
#print "$buffer";
   $freeform="";
   $MODFILE=""; $CMDB=""; $width=200;

   if ( $form{sact} eq "itkasmpage" ) 
	{ $MODFILE="$ITKASMPAGE"; $sTITLE="IT KASMS Page"; } 
   elsif ( $form{sact} =~ "itkasmpage\-" ) 
	{ $MODFILE="$ETC/$form{sact}"; $sTITLE="IT KASM $form{sact} Page"; $freeform=1; } 

   elsif ( $form{sact} eq "settings" ) 
	{ $MODFILE="$ETC/settings.dat"; $sTITLE="Config Settings"; $freeform=1;} 

# ASSET MANAGEMENT

   elsif ( $form{sact} eq "bcklists" && ! $form{cklfile} ) 
	{ $MODFILE="$ASMDIR/default/bcklists"; $sTITLE="Asset Management: Build Checklist"; $iTITLE="Create Build Checklists"; build_list; exit;} 
   elsif ( $form{sact} eq "bcklists" && $form{cklfile} ) { $MODFILE="$ASMDIR/default/$form{cklfile}"; $sTITLE="$form{stitle} Checklist"; $rbTITLE="Build Checklists"; $iTITLE="$sTITLE"; $BCKLISTS=1; } 

   elsif ( $form{sact} eq "retlists" && ! $form{cklfile} ) 
	{ $MODFILE="$ASMDIR/default/retlists"; $sTITLE="Asset Management: Retire Checklist"; $iTITLE="Create Retire Checklists"; build_list; exit;} 
   elsif ( $form{sact} eq "retlists" && $form{cklfile} ) { $MODFILE="$ASMDIR/default/$form{cklfile}"; $sTITLE="$form{stitle} Checklist"; $rbTITLE="Retire Checklists"; $RETLISTS=1; $iTITLE="$sTITLE";} 


   elsif ( $form{sact} eq "asm.status" ) 
	{ $MODFILE="$ASMDIR/default/asm.status"; $sTITLE="Asset Management: Status"; $iTITLE="Device Operational Status"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.dept" ) 
	{ $MODFILE="$ASMDIR/default/asm.dept"; $sTITLE="Asset Management: Departments"; $CMDB="1"; $iTITLE="Departments that own devices"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.loc" ) 
	{ $MODFILE="$ASMDIR/default/asm.loc"; $sTITLE="Asset Management: Location"; $CMDB="1"; $iTITLE="Where devices are located"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.ploc" ) 
	{ $MODFILE="$ASMDIR/default/asm.ploc"; $sTITLE="Asset Management: Room Location"; $CMDB="1"; $iTITLE="Device Physical Location"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.domains" ) 
	{ $MODFILE="$ASMDIR/default/asm.domains"; $sTITLE="Asset Management: Domains"; $CMDB="1"; $iTITLE="Domains devices are in"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.devices" ) 
	{ $MODFILE="$ASMDIR/default/asm.devices"; $sTITLE="Asset Management: Devices"; $CMDB="1"; $iTITLE="Types of Devices"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.os" ) 
	{ $MODFILE="$ASMDIR/default/asm.os"; $sTITLE="Asset Management: Operating Systems"; $CMDB="1"; $iTITLE="Operating System Type"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.patchg" ) 
	{ $MODFILE="$ASMDIR/default/asm.patchg"; $sTITLE="Asset Management: Patch Groups";$CMDB="1"; $iTITLE="Defined patch groups"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.flavor" ) 
	{ $MODFILE="$ASMDIR/default/asm.flavor"; $sTITLE="Asset Management: Flavors"; $CMDB="1"; $iTITLE="Specific types of OS Flavors"; build_list; exit;} 
   elsif ( $form{sact} eq "asm.type" ) 
	{ $MODFILE="$ASMDIR/default/asm.type"; $sTITLE="Asset Management: Type"; $CMDB="1"; $iTITLE="Device Type: Physical, Virtual, Mfg, etc..."; build_list; exit;} 
   elsif ( $form{sact} eq "asm.bltby" ) 
	{ $MODFILE="$ASMDIR/default/asm.bltby"; $sTITLE="Asset Management: Built By"; $CMDB="1"; $iTITLE="Device Builders"; build_pulldown; exit;} 
   elsif ( $form{sact} eq "attention" ) 
	{ $MODFILE="$ATTENTION"; $sTITLE="Alert Banner"; build_list; exit;} 
   # Write out setting mod if an update exists

   if ( $form{updset} ) 
   {
     $form{updset} =~ s/\|/\t/g;
     #$form{updset} =~ s/\r\n/\n/g;

     open(OUT, "> $MODFILE" ) || print "Cannot write $MODFILE";
     #print "<pre>$form{updset}</pre>";
     print OUT "$form{updset}";
     close(OUT);
     $message="[${WHOAMI}]\tIT KASM Settings $sTITLE\tChanged List of entries"; &write_log;
   }


   if ( $MODFILE )
   {
    $SUBMENU="";
    if ( $form{cklfile} ) { $SUBMENU="<font $fsbl><a href=\"$ITKASM?wp=SETTINGS-ASM\" class=\"hoverlink\" title=\"Go To Asset Management Settings\" style=\"color:$lnkcolor\">Asset Management</a> | <a href=\"$ITKASM?act=modset&sact=$form{sact}\" class=\"hoverlink\" title=\"Go to $rbTITLE\" style=\"color:$lnkcolor\">$rbTITLE</a> |</font> "; }
    print qq~
   	$hr_line
	<table width=100% bgcolor=$hdrcolor cellpadding=3 border=0><td>
    	<font $fsbl>
	<a href="$ITKASM?wp=SETTINGS-MAIN" class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> | 
	</font>
        $SUBMENU
	<font $fsb><b>$iTITLE</b></font></td></table>
    	$hr_line
        <form method=post action=$ITKASM>
        <input type=hidden name="act" value="modset">
        <input type=hidden name="sact" value="$form{sact}"> 
        <input type=hidden name="cklfile" value="$form{cklfile}"> 
     ~;
     $line="";
     $nobrk="";  
     if ( ! -s "$MODFILE" ) { `touch $MODFILE`; }
     if ( ! -s "$MODFILE" && "$BCKLISTS" && -f "$ASMDIR/default/bcklists-template.dat" ) { `cp $ASMDIR/default/bcklists-template.dat $MODFILE`; }
     if ( ! -s "$MODFILE" && "$RETLISTS" && -f "$ASMDIR/default/retlists-template.dat" ) { `cp $ASMDIR/default/retlists-template.dat $MODFILE`; }
     if ( "$BCKLISTS" ) { &display_checklist; }
     if ( "$RETLISTS" ) { &display_checklist; }
     open(IN, "$MODFILE") || print "ERROR: CANNOT OPEN $MODFILE";
     while(<IN>)
     {
       chomp;
       print "<font $fsn>";  

       if ( "$form{sact}" eq "admins" ) 
       {
         ($mID, $mNAME,$mPHONE,$mTEXT,$mEMAIL) = split(/\t/, $_);
         print "$mNAME<br>\n";
         $line="${line}$mID|$mNAME|$mPHONE|$mTEXT|$mEMAIL\n";
         $tboxdesc="<b>Syntax:</b> [Admin_ID]|[Full_Name]|[Cellphone]|[Text_Address]<br>List is deliminated by a \"|\" vertical bar.";
       }
       elsif( "$form{sact}" eq "oncall" )
       {
         ($mSDATE,$mDASH,$mEDATE,$mCOLON,$mID) = split(/ /, $_);
         print "$_<br>\n";
         $line="${line}$_\n";
         $tboxdesc="<b>Syntax:</b>  [Start_Date] - [End_Date] : [Admin_ID]";
       }
       elsif ( "$freeform" )
       {
         #s/\t/|/g;
         $line="${line}$_\n";
         $tboxdesc="Freeform writing: Enter anything";
       }
       elsif ( "$BCKLISTS" || "$RETLISTS" )
       {
         s/\t/|/g;
         $line="${line}$_\n";
         $tboxdesc="<font $fsn>This is a freeform text box with embedded commands to create a Checklist. <i>Checkboxes are not active here, but are active in a device profile</i><p><b><u>Checkbox Syntax</u><br></b>xx[unique number]:0|description<p>xx denotes a checkbox<br>A unique number as an identifier<br>:0 represents unchecked box<br>'|' represents a tab delimiter followed by description<p>%%%DEVICENAME%%% gets replaced with the device name<p>Basic HTML is allowed</font>";

       }
       else
       {
         if ( "$CMDB" ) 
         {
           print "$_<br>\n";
           $line="${line}$_\n";
           $tboxdesc="List all the names that will appear in the Profile to pulldown";
         }
         else 
         {
	   $mURL="";$mNAME="";
           ($mNAME, $mURL) = split(/\t/, $_);
  	   # go horizontal
	   if ( /\[/ &&  /\]/ && ! /\[end\]/i ) 
	   { 
           	$line="${line}$_";
		$nobrk="1"; s/\[//g; s/\]//g; 
                $_ =~ s/\r//g;
                $ccc=length($_);
                if ( $ccc eq 1 ) {print "";}
                elsif ( $_ ) { print "<b>$_:</b> \n";}
		@hline="";
	   }
	   elsif ( /\t/ ) 
	   {
           	  $line="${line}$mNAME|$mURL\n";
             	  $h = "<a href=\"$mURL\" class=\"hoverlink\" target=\"_set\" >$mNAME</a>\n";
		  push(@hline, $h);
		  if ( ! $nobrk ) 
		  { 
             	  	print "<a href=\" $mURL\" class=\"hoverlink\" target=\"_set\" >$mNAME</a><br>\n";
		  }

  	   }
	   elsif ( /\[end\]/i ) 
	   { 
		if ( $nobrk ) 
		{ 
		  $cntr=0; $acnt=scalar @hline;
		  foreach $U (@hline)
		  {
		     $cntr++;
 		     print "$U";
		     if ( $cntr ne $acnt && $cntr ne 1  ) { print " | "; }
		  }
		  $nobrk=""; print "<br>";
		}
		if ( ! /\[end\]/i) { print "$_<br>\n"; }
		$line="${line}$_\n"; 
	   }
	   else 
	   { 
	     $line="${line}$_\n"; 
	     $_ =~ s/\r//g;
	     if  ( ! "$_" ) { print "$_<p>\n";  }
	   }

           $tboxdesc="List the item deliminated with a \"|\" vertical bar, then URL. <b>Syntax:</b> [Item]|[URL]";
         }
       }
     }
     close(IN);
     print "</font>";
     $showupdate="";
     if ($form{updset}) { $showupdate="<font $fserr></i>... $sTITLE Updated ...</i></font><br>"; }
     if ( $sTITLE eq "Extras" && $form{sact} ne "extras") 
     {
       print qq~
	<p>
	<center><b>
	%%%set${sTITLE}.$form{sact}:box-color=$sTITLE,black,lightblue,0,200,eeead6,0
	</center></b>
       ~;
     }
     print qq~
        $hr_line
     <table border=0 cellpadding=3>
     <td valign=top><textarea rows=15 cols=100 name=updset wrap="off">$line</textarea></td>
     <td valign=top>$tboxdesc</td>
     </table>
    <p>$showupdate
    <p> <Input TYPE="submit" VALUE="Update $sTITLE">
     </td></tr>
     </td>
     </table>
     ~;
   }    
}




###
### Modify Tracker that was Created
###
sub mod_tracker
{
#print "$buffer<p>";
  #
  # IF updated, write out change
  #
  $TrackerID="$form{ID}";
  if( $form{upd} )
  {
    open(TRKD, "> $TRKDIR/$TrackerID/${TrackerID}.pro" ) || print "CANNOT write: $TRKDIR/$TrackerID/${TrackerID}.pro";
    print TRKD "id\t$TrackerID\n";
    print TRKD "name\t$form{trckname}\n";
    print TRKD "desc\t$form{trckdesc}\n";
    print TRKD "recname\t$form{recname}\n";
    print TRKD "recnum\t$form{recnum}\n";
    print TRKD "dsplst\t$form{dsplst}\n";
    print TRKD "rechide\t$form{rechide}\n";
    print TRKD "wopsact\t$form{wopsact}\n";
    #print "id\t$TrackerID<br>\n";
    #print "name\t$form{trckname}<br>\n";
    for ($c=0; $c < $form{trcknum}; $c++)
    {
        print TRKD "field\t";
        #print "field - ";
        foreach $pair (@pairs)
        {
          ($name, $value) = split(/=/, $pair);
          $value =~ tr/+/ /;
          if ( $name eq $c )
          {
             if ( $value =~ "%25" ) { ($val,$d)=split(/%/,$value); $value="${val}%"; }
             print TRKD "$value\t";}
             #print "$value - ";}
        }
        print TRKD "\n";
        #print "<br>";
    }
    close(TRKD);
    open(TRKD, "> $TRKDIR/$TrackerID/${TrackerID}.cmt" ) || print "ERROR: CANNOT write: $TRKDIR/$TrackerID/${TrackerID}.cmt";
    print TRKD "$form{trckcom}";
    close(TRKD);

  }

  print qq~
    	<form method=post action=$ITKASM>
    	<input type=hidden name=act value=modtrk>
    	<input type=hidden name=ID value="$form{ID}">
    	<input type=hidden name=upd value=1>
  ~;
  #
  #  modify tracker settings
  #
  if ( $form{act} eq "modtrk" )
  {
#print  "*** $TRKDIR/$TrackerID/${TrackerID}.pro<p>";
    if ( -f "$TRKDIR/$TrackerID/${TrackerID}.pro" ) 
    {
      open(TRKDNUM, "$TRKDIR/$TrackerID/${TrackerID}.num" ) || print "Cannot open $TRKDIR/$TrackerID/${TrackerID}.num";
      while (<TRKDNUM>)
      {
	chomp;
        $recnum="$_";
      }
      close(TRKDNUM);
      @TFIELDS=();
      open(TRKD, "$TRKDIR/$TrackerID/${TrackerID}.pro" ) || print "Cannot open $TRKDIR/$TrackerID/${TrackerID}.pro";

      while (<TRKD>)
      {
	chomp;
	if ( /^id\t/ )  { ($d, $ID) = split (/\t/, $_);	}
	if ( /^name\t/ ) { ($d, $trckname) = split (/\t/, $_);	}
	if ( /^desc\t/ ) { ($d, $trckdesc) = split (/\t/, $_);	}
	if ( /^recname\t/ ) { ($d, $recname) = split (/\t/, $_);	}
	if ( /^recnum\t/ ) { ($d, $recnum) = split (/\t/, $_);	}
	if ( /^dsplst\t/ ) { ($d, $dsplst) = split (/\t/, $_);	}
	if ( /^rechide\t/ ) { ($d, $rechide) = split (/\t/, $_);	}
	if ( /^wopsact\t/ ) { ($d, $wopsact) = split (/\t/, $_);	}
        if ( /^field\t/) { push(@TFIELDS, $_); }
      }
      close(TRKD);
      #
      # Get comment
      #
      $trckcom="";
      open(TRKD, "$TRKDIR/$TrackerID/${TrackerID}.cmt" ) || print "Cannot open $TRKDIR/$TrackerID/${TrackerID}.cmt";
      while (<TRKD>) { chomp; $trckcom = "${trckcom}$_\n"; }
      close(TRKD);

      $tfields= @TFIELDS;
      #if ( ! $recname ) { $recname="REC"; }
      #if ( ! $recnum ) { $recnum=10000; }
      if ( $dsplst eq "n" || ! $dsplst ) { $ndsplst="checked"; $rdsplst=""; }
      else { $ndsplst=""; $rdsplst="checked"; }
      if ( $rechide eq "y" ) { $ychecked="checked"; $nchecked=""; }
      else { $ychecked=""; $nchecked="checked"; }
      if ( $wopsact eq "y" ) { $ywoa="checked"; $nwoa=""; }
      else { $ywoa=""; $nwoa="checked"; }
      if ( $TrackerID ) 
      {
        $CRTUPD="Update";
        $CRTLINK="<font $fsbl> | <a href=$ITKASM?act=ctracker class=\"hoverlink\" title=\"Create Tracker Mine\" style=\"color:$lnkcolor\">Create Tracker</a></font>";
      } 
      else { $CRTUPD="Create"; $CRTLINK=""; }
      print qq~
        $hr_line
        <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
    	<font $fsbl>
	<a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> | 
	<a href=$ITKASM?act=listtrk class=\"hoverlink\" title="List available Tracker Mines" style=\"color:$lnkcolor\">List Trackers</a> | 
	</font><font $fsb>
	<b>$CRTUPD Tracker</b>
	</font>
        $CRTLINK
        <font $fsbl>
	| <a href=$ITKASMTRCK?ID=$form{ID} class=\"hoverlink\" title="Go To $trckname Tracker" target="test" style=\"color:$lnkcolor\">$trckname</a>  
	</font>
        </td><td align=right ><font $fsbl>
	Step 2: <a href=$ITKASM?act=ckave&kid=tracker:$form{ID} class=\"hoverlink\" style=\"color:$lnkcolor\">Create a KAVE</a>
	</font></td></table>
        $hr_line
	<!-- <table width=100% border=1> -->
        <!-- <td align=right><b>KAVE CODE:</b> %%%tracker:$form{ID}:$trckname</td> -->
        <!-- </table>  -->
        <table border=0 width=100%>
        <td>
    	<font $fsn>Tracker Title: </font><font $fsb><b>$trckname</b></font><p>
    	<font $fsn><b>Tracker Description: </b>
    <input type=text size=40 name="trckdesc" value="$trckdesc"><p>
	<font $fsn><b>Tracker ID: </b> $ID<p>
    	<font $fsn><b>Number Fields: </b>$tfields</font><p>
	<font $fsn><b>Record Name:</b> $recname</font>
    	<input type=hidden name=recname value="$recname">
	&nbsp; &nbsp;
	<font $fsn><b>Starting Number:</b> $recnum</font>
    	<input type=hidden name=recnum value="$recnum">
      ~;
      if ( $TrackerID eq "vendors" ) {  print "<input type=hidden name=rechide value=\"y\">"; }
      else 
      {
      print qq~
	&nbsp; &nbsp; &nbsp;
	<font $fsn><b>Hide: </b>
        <input type="radio" name="rechide" value="y" $ychecked> Yes / 
        <input type="radio" name="rechide" value="n" $nchecked> No 
      ~;
      }
      print qq~
	<p>
        <font $fsn><b>Display List:</b> </font>
                <input type="radio" name="dsplst" value="n" $ndsplst> Normal /
                <input type="radio" name="dsplst" value="r" $rdsplst> Reverse
        <p>
	<font $fsn><b>Update Operations Activities:</b>
        <input type="radio" name="wopsact" value="y" $ywoa> Yes / 
        <input type="radio" name="wopsact" value="n" $nwoa> No 
 	</font>


    	<input type=hidden name=trckname value="$trckname">
    	<input type=hidden name=trcknum value="$tfields">
	<p>
    <font $fsn><b>Comments:</b></font><br>
    <textarea rows=4 cols=80 name=trckcom wrap="on">${trckcom}</textarea><p>
	      <table cellspacing=0 cellpadding=3 border=0>
	      <tr>
              <td align=center><font $fsn><b>Field Name</b></font>$hr_line</td>
              <td align=center><font $fsn><b>Width</b></font> $hr_line</td>
              <td align=center><font $fsn><b>Type</b></font> $hr_line</td>
              <td align=center><font $fsn><b>Alignment</b></font> $hr_line</td>
              <td align=center><font $fsn><b>Wrapping</b></font> $hr_line</td>
              <td align=center><font $fsn><b>NewLine</b></font> $hr_line</td>
    </td>
              </tr>

      ~;
    @TRtype= ("text","number","email","datetime-local","date","time","phone","address");
    @TRtypeD=("Text","Number","Email","Date/Time","Date","Time","Phone","Address");

    for ($c=0; $c < $tfields; $c++)
      {
        ($Tf, $Tfn, $Twd,$Tty, $Tal,$Twr,$Tbr) = split(/\t/, $TFIELDS[$c]);
	print qq~
	  <tr>
	  <td><input type=text size=20 name="$c" value="$Tfn"></td>
	  <td><input type=text size=5 name="$c" value="$Twd"></td>
        <td><select name="$c">
        ~;
 	$tc=0;
        foreach $t (@TRtype)
 	{
	  if ( "$t" eq "$Tty" ) { $selected="selected"; }
	  else { $selected=""; }
	  print qq~

	    <option $selected value="$TRtype[$tc]">$TRtypeD[$tc]</option>
	  ~;
	  $tc++;
      	}
        print qq~
        </select></td>
        <td><select name="$c">
        ~;

    @TRal=("left","center","right");
    @TRalD=("Left","Center","Right");

 	$tc=0;
        foreach $t (@TRal)
 	{
	  if ( "$t" eq "$Tal" ) { $selected="selected"; }
	  else { $selected=""; }
	  print qq~
	    <option $selected value="$TRal[$tc]">$TRalD[$tc]</option>
	  ~;
	  $tc++;
      	}
        print qq~
        </select></td>
        <td><select name="$c">
        ~;

    @TRwr=("wrap","nowrap");
    @TRwrD=("Wrap","No Wrap");

 	$tc=0;
        foreach $t (@TRwr)
 	{
	  if ( "$t" eq "$Twr" ) { $selected="selected"; }
	  else { $selected=""; }
	  print qq~
	    <option $selected value="$TRwr[$tc]">$TRwrD[$tc]</option>
	  ~;
	  $tc++;
      	}
	print qq~
          </select></td>
          <td><select name="$c">
        ~;

    @TRbrk=("no","yes");
    @TRbrkD=("No","Yes");

 	$tc=0;
        foreach $t (@TRbrk)
 	{
	  if ( "$t" eq "$Tbr" ) { $selected="selected"; }
	  else { $selected="No"; }
	  print qq~
	    <option $selected value="$TRbrk[$tc]">$TRbrkD[$tc] </option>
	  ~;
	  $tc++;
      	}
	print qq~
          </select></td>
	  </tr>
	~;
      }
      print qq~  
	</table><p> $hr_line
      ~;
      if ( $form{upd}) { print "<font $fserr>Tracker Updated...<p></font>";}
      print qq~
    	<Input type=submit value="Update Tracker">
	</form>

      </td>
  <!--    <td>
	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
      </td> -->
      <td valign=top width=40%> 
    ~;
    
    # SHOW KAVES DEFINED FOR MINE
    $mineid="$TrackerID"; $minename="$trckname"; 
    $MINEDIR="$TRKDIR/$TrackerID"; $minetype="tracker";
    list_kaves_def;
    if ( $TrackerID ) 
    {
      @MINEARGS=("act=modtrk", "ID=$TrackerID");
      &mine_access;
    }
    print qq~
      </td>
      </table>
      ~;
    } #profile

  } #modtrk 

}



###
### Get the number of records to display
###
sub number_records
{
   if ( ! $form{knrec} ) { $form{knrec}="5"; }
   print qq~
	<tr><td align=right><font $fsn><b>Display Number Records:</b></font></td><td>
        <select name='knrec' onchange='this.form.submit()'>
     ~;
    open(RNUM, "$ETC/settings-recnumbers.dat") || print "CANNOT OPEN $ETC/settings-recnumbers.dat";
    while (<RNUM>) 
    {
	chomp;
	  if ( "$form{knrec}" eq "$_" ) { $selected="selected"; }
	  else { $selected=""; }
          print "<option value=\"$_\" $selected>$_</option>\n";
      
    }
    close(RNUM);
    print "</select></td></tr>";
}




###
### Select the type of kave to create
###
sub select_kavetype
{
#print "$buffer";
  #
  # Select the type of kave to create
  #

  #
  # ON-CALL
  #
  if ( "$form{ktype}" eq "oncall" )
  {
     #
     # GET THE OCDISPLAY
     #
     if ( -s "$KAVES/$form{kaveid}.pro")
     {
        open(FLD, "$KAVES/$form{kaveid}.pro" );
        while (<FLD>)
        { chomp; if ( /^ocdisp\t/) { ($f1, $kbtype)= split(/\t/, $_); } }
        close(FLD);
     }
     print qq~
      <tr><td align=right><font $fsn><b>Select an On-Call Mine:</font></b></td>
      <td>
        <select name='ktypeid' onchange='this.form.submit()'>
        <option value=\"\" $selected></option>
     ~;

     #
     # PICK A ONCALL TO BUILD A KAVE AROUND
     #
     open(ONC, "$ONCALL") || print "Cannot find $ONCALL";
     while (<ONC>)
     {
        chomp;
        ($kbtitle, $ktypeid) = split(/\t/, "$_");
        if ( "$form{ktypeid}" eq "$ktypeid" ) { $selected="selected"; }
        else { $selected=""; }
        print "<option value=\"$ktypeid\" $selected>$kbtitle</option>\n";
     }
     close(ONC);
     print "</td></tr>\n";
    # DISPLAY HORIZONTAL OR VERTICLE
    print "<tr><td align=right valign=top><b><font $fsn>Display:</font></b></td><td>\n";
    if ( $form{ocdisp} eq "horizontal" ) { $selectedh="selected"; $selectedv=""; }
    else { $selectedv="selected"; $selectedh=""; }
    print qq~
        <select name='ocdisp' onchange='this.form.submit()'>
        <option value="horizontal" $selectedh>Horizontal</option>
        <option value="verticle" $selectedv>Verticle</option>
        </select>
      </td></tr>
    ~;
    
    # DISPLAY TIMING
    print "<tr><td align=right valign=top><b><font $fsn>Display Timing:</font></b></td><td>\n";
    if ( $form{octiming} eq "yes" ) { $selectedy="selected"; $selectedn=""; }
    else { $selectedn="selected"; $selectedy=""; }
    print qq~
        <select name='octiming' onchange='this.form.submit()'>
        <option value="yes" $selectedy>Yes</option>
        <option value="no" $selectedn>No</option>
        </select>
      </td></tr>
    ~;
    
    # DISPLAY DATES
    print "<tr><td align=right valign=top><b><font $fsn>Display Dates:</font></b></td><td>\n";
    if ( $form{ocdates} eq "yes" ) { $selectedy="selected"; $selectedn=""; }
    else { $selectedn="selected"; $selectedy=""; }
    print qq~
        <select name='ocdates' onchange='this.form.submit()'>
        <option value="yes" $selectedy>Yes</option>
        <option value="no" $selectedn>No</option>
        </select>
      </td></tr>
    ~;
    
    # DISPLAY WHO
    if ( -s "$ONCDIR/$ktypeid/$ktypeid.ocl" ) 
    {
      print "<tr><td align=right valign=top><b><font $fsn>Display Who:</font></b></td><td>\n";
      @OCL=();
      open (ONC, "$ONCDIR/$form{ktypeid}/$form{ktypeid}.ocl" )  || print "Profile $ONCDIR/$form{ktypeid}/$form{ktypeid}.ocl does not exist";
      while (<ONC>) 
      { 
	chomp; 
        $checked="";
        foreach $whofnd (@OCWHO)
        { 
	  if ( "$whofnd" eq "$_" ) { $checked="checked"; }
        }
        print qq~
	  <input name='ocwho' type="checkbox" value="$_" $checked> $_<br>
        ~;
      }
      print "</td></tr>\n";
    }

    number_records;
  }


  #
  # KNOWLEDGEBASE 
  #
  if ( "$form{ktype}" eq "knowledgebase" ) 
  {
     #
     # GET THE KBDISPLAY
     #
     if ( -s "$KAVES/$form{kaveid}.pro")
     {
	open(FLD, "$KAVES/$form{kaveid}.pro" );
	while (<FLD>) 
	{ chomp; if ( /^kbdisp\t/) { ($f1, $kbtype)= split(/\t/, $_); } }
	close(FLD);
     }
     print qq~
      <tr><td align=right><font $fsn><b>Select a KnowledgeBase:</font></b></td>
      <td>
        <select name='ktypeid' onchange='this.form.submit()'>
        print "<option value=\"\" $selected></option>\n";
     ~;

     #
     # PICK A KBASE TO BUILD A KAVE AROUND
     #
     open(KB, "$KBASE") || print "Cannot find $TRACKER";
     while (<KB>)
     {
  	chomp;
	($kbtitle, $ktypeid) = split(/\t/, "$_");
        if ( "$form{ktypeid}" eq "$ktypeid" ) { $selected="selected"; }
        else { $selected=""; }
	print "<option value=\"$ktypeid\" $selected>$kbtitle</option>\n";
     }
     close(KB);
    print "<tr><td align=right valign=top><b><font $fsn>Display:</font></b></td><td>\n";
    if ( $kbtype eq "popular" ) { $selectedp="selected"; $selectedl="";}
    elsif ( $kbtype eq "latest" ) { $selectedl="selected"; $selectedp="";}
    else { $selectedl=""; $selectedp="";}
    print qq~
        <select name='kbdisp' onchange='this.form.submit()'>
	<option value="" ></option>\n";
	<option value="popular\" $selectedp>Most Popular</option>\n";
	<option value="latest\" $selectedl>Latest Entries</option>\n";
	</select>
    ~;
    number_records;
  }

  #
  # ASSSET MANAGEMNT
  #
  if ( "$form{ktype}" eq "assets" ) 
  {
    print "<tr><td align=right valign=top><b><font $fsn>Select Assets to count:</font></b></td><td>\n";
    #
    # GET THE FIELDS
    #
    if ( -s "$KAVES/$form{kaveid}.pro")
    {
	@kfields=();
	open(FLD, "$KAVES/$form{kaveid}.pro" );
	while (<FLD>) 
	{ 
	  chomp;
	  $field="";
	  if ( /^field\t/) 
	  { 
	  	($f1, $field)= split(/\t/, $_);
		push (@kfields, $field);
          }
	}
	close(FLD);
    }
    @ktypes=();
    @ktypes= ('OS','Flavor','Status','Type','Location','Group');
    foreach $kt (@ktypes)
    {
      if ( $kt ) 
      {
        if ( $kt eq "OS") { $kfname="Operations Systems"; }
	else { $kfname="$kt"; }
        $found=""; $checked="";
        foreach $kfield (@kfields)
        { if ( "$kfield" eq "$kt") { $found="1"; $checked="checked"; } }
        print qq~
          <input name='field' type="checkbox" value="$kt" $checked> $kfname<br>
        ~;
      }
    }
  }

  #
  # TRACKER
  #
  if ( "$form{ktype}" eq "tracker" ) 
  {
     print qq~
      <tr><td align=right><font $fsn><b>Select a Tracker:</font></b></td>
      <td>
        <select name='ktypeid' onchange='this.form.submit()'>
	print "<option value=\"\" $selected></option>\n";
     ~;
     #
     # PICK A TRACKER TO BUILD A KAVE AROUND
     #
     open(TRK, "$TRACKER") || print "Cannot find $TRACKER";
     while (<TRK>)
     {
  	chomp;
	($trktitle, $ktypeid) = split(/\t/, "$_");
        if ( "$form{ktypeid}" eq "$ktypeid" ) { $selected="selected"; }
        else { $selected=""; }
	print "<option value=\"$ktypeid\" $selected>$trktitle</option>\n";
     }
     close(TRK);
     print qq~
	</select>
        </td></tr>
     ~;
    #
    # GET THE FIELDS
    #
    if ( -s "$KAVES/$form{kaveid}.pro")
    {
	@kfields="";
	open(FLD, "$KAVES/$form{kaveid}.pro" );
	while (<FLD>) 
	{ 
	  chomp;
	  $field="";
	  if ( /^field\t/) 
	  { 
	  	($f1, $field)= split(/\t/, $_);
		push (@kfields, $field);
          }
	}
	close(FLD);

    }
    #
    # Collect fields out of the tracker profile
    #
    if ( -f "$TRKDIR/$form{ktypeid}/$form{ktypeid}.pro" ) 
    {
      print "<tr><td align=right valign=top><b><font $fsn>Select Fields to Display:</font></b></td><td>\n";
      $fcount=0;
      open(TRKID, "$TRKDIR/$form{ktypeid}/$form{ktypeid}.pro" ) || print "Cannot find $TRKDIR/$form{ktypeid}/$form{ktypeid}.pro\n";
      while (<TRKID>)
      {
  	chomp;
        if ( /^field\t/ ) 
	{ 
	  $fcount++; $field="";
	  ($d,$field) = split (/\t/, $_);
	  # check if there is a field checked or not
          $found="";
          foreach $kfield (@kfields)
    	  {
  	    if ( "$fcount" eq "$kfield" ) { $found="1";}
	  } 
          if ( $found ) { $checked="checked"; }
	   else { $checked=""; }
  print qq~
        <input name='field' type="checkbox" value="$fcount" $checked> $field<br>
  ~;
  	 }
       }
       close(TRKID);
    	print "<tr><td valign=top align=right><font $fsn><b>Search Pattern</b> <i>(optional)</i>:</b></font>\n";
	print "<td><input type=text size=20 name=\"trckpat\" value=\"$form{trckpat}\"></td></tr>\n";
    number_records;

       print "</td></tr>";
     }
  }

  #
  # TASKS
  # Select the type of kave to create
  #
  if ( "$form{ktype}" eq "task" ) 
  {
    if ( $kID ) { $form{ktypeid}="$kID"; }
     print qq~
      <tr><td align=right><font $fsn><b>Select a Task:</font></b></td>
      <td>
        <select name='ktypeid' onchange='this.form.submit()'>
	print "<option value=\"\" $selected></option>\n";
     ~;
     #
     # Select a TASK BUILD A KAVE AROUND
     #
     open(TSK, "$TASK") || print "Cannot find $TASK";
     while (<TSK>)
     {
  	chomp;
	($tsktitle, $tskID) = split(/\t/, "$_");
        if ( "$form{ktypeid}" eq "$tskID" ) { $selected="selected"; }
        else { $selected=""; }
	print "<option value=\"$tskID\" $selected>$tsktitle</option>\n";
     }
     close(TSK);
     print qq~
	</select>
        </td></tr>
     ~;

    #
    # Select a Group
    #
     $selected="";
     print qq~
      <tr><td align=right><font $fsn><b>Display Specific Group:</font></b></td>
      <td>
        <select name='kgroup' onchange='this.form.submit()'>
	<option value=\"ALL\">ALL</option>
     ~;
     print "$TSKDIR/$form{ktypeid}/$form{ktypeid}.grp\n";
     open(TSKD, "$TSKDIR/$form{ktypeid}/$form{ktypeid}.grp") || print "Cannot find $TSKDIR/$form{ktypeid}/$form{ktypeid}.grp";
     while (<TSKD>)
     {
  	chomp;
        if ( "$form{kgroup}" eq "$_" ) { $selected="selected"; }
        else { $selected=""; }
	print "<option value=\"$_\" $selected>$_</option>\n";
     }
     close(TSKD);
     print qq~
	</select>
        </td></tr>
     ~;
    #
    # Select a Category
    #
     $selected="";
     print qq~
      <tr><td align=right><font $fsn><b>Display Specific Category:</font></b></td>
      <td>
        <select name='ktag' onchange='this.form.submit()'>
	<option value=\"ALL\">ALL</option>
     ~;
#print "$TSKDIR/$form{ktypeid}/$form{ktypeid}.tag\n";
     open(TSKD, "$TSKDIR/$form{ktypeid}/$form{ktypeid}.tag") || print "Cannot find $TSKDIR/$form{ktypeid}/$form{ktypeid}.tag";
     while (<TSKD>)
     {
  	chomp;
        if ( "$form{ktag}" eq "$_" ) { $selected="selected"; }
        else { $selected=""; }
	print "<option value=\"$_\" $selected>$_</option>\n";
     }
     close(TSKD);
     print qq~
	</select>
        </td></tr>
     ~;
    #
    # Select WHO to Display
    #
     $aselected=""; $mselected="";
     if ( "$form{kwho}" eq "ALL" ) { $aselected="selected"; }
     if ( "$form{kwho}" eq "specific" ) { $mselected="selected"; }
     print qq~
      <tr><td align=right><font $fsn><b>Display Specific Assignee:</font></b></td>
      <td>
        <select name='kwho' onchange='this.form.submit()'>
	<option value=\"ALL\" $aselected>ALL Assignees</option>
	<option value=\"specific\" $mselected>Assignee Logged In</option>
	</select>
     ~;
     number_records;
     print qq~
	</select>
        </td></tr>
     ~;
  }

  #
  # FREEFORM
  # Select the Freeform Kave to use
  if ( "$form{ktype}" eq "freeform" ) 
  {
     print qq~
      <tr><td align=right><font $fsn><b>Select a Freeform:</font></b></td>
      <td>
        <select name='ktypeid' onchange='this.form.submit()'>
        print "<option value=\"\" $selected></option>\n";
     ~;
     #
     # Select a FREEFORM BUILD A KAVE AROUND
     #
     open(FRE, "$FREE") || print "Cannot find FREEFORM $FREE";
     while (<FRE>)
     {
        chomp;
        ($fretitle, $freID) = split(/\t/, "$_");
        if ( "$form{ktypeid}" eq "$freID" ) { $selected="selected"; }
        else { $selected=""; }
        print "<option value=\"$freID\" $selected>$fretitle</option>\n";
     }
     close(FRE);
     print qq~
        </select>
        </td></tr>
     ~;
  }

  #
  # RESOURCE
  # Select the Freeform Kave to use
  if ( "$form{ktype}" eq "resource" )
  {
     print qq~
      <tr><td align=right><font $fsn><b>Select a Resource:</font></b></td>
      <td>
        <select name='ktypeid' onchange='this.form.submit()'>
        print "<option value=\"\" $selected></option>\n";
     ~;
     #
     # Select a RESOURCE to build a KAVE around
     #
     open(RES, "$RESRC") || print "Cannot find RESOURCE FILE $RESRC";
     while (<RES>)
     {
        chomp;
        ($restitle, $resid) = split(/\t/, "$_");
        if ( "$form{ktypeid}" eq "$resid" ) { $selected="selected"; }
        else { $selected=""; }
        print "<option value=\"$resid\" $selected>$restitle</option>\n";
     }
     close(RES);
     print qq~
        </select>
        </td></tr>
     ~;
  }


  #
  # SEARCH
  # Select the Search Kave to use
  if ( "$form{ktype}" eq "search" ) 
  {
     print qq~
      <tr><td align=right><font $fsn><b>Select a Search mine:</font></b></td>
      <td>
        <select name='ktypeid' onchange='this.form.submit()'>
        print "<option value=\"\" $selected></option>\n";
     ~;
     #
     # Select a FREEFORM BUILD A KAVE AROUND
     #
     open(SRV, "$SRCH") || print "Cannot find SEARCH $SRCH";
     while (<SRV>)
     {
        chomp;
        ($srchtitle, $srchid) = split(/\t/, "$_");
        if ( "$form{ktypeid}" eq "$srchid" ) { $selected="selected"; }
        else { $selected=""; }
        print "<option value=\"$srchid\" $selected>$srchtitle</option>\n";
     }
     close(FRE);
     if ( ! $form{ksize} ) { $form{ksize}=30; }
     print qq~
        </select>
        </td></tr><tr>
    	<td align=right><font $fsn><b>Search Character Width: </b></td>
    	<td align=left><input type=text size=4 name="ksize" value="$form{ksize}"></td>
	</tr>
     ~;
  }

}


###
### List/Edit Kaves
### 
sub list_kave
{
  print qq~
        $hr_line
        <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
        <font $fsbl>
        <a href="$ITKASM?wp=SETTINGS-MAIN" class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\" >Settings</a></font>
	<font $fsb> | <b>List Kaves</b> | </font><font $fsbl>
        <a href=$ITKASM?act=ckave class=\"hoverlink\" title="Create a Kave" style=\"color:$lnkcolor\">Create Kave</a> 
        </font></td><td align=right width=15% nowrap><font $fsbl>
        Step 3: <a href=$ITKASM?act=listpages class=\"hoverlink\" title="List All Pages" style=\"color:$lnkcolor\">List Pages</a>
        </font> </td></table>
        $hr_line
	<p>
  	<table cellpadding=3>
  ~;
  @KLST=();
  opendir(DIR, "$KAVES") || die "CANT OPEN DIRECTORY: $KAVES\n";
  while ( $_ = readdir(DIR))
  {
    chomp;
    $kfile="$_";
    if ( ! m/^\./ )
    {
      ($id, $pro)=split(/\./, $kfile);
      open(KAVES, "$KAVES/$kfile") || print "CANNOT OPEN $KAVES/$kfile";
      while(<KAVES>)
      {
        chomp;
 	### TEST FOR GOD MODE TO SHOW KAVES CONFIGURED IN SETTINGS
          if ( /^kavename\t/ ) { ($d1, $kavename) = split(/\t/, $_); }
          if ( /^ktype\t/ ) { ($d1, $ktype) = split(/\t/, $_); }
          if ( /^kavedesc\t/ ) { ($d1, $kavedesc) = split(/\t/, $_); }
      }
      close(KAVES);
        $push="$ktype\t$kavename\t$kavedesc\t$id";
        if ( "$push" =~ /SETTINGS/ && $GOD ) { push(@KLST, $push); }
        if ( "$push" !~ /SETTINGS/ ) { push(@KLST, $push); }
    }
  }
  print qq~
	<tr>
	  <td align=center><font $fsb><b>Mines</b></font><br>$hr_line</td>
	  <td align=center><font $fsb><b>Edit</b></font><br>$hr_line</td>
	  <td align=center><font $fsb><b>Name</b></font><br>$hr_line</td>
	  <td align=center><font $fsb><b>Description</b></font><br>$hr_line</td>
	</tr>
  ~;
  close(DIR);
      @KLST = sort @KLST;
      $pktype=""; $cnt=0;
      $ccc="1";
      foreach (@KLST)
      {
        ($ktype, $kavename, $kavedesc, $id) = split (/\t/, $_);
	$ktype = ucfirst $ktype;
        if ( $ktype ne $kptype ) 
	{ 
	   $newmine="";
	   if ( ! $ccc ) { $newmine="<tr><td><br></td></tr>"; }
	   $newmine="$newmine <td align=right><font $fsb><b><u>$ktype</u></b></font></td>"; 
	   $kptype="$ktype"; $cnt=0; $ccc="";
	}
        else { $newmine="<td></td>"; $cnt++; }
        if ( /SETTINGS/) { $BS="<b>"; $BE="</b>"; }
        else { $BS=""; $BE="";}
        print qq~
	 <tr>$newmine
	  <td align=center> <a href=$ITKASM?act=ckave&kaveid=$id&from=kavelist class=\"hoverlink\" title="Edit $kavename" style=\"color:$lnkcolor\" >
	    <img src=$IMAGES/edit.png height=12 border=0></a>
	  </td>
	  <td><font $fsn>${BS}$kavename${BE}</a></td>
	  <td align=left valign=top><font $fsn>${BS}$kavedesc${BE}</font></td></tr>
	  ~;
      }
  print "</table>";
}

###
### Display Sample Kave
###
sub kave_sample
{
#print "$buffer<br>";
      print qq~
        <b><font $fsb>Sample Kave:</font></b><p>
        <table border=0 cellpadding=3 cellspacing=0><td>
      ~;
       if ( "$form{tmplt}" ne "None" ) 
       {
        if ( ! $kavename ) { $kavename="Sample Header"; }
 	#$khtx=$gbxframetxt; $kfbg=$gbxframebg; $kbrd=$gbxbord;
	#$kwdt=$gbxwidth; $kbkg1=$gbxbg1; $kbkg2=$gbxbg2;
	#$kbdybrd=0; $khrclr=$gbxhr; $ktxt=$gbxtxt; $klnk=$gbxlnk; 
 	#print "$khtx=$txtcolor; $kfbg=$bgcolor1; $kbrd=$gbxbord;<br>";
	#print "$kwdt=$gbxwidth; $kbkg1=$gbxbg1; $kbkg2=$gbxbg2;<br>";
	#print "$kbdybrd=0; $khrclr=$hrclr; $ktxt=$txtcolor; $klnk=$lnkcolor; <br>";
 	$kconfig="%%%open.none:$kavename,$khtx,$kfbg,$kbrd,$kwdt,$kbkg1,$kbkg2,$kbdybrd,$khrclr,$ktxt,$klnk";
        &open_kave; 
	$hrcolor="$khrclr"; $cflip="";
        if ( $form{ktype} eq "search" )
        {   
	  print qq~
   	     <center>
	    <form action="$ITKASMASM" method=get>
	    <input type="text" name="s" id="s" value="$kavename" size="30" onfocus="if (this.value==\'$kavename\'){this.value='';};return false;" onblur="if (this.value==''){this.value=\'$kavename\';return false;}">
            </form>
	    </center>
	  ~;
	}
        else
	{ 
          if ( ! $form{knrec} || $form{knrec} eq "ALL" ) { $form{knrec}="5"; }
          for ($i = 1; $i < $form{knrec}+1; $i++) 
          {
	    if ( $form{kstag} eq "yes" || ! $form{kstag} ) 
	    {
            	if ( ! $cflip ) { $bgc="$kbkg1"; $cflip="1"; }
	    	else { $bgc="$kbkg2";  $cflip=""; }
	    }
	    else { $bgc="$kbkg1"; }
 	    print "<tr><td bgcolor=$bgc><font size=$fontnorm color=$ktxt>Sample Line $i: <font color=$klnk>URL Link $i</font></td></tr>\n";
          }
	    if ( $form{kstag} eq "yes" ) { $bgc="$kbkg2"; }
	    else { $bgc="$kbkg1"; }
	    if ( $form{khrclr} ) { $hrc="$form{khrclr}"; }
	    else {  $hrc="$khrclr"; }
 	    print "<tr><td bgcolor=$bgc>"; hrline; print "</td></tr>\n";
 	    print "<tr><td bgcolor=$kbkg1><font $fsn>Sample Horizontal Lines</font></td></tr>\n";
 	    print "<tr><td bgcolor=$kbkg1>"; hrline; print "</td></tr>\n";
            print "</td>\n";
	}
	  close_kave; 
          if ( $form{act} ne "sysconfigs" ) 
          {
     	    print "<tr><td colspan=2 align=left>&nbsp;<p><Input type=submit name=ksave value=\"Update\"></td></tr>";
          }
	   print "</td></table>";
       }
}


###
### Save Kave configs
###
sub kave_save
{

  # collect the fields first.
  @fields=();
  foreach $buff (@pairs) 
  { 
     if ( $buff =~ /field=/) 
     { 
	chomp($buff);
        ($d1, $f) = split (/=/, $buff);
        push(@fields, $f);
#print "**** You picked $f .***** <br>\n"; 

     }
   }

  @OCWHO=();
  foreach $ocwho (@pairs) 
  { 
     if ( $ocwho =~ /ocwho=/) 
     { 
	chomp($ocwho);
        ($d1, $f) = split (/=/, $ocwho);
        push(@OCWHO, $f);
#print "**** You picked $f .***** <br>\n"; 

     }
   }

   if ( ! -d "$KAVES" ) { `mkdir $KAVES`; }
   if ( $form{kavename} ) 
   {      
      open(SAVE, "> $KAVES/$form{kaveid}.pro") || print "CANNOT WRITE KAVE: $KAVES/$form{kaveid}.pro\n";

        if ( $form{kavename} ) { print SAVE "kavename\t$form{kavename}\n"; }
        if ( $form{kavedesc} ) { print SAVE "kavedesc\t$form{kavedesc}\n"; }
        if ( $form{ktype} ) { print SAVE "ktype\t$form{ktype}\n"; } 
        if ( $form{ktypeid} ) { print SAVE "ktypeid\t$form{ktypeid}\n"; } 
  	if ( $form{kaveid}) { print SAVE "kaveid\t$form{kaveid}\n";   }
        #if ( $form{kfbg} ) {  print SAVE "kave\t$form{khtx},$form{kfbg},$form{kbrd},$form{kwdt},$form{kbkg1},$form{kbkg2},$form{kbdybrd},$form{khrclr},$form{ktxt},$form{klnk}\n";  }
        print SAVE "kave\t$form{khtx},$form{kfbg},$form{kbrd},$form{kwdt},$form{kbkg1},$form{kbkg2},$form{kbdybrd},$form{khrclr},$form{ktxt},$form{klnk}\n"; 
  	if ( $form{kgroup}) { print SAVE "kgroup\t$form{kgroup}\n";   }
  	if ( $form{ktag}) { print SAVE "ktag\t$form{ktag}\n";   }
  	if ( $form{kwho}) { print SAVE "kwho\t$form{kwho}\n";   }
  	if ( $form{knrec}) { print SAVE "knrec\t$form{knrec}\n";   }
  	if ( $form{kdispnam}) { print SAVE "kdispnam\t$form{kdispnam}\n";   }
  	if ( $form{kstag}) { print SAVE "kstag\t$form{kstag}\n";   }
  	if ( $form{ksize}) { print SAVE "ksize\t$form{ksize}\n";   }
  	if ( $form{trckpat}) { print SAVE "trckpat\t$form{trckpat}\n";   }
  	if ( $form{kbdisp}) { print SAVE "kbdisp\t$form{kbdisp}\n";   }
  	if ( $form{vdrdisp}) { print SAVE "vdrdisp\t$form{vdrdisp}\n";   }
  	if ( $form{vdrsrch}) { print SAVE "vdrsrch\t$form{vdrsrch}\n";   }
  	if ( $form{ocdisp}) { print SAVE "ocdisp\t$form{ocdisp}\n";   }
  	if ( $form{octiming}) { print SAVE "octiming\t$form{octiming}\n";   }
  	if ( $form{ocdates}) { print SAVE "ocdates\t$form{ocdates}\n";   }

   	# Write out the fields
        $fsize=@fields;
        if ( @fields ) 
        { foreach (@fields) { if ( $_ ) { print SAVE "field\t$_\n"; } } }
        if ( @OCWHO ) 
        { foreach (@OCWHO) { if ( $_ ) { print SAVE "ocwho\t$_\n"; } } }
        close(SAVE);
      }
      elsif ( ! $form{kavename} && -f "$KAVES/$form{kaveid}.pro" ) { $ERROR="<font $fserr>Error: TITLE needed before itcan be saved</font><br>";}
}


###
### GET KAVECONFIGS
###
sub kave_getconf
{
  @files=(); @OCWHO=();
  open(KAVE, "$KAVES/$form{kaveid}.pro") || print "CANNOT OPEN $KAVES/$form{kaveid}.pro";
  while (<KAVE>)
  {
	chomp;
        if ( /^kavename\t/ ) { ($d1,$form{kavename})=split(/\t/,$_); } 
        if ( /^kavedesc\t/ ) { ($d1,$form{kavedesc})=split(/\t/,$_); }  
        if ( /^ktype\t/ ) { ($d1,$form{ktype})=split(/\t/,$_); }  
        if ( /^ktypeid\t/ ) { ($d1,$form{ktypeid})=split(/\t/,$_); }  
        if ( /^kaveid\t/ ) { ($d1,$form{kaveid})=split(/\t/,$_); }  
        if ( /^knrec\t/ ) { ($d1,$form{knrec})=split(/\t/,$_); }  
        if ( /^kgroup\t/ ) { ($d1,$form{kgroup})=split(/\t/,$_); }  
        if ( /^ktag\t/ ) { ($d1,$form{ktag})=split(/\t/,$_); }  
        if ( /^kave\t/ ) 
	{ 
	  ($d1,$form{kave}) = split(/\t/,$_); 
          ($form{khtx},$form{kfbg},$form{kbrd},$form{kwdt},$form{kbkg1},$form{kbkg2},$form{kbdybrd},$form{khrclr},$form{ktxt},$form{klnk}) = split(/,/, $form{kave}); 
         ($khtx,$kfbg,$kbrd,$kwdt,$kbkg1,$kbkg2,$kbdybrd,$khrclr,$ktxt,$klnk)=split(/\,/, $form{kave});
	}  

        if ( /^knrec\t/ ) { ($d1,$form{knrec})=split(/\t/,$_); }  
        if ( /^kdispnam\t/ ) { ($d1,$form{kdispnam})=split(/\t/,$_); }  
        if ( /^kstag\t/ ) { ($d1,$form{kstag})=split(/\t/,$_); }  
        if ( /^ksize\t/ ) { ($d1,$form{ksize})=split(/\t/,$_); }  
        if ( /^kbdisp\t/ ) { ($d1,$form{kbdisp})=split(/\t/,$_); }  
        if ( /^field\t/ ) { ($d1,$f)=split(/\t/,$_); push(@fields, $f); }
        if ( /^ocdisp\t/ ) { ($d1,$form{ocdisp})=split(/\t/,$_); }  
        if ( /^octiming\t/ ) { ($d1,$form{octiming})=split(/\t/,$_); }  
        if ( /^ocdates\t/ ) { ($d1,$form{ocdates})=split(/\t/,$_); }  
        if ( /^ocwho\t/ ) { ($d1,$f)=split(/\t/,$_); push(@OCWHO, $f); }
        if ( /^trckpat\t/ ) { ($d1,$form{trckpat})=split(/\t/,$_); }  
  }
  close(KAVE);
}

###
### DELETE A KAVE
###
sub delete_kave
{
#print "$buffer";
  # get_kave_profile returns $ERRORLOG if there is problem
  $kaveid="$form{kaveid}"; &get_kave_profile; 
  if ( -f "$KAVES/$form{kaveid}.pro" ) { $KAVELINK="<font $fsbl><a href=\"$ITKASM?act=ckave&kaveid=$kaveid&from=kavelist\" class=\"hoverlink\" title=\"Back to '$kavename' Kave\" style=\"color:$lnkcolor\">$kavename Kave</a></font> |"; }
  else { $KAVELINK=""; }
  print qq~
         <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
        <font $fsbl><a href="$ITKASM?wp=SETTINGS-MAIN" class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\" >Settings</a></font>
        <font $fsb> | </font>
        <font $fsbl><a href=$ITKASM?act=listkaves class=\"hoverlink\" title="List available Kaves" style=\"color:$lnkcolor\">List Kaves</a></font> |
        $KAVELINK
        <font $fsbl><a href=$ITKASM?act=ckave class=\"hoverlink\" title="Create a Kave" style=\"color:$lnkcolor\">Create New Kave</a></font>
        <font $fsb> | </font>
	<font $fsb><b>Delete $kavename</b></font>
        </td><td align=right width=15% nowrap><font $fsbl> | 
        Step 3: <a href=$ITKASM?act=listpages class=\"hoverlink\" title="List All Pages" style=\"color:$lnkcolor\">List Pages</a>
        </font> </td></table>
        $hr_line
  ~;

  if ( ! $form{con} )
  {
    print qq~
    <p>&nbsp;
    <center>
    <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
    <td>
      <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
       <tr>
      <tr><td align=center colspan=2><font $fsb>Confirm deletion of the Kave</font><p>
	<font $fsberr><b> $kavename</b></font><br>
	<font $fsberr>$kavedesc</font><p>
	$hr_line
      <tr><td align=center>
      <form method=post action=$ITKASM>
      <input type=hidden name="act" value="delkave">
      <input type=hidden name="kaveid" value="$form{kaveid}">
      <input type=hidden name="con" value="confirm">
      <input type=submit value="CONFIRM">
      </form>
	</td><td align=center>
      <form method=post action=$ITKASM>
      <input type=hidden name="act" value="ckave">
      <input type=hidden name="kaveid" value="$form{kaveid}">
      <input type=hidden name="from" value="kavelist">
      <input type=submit value="CANCEL">
      </form>
	</td></tr>
      </td> </tr>
     </table>
     </td></table>
     </center>
    ~;
  }
  elsif ( $form{con} eq "confirm" )
  {
    #
    # DELETE KAVE ENTRY
    #
    $success="";
    if ( -f "$KAVES/$form{kaveid}.pro") { $success = unlink "$KAVES/$form{kaveid}.pro"; }
    if ( ! $success ) 
    { 
      print qq~
        <p>&nbsp;
        <center>
        <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
        <td>
          <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
           <tr>
          <tr><td align=center colspan=2><font $fsberr>
      	    Could not Delete Kave. Possible issues: <p>Permission or already deleted
            </font><p>
          </td> </tr>
       </table>
       </td></table>
       </center>
    ~;
    }
    else
    {
      print qq~
      <p>&nbsp;
      <center>
      <table border=1 cellspacing=3 cellpadding=20 bgcolor=$hdrcolor>
      <td>
        <table border=0 cellspacing=4 cellpadding=3 bgcolor=$bgcolor1>
         <tr>
        <tr><td align=center colspan=2><font $fsb><b>$kavename</b><br>has been deleted</font><p>
          $hr_line
        </td> </tr>
        <tr><td align=center>
          <form method=post action=$ITKASM>
          <input type=hidden name="act" value="listkaves">
          <input type=hidden name="con" value="done">
          <input type=submit value="CONTINUE">
          </form>
        </td></tr>
       </table>
       </td></table>
       </center>
      ~;
    }
  }
}


###
### LIST KAVES THAT WERE PUBLISHED IN IT KASM PAGES
###
sub list_kaves_pub
{
    print qq~
	<!-- LIST KAVES THAT WERE PUBLISHED IN IT KASM PAGES -->
	<table border=0 width=100% cellpadding=3>
	<td valign=top align=center width=33%>
	<table border=0 >
        <tr>
          <td valign=top align=left nowrap>
	  <font $fsn><b>Published on IT KASM Pages:</b></font>
	  </td><td valign=top align=left no wrap>
      ~;
      $cant_delete="None"; 
      #
      # GET IT KASM PAGES THAT THE KAVE IS PUBLISHED IN
      #
      opendir(PGID, "$KPGDIR") || die "CANT OPEN DIRECTORY: $KPGDIR";
      while ( $_ = readdir(PGID))
      {
        chomp;
        $pageid="$_";
        if ( ! m/^\./ )
        {
          # GET ALL THE DATA FILES
#print "$pageid<br>";
          opendir(PGSEC, "$KPGDIR/$pageid") || die "CANT OPEN DIRECTORY: $KPGDIR/$pageid";
          while ( $_ = readdir(PGSEC))
          {
            chomp;
            $datfile="$_";
            if ( ! m/^\./ && /\.dat/)
            {
#print "- $datfile<br>";
              $foundit="";
	      # CHECK ALL THE DATAFILES (A,B,C,D,...) THAT MAKE UP THE PAGE
 	      open(DFILE, "$KPGDIR/$pageid/$datfile") || print "CANNOT OPEN $KPGDIR/$pageid/$datfile";
	      while (<DFILE>)
	      {
		if (/$form{kaveid}/) 
    		{
		  &get_page_profile;
 		  print "<font $fsnl><a href=\"$ITKASM?act=ckpage&pageid=$pageid\" class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"Go to $pgname IT KASM Page so '$form{kavename}' can be removed\">$pgname</a></font><br>";
		  $cant_delete="";
		  $foundit="1";
		}
   	      }
	      close(DFILE);
              if ( $foundit )
	      {
    	        @LST=();@NEWLST=();
    	        tie @LST, 'Tie::File', "$KPGDIR/$pageid/$datfile" or die;
    	        $NEWLINE="";
    	        foreach (@LST)
    	        {
      	          if ( /\t$form{kaveid}/)
      	          {
                    $NEWLINE="$form{kavename}\t$form{kaveid}\n";
        	    push@NEWLST, "$NEWLINE";
      	          }
      	          else { push@NEWLST, "$_";}
 	        }
	        @LST=@NEWLST;
    	        untie(@LST);
	      }
	    }
 	  }
	  close(PGSEC);
        }
      }
      close(PGID);
      print "<font $fserr>${cant_delete}</font></td>\n";
     ###
     ### MAKE SURE A SETTING KAVE CANNOT BE DELETED
     ###
     if ( "$form{kavename}" =~ "SETTINGS" ) { }
     else
     {
      if ( ! $cant_delete ) 
      { 
	 print "<td valign=top >&nbsp;&nbsp;&nbsp;&nbsp;<img src=$IMAGES/trashcan-x.png height=20 title=\"Remove '$form{kavename}' from all IT KASM Pages to delete the Kave.\"></td>\n";
      }
      else
      {
 	print qq~
	  <td valign=top>&nbsp;&nbsp;&nbsp;&nbsp;
 	    <a href=\"$ITKASM?act=delkave&kaveid=$form{kaveid}\" class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"Delete '$kavename' forever\"><img src=$IMAGES/trashcan.png border=0 height=20 title=\"Delete '$kavename' forever\">
	  </td>
	~;
      } 
     }
      print qq~ 
	</table> 
	</tr>
	<tr><td colspan=3>$hr_line</td><tr>
        </td> </table>
       ~;
}


###
### Create/Edit Kave
###
sub create_kave
{
#print "$buffer<p>";
  print "$hr_line";

  # if first time through get a Kave ID
  if ( ! $form{kaveid} ) 
  {
    $valid="";
    while ( ! $valid  )
    {
      my $random_string=&get_token(6);
      &get_token;
      $number="$random_string"; 
      if ( ! -f "$KAVES/${number}.pro" ) { $valid="1"; }
    }
    $form{kaveid}="$number";
  }

  # Set the default kave type if not set
  if ( ! $form{tmplt} ) { $form{tmplt} = "Default"; }

  #
  # SAVE the changes first thing!
  #
  if ( ! $form{from} ) { kave_save;  }
  else { kave_getconf; $form{tmplt}="Custom"; } 

  #
  # If coming from creating somewhere tracker/task/freeform/....
  #
  if ( $form{kid} ) 
  {
        ($kTYPE,$kID) = split(/:/, $form{kid});
#print "TYPE/ID = $kTYPE/$kID<br>";
        if ( "$kTYPE" eq "tracker" ) 
	  { $FILE="$TRKDIR/$kID/${kID}.pro"; $form{ktype}="tracker"; $form{ktypeid}="$kID"; } 
        if ( "$kTYPE" eq "task" ) 
	  { $FILE="$TSKDIR/$kID/${kID}.pro"; $form{ktype}="task"; $form{ktypeid}="$kID"; } 
        if ( "$kTYPE" eq "resource" ) 
	  { $FILE="$RESDIR/$kID/${kID}.pro"; $form{ktype}="resource"; $form{ktypeid}="$kID"; } 
        if ( "$kTYPE" eq "freeform" ) 
	  { $FILE="$FREDIR/$kID/${kID}.pro"; $form{ktype}="freeform"; $form{ktypeid}="$kID"; } 
        if ( "$kTYPE" eq "knowledgebase" ) 
	  { $FILE="$KBASEDIR/$kID/${kID}.pro"; $form{ktype}="knowledgebase"; $form{ktypeid}="$kID"; } 
        if ( "$kTYPE" eq "oncall" ) 
	  { $FILE="$ONCDIR/$kID/${kID}.pro"; $form{ktype}="oncall"; $form{ktypeid}="$kID"; } 
        if ( "$kTYPE" eq "search" ) 
	  { $FILE="$SRCHDIR/$kID/${kID}.pro"; $form{ktype}="search"; $form{ktypeid}="$kID"; } 
        open (GET, "$FILE") || print "CANNOT FIND THIS $FILE";
        while(<GET>)
	{
	  chomp;
	  if ( /^name\t/ ) { ($d, $form{kavename}) = split(/\t/, "$_"); } 
	}
	close(GET);
  }

#print "kavename = $form{kavename}";
      #
      # Column 1 - Title/Desc/Type of Kave
      #
      print qq~
        <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
        <font $fsbl><a href="$ITKASM?wp=SETTINGS-MAIN" class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\" >Settings</a></font>
	<font $fsb> | </font>
        <font $fsbl><a href=$ITKASM?act=listkaves class=\"hoverlink\" title="List available Kaves" style=\"color:$lnkcolor\">List Kaves</a></font>
	<font $fsb> | <b>$form{kavename} Kave</b> | </font><font $fsbl>
        <a href=$ITKASM?act=ckave class=\"hoverlink\" title="Create a Kave" style=\"color:$lnkcolor\">Create New Kave</a> 
        <a href=$ITKASMTRCK?ID=$form{ID} class=\"hoverlink\" title="Go To $trckname" style=\"color:$lnkcolor\">$trckname </a>
	</font></td><td align=right width=15% nowrap><font $fsbl>
        Step 3: <a href=$ITKASM?act=listpages class=\"hoverlink\" title="List All Pages" style=\"color:$lnkcolor\">List Pages</a>
	</font> </td></table>
        $hr_line
        <form method=post action=$ITKASM>
    	<input type=hidden name=act value=ckave>
    	<input type=hidden name=kaveid value=$form{kaveid}>
        <table border=0 cellspacing=3 cellpadding=3 width=100%>
     	<td valign=top width=100% nowrap>
        <i><font $fsn> $ERROR </font></i><br>
	<font $fsn><b>Kave Title: </b> </font>
        <input type=text size=20 name="kavename" value="$form{kavename}">
	<p>
        <font $fsn><b>Description:</b>
        <input type=text size=40 name="kavedesc" value="$form{kavedesc}"><p>
	<p>
        <table border=0 cellpadding=3>	
	<tr><td align=right><font $fsn><b>Kave ID:</b></font></td><td>$form{kaveid}</td></tr>
	<tr><td align=right><font $fsn><b>Type of Kave:</b></font></td><td>
        <select name='ktype' onchange='this.form.submit()'>
        ~;
        @ktypes= ('', 'Assets','Freeform','IPAM','KnowledgeBase','OpsActivities','OnCall','Resource','Search','Task','Tracker');
        foreach $kt (@ktypes)
        {
          $lckt=lc($kt);
	  if ( "$form{ktype}" eq "$lckt" ) { $selected="selected"; }
	  else { $selected=""; }
          print "<option value=\"$lckt\" $selected>$kt</option>\n";

	}
 	print "</select></td></tr>";

        &select_kavetype;

        print qq~ 
          </table>
	  </td>

<td>
        ~;

      # LIST KAVES PUBLISHED ON ITKASM PAGES

      list_kaves_pub;


      #
      # Column 2 - choose/modify a template
      #
      $selYES=""; $selNO="";
      if ( $form{kavename} ) { $kavename="$form{kavename}"; }
       if ( $form{kdispnam} eq "yes" ) { $selYES="selected"; }
       if ( $form{kdispnam} eq "no" ) { $selNO="selected"; }
       if ( $form{kstag} eq "yes" ) { $selstagYES="selected"; }
       if ( $form{kstag} eq "no" ) { $selstagNO="selected"; }
       print qq~

        <table border=0 width=100% cellpadding=3>

        <!-- Pick box Color size -->
        <td valign=top align=center>
	 <table border=0>
         <tr><td align=right>
	 <b><font $fsn>Display Title:</font></b></td><td>
         <select name='kdispnam' onchange='this.form.submit()'>
         <option value="yes" $selYES>Yes</option>
         <option value="no" $selNO>No</option>
         </select>
	</td></tr>
         <tr><td align=right>
	 <b><font $fsn>Select a Template:</font></b></td><td>
         <select name='tmplt' onchange='this.form.submit()'>
       ~;
      $foundtmp=""; $selected="";
       open(ST, "$ETC/kave-templates.dat") || print "ERROR: Cannot find $ETC/kave-templates.dat";
       while(<ST>)
       {
         chomp;
         if ( /^%%%/ ) 
         {
           ($ktmpschema,$kaveconf) = split(/:/, $_);
           ($kavetitle,$khtx,$kfbg,$kbrd,$kwdt,$kbkg1,$kbkg2,$kbdybrd,$khrclr,$ktxt,$klnk)=split(/,/, $kaveconf);
	 if ( /:$form{tmplt},/ ) 
	 { 
	   $selected="selected"; $foundtmp="";

	   $form{khtx}="$khtx"; $form{kfbg}="$kfbg"; $form{kbrd}="$kbrd"; 
	   $form{kwdt}="$kwdt"; $form{kbkg1}="$kbkg1"; $form{kbkg2}="$kbkg2"; 
	   $form{kbdybrd}="$kbdybrd"; $form{khrclr}="$khrclr"; $form{ktxt}="$ktxt";
	   $form{klnk}="$klnk";
   	 }
	 else { $selected="";}
         print "<option value=\"$kavetitle\" $selected>$kavetitle</option>\n";
         }
       }
       close(ST);
       if ( ! $foundtmp ) 
       { 
	   $selected="selected";
	   $khtx="$form{khtx}"; $kfbg="$form{kfbg}"; $kbrd="$form{kbrd}"; 
	   $kwdt="$form{kwdt}"; $kbkg1="$form{kbkg1}"; $kbkg2="$form{kbkg2}"; 
	   $kbdybrd="$form{kbdybrd}"; $khrclr="$form{khrclr}"; $ktxt="$form{ktxt}";
	   $klnk="$form{klnk}";
       }
       print "<option value=\"Custom\" $selected>Custom</option>\n";
       print qq~
          </select>
          </td></tr>
          <tr><td align=right nowrap><font $fsn><b>Frame Background:</b></font></td>
          <!-- <td><input type=text size=8 name="kfbg" value="$form{kfbg}"></td></tr> -->
          <td><input type=color name="kfbg" value="$form{kfbg}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Frame Header Text:</b></font>
          <td><input type=color name="khtx" value="$form{khtx}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Body Text:</b></font>
          <td><input type=color name="ktxt" value="$form{ktxt}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Linked Text:</b></font>
          <td><input type=color name="klnk" value="$form{klnk}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Frame Border:</b></font>
          <td><input type=text size=8 name="kbrd" value="$form{kbrd}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Inside Border Size:</b></font>
          <td><input type=text size=8 name="kbdybrd" value="$form{kbdybrd}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Kave Width:</b></font>
          <td><input type=text size=8 name="kwdt" value="$form{kwdt}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Primary Body Background:</b></font>
          <td><input type=color name="kbkg1" value="$form{kbkg1}"></td></tr>
          <tr><td align=right nowrap><font $fsn><b>Secondary Body Background:</b></font>
          <td><input type=color name="kbkg2" value="$form{kbkg2}"></td></tr>
         <tr><td align=right>
	 <b><font $fsn>Stagger Primary/Secondary:</font></b></td><td>
         <select name='kstag' onchange='this.form.submit()'>
        ~;
  	if ( "$form{ktype}" ne "resource" && "$form{ktype}" ne "freeform" && "$form{ktype}" ne "search" )
  	{
	  print qq~
         <option value="yes" $selstagYES>Yes</option>
	  ~;
	}
	print qq~
         <option value="no" $selstagNO>No</option>
         </select>
	</td></tr>
          <tr><td align=right nowrap><font $fsn><b>Horizontal Rule:</b></font>
          <!-- <td><input type=text size=8 name="khrclr" value="$form{khrclr}"></td></tr> -->
          <td><input type=color name="khrclr" value="$form{khrclr}"></td></tr>
     	   <!-- <tr><td colspan=2 align=right>&nbsp;<br><Input type=submit name=ksave value=\"Update\"></td></tr> -->
         </table>
         </td>
       ~;


       #
       # Column 3 - display Sampe Kave
       #
       print qq~
            <!-- Display a Sample Kave -->
             <td valign=top align=center>
       ~;

       kave_sample;

       print qq~
</table>
</td>

         </table>
    	 <input type=submit name=ksave value="Save">
	 </td>
         </table>
         $hr_line
         </form>
~;


}


###
### Create Tracker
###
sub create_tracker
{
  #
  # If form is filled out, write
  #
  if ( $form{trckname} && $form{trcknum} && $form{1} ) 
  {
    $valid="";
    while ( ! $valid  )
    {
      my $random_string=&get_token(6);
      &get_token;
      $number="$random_string";
      if ( ! -d "$TRKDIR/${number}" ) { $valid="1"; }
    }
    $TrackerID="$number";

    #$TrackerName="$form{trckname}";
    #$TrackerName =~ s/\s+/\_/g;
    #print "TRACKERNAME = $TrackerName  - $DPATH/tracker/$TrackerName<p>";

#print "$buffer";

    if ( ! -d "$TRKDIR/$TrackerID" ) { `mkdir -p "$TRKDIR/$TrackerID"`; }
    #
    # Write to tracker index file
    #
    open(TRKR, ">> $TRACKER" ) || print "CANNOT WRITE $TRACKER";
    print TRKR "$form{trckname}\t$TrackerID\n";
    close(TRKR);
    #
    # Create data structure.
    #
    open(TRKD, "> $TRKDIR/$TrackerID/$TrackerID.pro" ) || print "CANNOT write: $TRKDIR/$TrackerID/$Tracker.pro";
    print TRKD "id\t$TrackerID\n";
    print TRKD "name\t$form{trckname}\n";
    print TRKD "desc\t$form{trckdesc}\n";
    print TRKD "recname\t$form{recname}\n";
    print TRKD "recnum\t$form{recnum}\n";
    print TRKD "dsplst\t$form{dsplst}\n";
    print TRKD "rechide\t$form{rechide}\n";
    print TRKD "wopsact\t$form{wopsact}\n";
    for ($c=1; $c < $form{trcknum}+1; $c++)
    {
        print TRKD "field\t";
        foreach $pair (@pairs)
        {
          ($name, $value) = split(/=/, $pair);
          $value =~ tr/+/ /;
          if ( $name eq $c )
          {
             if ( $value =~ "%25" ) { ($val,$d)=split(/%/,$value); $value="${val}%"; }
             print TRKD "$value\t";}
        }
        print TRKD "\n";
    }
    close(TRKD);
    open(TRKD, "> $TRKDIR/$TrackerID/${TrackerID}.cmt" ) || print "CANNOT write: $TRKDIR/$TrackerID/${TrackerID}.cmt";
    print TRKD "$form{trckcom}";
    close(TRKD);
    open(TRKN, "> $TRKDIR/$TrackerID/${TrackerID}.num" ) || print "CANNOT write: $TRKDIR/$TrackerID/${TrackerID}.num";
    print TRKN "$form{recnum}";
    close(TRKN);


    print qq~
	<META HTTP-EQUIV="Refresh" CONTENT="0;URL=$ITKASM?act=modtrk&ID=$TrackerID">
    ~;
    $META="1";
  }
  else
  {
  print qq~
    $hr_line
    <table width=100% bgcolor=$hdrcolor cellpadding=3><td>
    <font $fsbl>
    <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> |
    <a href=$ITKASM?act=listtrk class=\"hoverlink\" title="List available Tracker Mines" style=\"color:$lnkcolor\">List Tracker</a> 
    </font><font $fsb>
     | <b>Create Tracker</b> | 
    </font><font $fsbl>
    <a href=$ITKASM?act=clonetrk class=\"hoverlink\" title="Clone a Tracker Mine" style=\"color:$lnkcolor\">Clone Tracker</a>
    </font>
    </td></table>
    $hr_line
    <p>
    <form method=post action=$ITKASM>
    <input type=hidden name=act value=ctracker>
    <font $fsn><b>Tracker Title: </b></font>
    <input type=text size=35 name="trckname" value="$form{trckname}" title="No meta characters, accept dash or underscore" required><p>
    <font $fsn><b>Tracker Description: </b></font>
    <input type=text size=40 name="trckdesc" value="$form{trckdesc}" ><p>
    <font $fsn><b>Number Fields: </b></font>
  ~;
  print "<input type=\"number\" size=\"3\" name=\"trcknum\" min=\"1\" max=\"15\" value=\"$form{trcknum}\"><p>\n";
  if ( $dsplst eq "n" || ! $dsplst ) { $ndsplst="checked"; $rdsplst=""; }
  else { $ndsplst=""; $rdsplst="checked"; }
  if ( $form{trcknum} ) 
  {
    $recname="REC"; $recnum="10000"; $ychecked="checked";
    print qq~
        <font $fsn><b>Display List: </b></font>
                <input type="radio" name="dsplst" value="n" $ndsplst> <font $fsn>Normal / </font>
                <input type="radio" name="dsplst" value="r" $rdsplst> </font $fsn>Reverse </font>
        <p>
        <font $fsn><b>Record Name: </b><input type=text size=3 name="recname" value="$recname"></font>
        &nbsp;
        &nbsp;
        <font $fsn><b>Starting Number: </b><input type=text size=5 name="recnum" value="$recnum"></font>
        &nbsp;
        &nbsp;
        &nbsp;
        <font $fsn><b>Hide: </b>
        <input type="radio" name="rechide" value="y" $ychecked> Yes /
        <input type="radio" name="rechide" value="n" $nchecked> No
    <p>
    <font $fsn><b>Comments:</b></font><br>
    <textarea rows=3 cols=100 name=trckcom wrap="on">$form{trckcom}</textarea><p>
      <table cellspacing=0 cellpadding=3 border=0>
	<tr>
	<td align=center><font $fsn><b>Field Name</b></font>$hr_line</td>
	<td align=center><font $fsn><b>Width</b></font> $hr_line</td>
	<td align=center><font $fsn><b>Type</b></font> $hr_line</td>
	<td align=center><font $fsn><b>Alignment</b></font> $hr_line</td>
	<td align=center><font $fsn><b>Wrapping</b></font> $hr_line</td>
	<td align=center><font $fsn><b>NewLine</b></font> $hr_line</td>
        </td><td rowspan=20 valign=top>
          &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        </td><td valign=top align=center rowspan=2>
          <font $fsn><b>Update Operations Activities:</b><br>
          <input type="radio" name="wopsact" value="y"> Yes /
          <input type="radio" name="wopsact" value="n" checked> No
          </font>
        </td>
	</tr>
    ~;
    for ($c=1; $c < $form{trcknum}+1; $c++)
    { 
      print qq~
    	<tr>
	<td><font $fsn>$c:</font>
	<input type="text" size=20 name="$c" value=""></td>
        <td><input type="text" size=4 name="$c" value=""></td>
        <td><select name="$c">
	<option value="text">Text</option>
	<option value="number">Number</option>
	<option value="email">Email</option>
	<option value="dt">Date/Time</option>
	<option value="date">Date</option>
	<option value="time">Time</option>
	<option value="phone">Phone</option>
	<option value="address">Address</option>
        </select></td>
 

        <td><select name="$c">
	<option value="left">Left</option>
	<option value="center">Center</option>
	<option value="right">Right</option>
        </select></td>

        <td><select name="$c">
	<option value="nowrap">No Wrap</option>
	<option value="wrap">Wrap</option>
        </select></td>
 
        <td><select name="$c">
	<option value="no">No</option>
	<option value="yes">Yes</option>
        </select></td>
	</tr>
	<p>
      ~;
    }
  }
  print qq~
	</table>
	<p> $hr_line
    <input type=submit value="Continue">
    </form>
  ~;
  } 
}



###
### Sort a file
###
sub sort_file
{
   @LST=(); @NEWLST=();
   tie @LST, 'Tie::File', "$FILE" or die; 
   @LST= sort @LST;
   untie(@LST);
}

###
### Change Name in Task, Tracker, or Freeform Index
###
# $ID=form{Task/Track/FreeID} / $NEWNAME=$form{name} $FILE=/etc/file
sub index_namechg
{
   @LST=(); @NEWLST=();
   tie @LST, 'Tie::File', "$FILE" or die; 
   foreach (@LST)
   {
     ($curNAME,$curID) = split(/\t/, $_);
     if ( /\t$ID/) 
     { 
        $NEWLINE="$NEWNAME\t$curID";
	push(@NEWLST, "$NEWLINE"); 
     }
     else { push(@NEWLST, "$_");  }
   }
   @LST=@NEWLST;
   untie(@LST);
}


###
### MOVE RECORD DOWN 
### Pass MOVEFILE = file with record to move down
### Pass MOVEREC = the record number that moves down
###
sub move_record_down
{
    @LST=(); @NEWLST=();
    tie @LST, 'Tie::File', "$MOVEFILE" or die;
    $COUNT=0; $found="";
    $len = scalar @LST;
    foreach (@LST)
    {
      $COUNT++;
      if ( ! $moved )
      {
        if ( $len == $MOVEREC )
        {
           $found="$LST[$len-1]"; $moved="1";
            push @NEWLST, "$LST[$len-1]";  $found="";
        }
      }
      if ( $COUNT == $MOVEREC )  { $found="$_";  }
      else
      {
            if ( "$found" ) { push @NEWLST, "$_";  push @NEWLST, "$found"; $found=""; }
            else {  push @NEWLST, "$_"; $found=""; }
      }
    }
    @LST=@NEWLST;
    untie(@LST);
}


###
### TASK Delete Group/Category/Assignee
###
sub delete_task_gta
{
   @LST=(); @NEWLST=();
   tie @LST, 'Tie::File', "$FILE" or die; 
   $COUNT=0;
   foreach (@LST)
   {
     $COUNT++;
     if ( $COUNT != $form{num} ) { push(@NEWLST, "$_"); }
     else { $del_line="$_"; }
   }
   @LST=@NEWLST;
   untie(@LST);
   ($ckltitle,$cklfile)=split(/\t/,$del_line);
   if ( $form{sact} eq "bcklists" || $form{sact} eq "retlists" ) { `rm -f $ASMDIR/default/$cklfile`; }
}


###
### Create Tasks
###
sub create_task
{
#print "buffer = $buffer<p>";
  #
  # If a sub action is passed get Title and Desc
  #
  if ( "$form{sact}" )
  {
    open (PRO, "$TSKDIR/$form{taskid}/$form{taskid}.pro" )  || print "Profile $TSKDIR/$form{taskid}/$form{taskid}.pro does not exist";
    while (<PRO>)
    { 
      chomp;
      if ( /^name\t/ ) { ($d, $form{tskname}) = split(/\t/, $_); }
      if ( /^desc\t/ ) { ($d, $form{tskdesc}) = split(/\t/, $_); }
    }
    close(PRO);
    if ( $form{sact} eq "delg" ) { $FILE="$TSKDIR/$form{taskid}/$form{taskid}.grp"; delete_task_gta; }
    if ( $form{sact} eq "delt" ) { $FILE="$TSKDIR/$form{taskid}/$form{taskid}.tag"; delete_task_gta; }
    if ( $form{sact} eq "dela" ) { $FILE="$TSKDIR/$form{taskid}/$form{taskid}.asn"; delete_task_gta; }
  }

  $taskid="";
  if ( ! "$form{taskid}" && "$form{tskname}" )
  {
      $valid="";
      while ( ! $valid  )
      {
        my $random_string=&get_token(6);
        &get_token;
        $number="$random_string";
        if ( ! -d "$TSKDIR/${number}" ) { $valid="1"; }
      }
      $taskid = "$number";
      if ( ! -d "$TSKDIR/$taskid" ) 
      { `mkdir -p "$TSKDIR/$taskid"`; }

      #
      # Write to task index file
      #
      open(TSK, ">> $TASK" ) || print "CANNOT WRITE $TASK";
      print TSK "$form{tskname}\t$taskid\n";
      close(TSK);
      $form{taskid} = "$taskid";

      # Sort file
      tie @LST, 'Tie::File', "$TASK" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);

  }

  #
  # Write out changes
  #
  if ( $form{tskname} ) 
  {
    $taskid="$form{taskid}";

    # $ID=form{Task/Track/FreeID} / $NEWNAME=$form{name} $FILE=/etc/file
    # check if name changed and update index
    #
    $curName="";
    open(TSKD, "$TASK" ) || print "CANNOT read: $TASK";
    while (<TSKD>) 
    { 
	chomp; 
	if ( /\t$form{taskid}/ ) { ($idxName,$d)=split(/\t/, $_); } 
    }
    close(TSKD);
    if ( "$idxName" ne "$form{tskname}" ) 
    { 
      $ID="$taskid"; $FILE="$TASK"; 
      $NEWNAME="$form{tskname}"; index_namechg; 
      # Sort file
      tie @LST, 'Tie::File', "$TASK" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    }
    # Write Profile data structure.
    #
    open(TSKD, "> $TSKDIR/$taskid/$taskid.pro" ) || print "CANNOT write: $TSKDIR/$taskid/$taskid.pro";
    print TSKD "id\t$taskid\n";
    print TSKD "name\t$form{tskname}\n";
    print TSKD "desc\t$form{tskdesc}\n";
    close(TSKD);


    #
    # WRITE OUT GROUP
    #
    if ( "$form{tskgrps}" )
    {
      `touch $TSKDIR/$form{taskid}/$form{taskid}.grp`; 

      # CHECK IF ENTRY IS DUPLICATE
      $found="";
      open(GRP, "$TSKDIR/$form{taskid}/$form{taskid}.grp" )|| print "CANNOT FIND  $TSKDIR/$form{taskid}/$form{taskid}.grp";
      while(<GRP>) 
	{ chomp; if ( /^$form{tskgrps}/) { $found="1"; }  }
      close(GRP);
      if ( ! "$found" )
      {
        open(WGRP, ">> $TSKDIR/$form{taskid}/$form{taskid}.grp" )|| print "CANNOT WRITE $TSKDIR/$form{taskid}/$form{taskid}.grp";
        print WGRP "$form{tskgrps}\n";
        close(WGRP);
        tie @LST, 'Tie::File', "$TSKDIR/$form{taskid}/$form{taskid}.grp" or die; 
        @NEWLST=sort @LST;
	@LST=@NEWLST;
   	untie(@LST);
      }
    } # End Write group

    #
    # WRITE OUT TAGS
    #
    if ( "$form{tsktags}" )
    {
      `touch $TSKDIR/$form{taskid}/$form{taskid}.tag`; 

      # CHECK IF ENTRY IS DUPLICATE
      $found="";
      open(TAG, "$TSKDIR/$form{taskid}/$form{taskid}.tag" )|| print "CANNOT FIND  $TSKDIR/$form{taskid}/$form{taskid}.tag";
      while(<TAG>) 
	{ chomp; if ( /^$form{tsktags}/) { $found="1"; }  }
      close(TAG);
      if ( ! "$found" )
      {
        open(WTAG, ">> $TSKDIR/$form{taskid}/$form{taskid}.tag" )|| print "CANNOT WRITE $TSKDIR/$form{taskid}/$form{taskid}.tag";
        print WTAG "$form{tsktags}\n";
        close(WTAG);
        tie @LST, 'Tie::File', "$TSKDIR/$form{taskid}/$form{taskid}.tag" or die; 
        @NEWLST=sort @LST;
	@LST=@NEWLST;
   	untie(@LST);
      }
    }  # End write Category
    #
    # WRITE ASSIGNEE
    #
    if ( "$form{tskassn}" )
    {
      `touch $TSKDIR/$form{taskid}/$form{taskid}.asn`; 

      # CHECK IF ENTRY IS DUPLICATE
      $found="";
      open(ASN, "$TSKDIR/$form{taskid}/$form{taskid}.asn" )|| print "CANNOT FIND  $TSKDIR/$form{taskid}/$form{taskid}.asn";
      while(<ASN>) { chomp; if ( /^$form{tskassn}/)  { $found="1";  } }
      close(ASN);
      if ( ! "$found" )
      {
        open(WASN, ">> $TSKDIR/$form{taskid}/$form{taskid}.asn" )|| print "CANNOT WRITE $TSKDIR/$form{taskid}/$form{taskid}.asn";
        print WASN "$form{tskassn}\n";
        close(WASN);
        tie @LST, 'Tie::File', "$TSKDIR/$form{taskid}/$form{taskid}.asn" or die; 
        @NEWLST=sort @LST;
	@LST=@NEWLST;
   	untie(@LST);
      }
    } # End write assignee
  } # end of writes

  #
  # DISPLAY CREATE TASK PAGE
  #
  if ( $form{taskid} ) 
  { 
	$HiddenID="<input type=hidden name=taskid value=\"$form{taskid}\">";
	$showname="<font $fsb> | </font><font $fsbl><a href=$ITKASMTSK?ID=$form{taskid} class=\"hoverlink\" title=\"Go To $form{tskname}\" style=\"color:$lnkcolor\">$form{tskname}</a></font>";
	$createkave="<font $fsb>Step 2: </font><font $fsbl><a href=$ITKASM?act=ckave&kid=task:$form{taskid} class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create a KAVE</a></font>";
	$CRTUPD="Update"; 
	$CRTLINK="<font $fsbl> | <a href=$ITKASM?act=ctask class=\"hoverlink\" title=\"Create New Task Mine\" style=\"color:$lnkcolor\">Create Task</a></font>";
  }
  else { $CRTUPD="Create"; $CRTLINK=""; }
  print qq~
      $hr_line
      <table width=100% bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
      <font $fsbl><a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a></font>
      <font $fsb> | </font>
      <font $fsbl><a href=$ITKASM?act=listtsk class=\"hoverlink\" title="List available Task Mines" style=\"color:$lnkcolor\">List Tasks</a></font>
      <font $fsb> | <b>$CRTUPD Task</b> </font>
      $CRTLINK
      $showname
      </td><td valign=top align=right width=15%>
	$createkave
      </td>
      </table>
  <!--             -->
  <!-- CREATE TASK -->
  <!--             -->
      $hr_line
      <p>
  <table border=0>
<td>
      <form method=post action=$ITKASM>
        <input type=hidden name=act value=ctask>
	$HiddenID
      <table border=0>
        <tr><td valign=top>
        <font $fsn><b>Task Title: </b></font>
	</td><td>
        <input type=text size=25 name="tskname" value="$form{tskname}"><br>
        </td></tr><tr><td valign=top>
        <font $fsn><b>Task Description: </b></font>
	</td><td>
        <input type=text size=40 name="tskdesc" value="$form{tskdesc}"><b><p>
        </td></tr>
        </td></tr><tr><td valign=top>
        <font $fsn><b>Task ID: </b></font>
	</td><td>
        $form{taskid}<p>
        </td></tr>
      </table>
      <br>
	<table border=0 cellpadding=3> <td valign=top>
        <font $fsn><b>Add Group:</b></font>
        <input type=text size=15 name="tskgrps" value="">
        <hr size=1>
  ~;
  if ( -f "$TSKDIR/$form{taskid}/$form{taskid}.grp" )
  {
    print "<table width=100% border=0>\n";
    $grpcnt=0;
    open(TSKD, "$TSKDIR/$taskid/${taskid}.grp" ) || print "CANNOT read: $TSKDIR/$taskid/$taskid.grp";
    while (<TSKD>)
    {
      $grpcnt++;
      chomp;
      print qq~
	<tr><td valign=top><font $fsn>$_</font></td>
	<td>
	  <a href=$ITKASM?act=ctask&taskid=$form{taskid}&sact=delg&num=$grpcnt height=15>
	  <img src=$IMAGES/trashcan.png height=15 border=0>
        </td></tr> 
      ~;
    }
    close(TSKD);
    print "</table>";
  }
  print qq~
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td valign=top>
        <font $fsn><b>Add Category:</b></font>
        <input type=text size=15 name="tsktags" value="">
	<hr size=1>
  ~;
  if ( -f "$TSKDIR/$form{taskid}/$form{taskid}.tag" )
  {
    print "<table width=100% border=0>\n";
    $tagcnt=0;
    open(TSKD, "$TSKDIR/$taskid/${taskid}.tag" ) || print "CANNOT read: $TSKDIR/$taskid/$taskid.tag";
    while (<TSKD>)
    {
      $tagcnt++;
      chomp;
      print qq~
	<tr><td valign=top><font $fsn>$_</font></td>
	<td>
  	  <a href=$ITKASM?act=ctask&taskid=$form{taskid}&sact=delt&num=$tagcnt height=15>
	  <img src=$IMAGES/trashcan.png height=15 border=0>
        </td></tr> 
      ~;
    }
    close(TSKD);
    print "</table>\n";
  }
  print qq~
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td valign=top halign=left>
        <font $fsn><b>Add Assignee:</b></font>
        <select name='tskassn' onchange='this.form.submit()'>
        <option value=\"\" selected></option>
  ~;
  @users=();
  open(USR, "$USERS") || print "Cannot find $USERS";
  while (<USR>) 
  { chomp; ($UUID, $UPWD, $ufname, $ulname) = split (/\t/, $_); push(@users, "$ulname\t$ufname\t$UUID"); }
  close(USR);
  @users = sort @users;
  foreach (@users)
  {
	  ($ulname, $ufname, $UUID) = split (/\t/, $_);
          if ( ! /Administrator/i )  
	  { print "<option value=\"$UUID\" >${ulname}, ${ufname}</option>\n"; }
  }
  print "</select><hr size=1>";

  # LIST ASSIGNEE'S
  if ( -f "$TSKDIR/$form{taskid}/$form{taskid}.asn" )
  {
    print "<table width=100% border=0>\n";
    $asncnt=0; @asn=();
    open(ASN, "$TSKDIR/$form{taskid}/$form{taskid}.asn" )|| print "CANNOT FIND  $TSKDIR/$form{taskid}/$form{taskid}.asn";
    while(<ASN>) 
    { 
	chomp; 
	$asncnt++; $userID="$_"; &convert_user;
	push(@asn, "$ulname\t$ufname$_\t$asncnt"); 
    }
    close(ASN);
    @asn = sort @asn;
    foreach (@asn)
    {
	($ulname, $ufname, $asncnt) = split (/\t/, $_);
        if ( $ulname || $ufname ) 
	 { 
	    print qq~
		<tr><td valign=top><font $fsn>${ulname}, ${ufname}</font></td>
		<td>
		<a href=$ITKASM?act=ctask&taskid=$form{taskid}&sact=dela&num=$asncnt height=15>
		<img src=$IMAGES/trashcan.png height=15 border=0>
	        </td></tr> 
	    ~;
 	  }
    }
    print "</table>";
  }
  print qq~
        </table>
        <p> $hr_line
        <input type=submit name=save value="Save">
      </form>
</td><td valign=top>
  ~;
    # SHOW KAVES DEFINED FOR MINE
    $mineid="$form{taskid}"; $minename="$form{tskname}";
    $MINEDIR="$TSKDIR/$form{taskid}";$minetype="task";
    list_kaves_def;

    if ( $form{taskid} ) 
    {
      @MINEARGS=("act=ctask","taskid=$form{taskid}","sact=1");
      &mine_access;
    }
  print qq~
</td>
</table>
  ~;
}


###
### LIST ALL TASKS CREATED
###
sub list_tasks
{
    if ( $form{tid} )
    { $createkave="Step 2: <a href=\"$ITKASM?act=ckave&kid=task:$form{tid}\" class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create A Kave</a>"; }
    print qq~
        $hr_line
	<table width=100% bgcolor=$hdrcolor cellpadding=3><td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> 
	 | </font>
	<font $fsb><b>List Tasks</b> | </font>
	<font $fsbl>
        <a href=$ITKASM?act=ctask class=\"hoverlink\" title="Create a Task Mine" style=\"color:$lnkcolor\">Create Task</a>
	</font></td><td valign=top align=right><font $fsbl>
	$createkave
	</font></td></table>
        $hr_line
        <font $fsn>Click to View Task Profile or Edit:</font><p>
        <table border=0 width=100%>
        <tr valign=top>
        <td align=center><b><font $fsb>Tasks</font><br><hr size=1 ></b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td align=center ><b><font $fsb>Groups<br><hr size=1 ></font></b></td>
	<td align=center ><b><font $fsb>Category<br><hr size=1 ></font></b></td>
	<td align=center ><b><font $fsb>Assignee<br><hr size=1 ></font></b></td>
	<td align=center ><b><font $fsb>Access<br><hr size=1 ></font></b></td>
        <tr><td valign=top>
        <table cellpadding=3 cellspacing=3>
    ~;
    #
    # Read the task.dat file and get the titles and id's.
    #
    $foundrec="";
    if ( ! -f "$TASK" ) { `touch $TASK`; }
    open(TSK, "$TASK" ) || print "CANNOT OPEN TASK DATA $TASK";
    while (<TSK>)
    {
      chomp;
      ($ttitle, $tid)=split(/\t/, $_);
      #
      # Get all the profile info
      #
      @TRKPRO="";
      open(TPROF, "$TSKDIR/$tid/$tid.pro") || print "CANNOT OPEN $TSKDIR/$tid/$tid.pro";
      while(<TPROF>) { chomp; push @TSKPRO, "$_"; $foundrec="1"; }
      close(TPROF);
      shift @TSKPRO;
      foreach (@TSKPRO)
      { if ( /desc/ ) { ($d1, $tdesc)=split(/\t/, $_); } }
      #
      # Diplay the title and description
      #
      if ( $tid eq $form{tid} ) { $tline="<b>$ttitle</b> | ID: $tid"; $clTITLE="$ttitle"; @vTSKPRO=@TSKPRO; }
      else { $tline="<a href=$ITKASM?act=listtsk&tid=$tid class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"View \'$ttitle\' Task Profile\">$ttitle</a>"; }
      print qq~
          <tr><td nowrap valign=top><font $fsn>
                <a href=$ITKASM?act=ctask&taskid=$tid&sact=1 title="Edit \'$ttitle\' profile"><img src=$IMAGES/edit.png height=12 border=0></a> 
		&nbsp;
                <a href=$ITKASMTSK?ID=$tid title="Go to \'$ttitle\' page"><img src=$IMAGES/redirect.png height=12 border=0></a> 
		&nbsp;
	$tline
          </font></td><td><font $fsn>$tdesc</font></td></tr>
      ~;
    }
    close(TSK);
      if ( ! "$foundrec" ) { print "<font $fsb><b><i>Nothing Created...</i></b></font>"; }
    print "</td></table><td>";
    #
    # DISPLAY GROUPS
    #
    if ( -s "$TSKDIR/$form{tid}/$form{tid}.grp" )
    {
      print "<td valign=top nowrap><font $fsn>\n";
      open(TGRP, "$TSKDIR/$form{tid}/$form{tid}.grp" ) || print "CANNOT OPEN $TSKDIR/$form{tid}/$form{tid}.grp";
      while(<TGRP>) { chomp; print "$_<br>"; }
      close(TGRP);
      print "</font></td>\n";
    }
    else { print "<td></td>"; }
    #
    # DISPLAY TAGS
    #
    if ( -s "$TSKDIR/$form{tid}/$form{tid}.tag" )
    {
      print "<td valign=top nowrap><font $fsn>\n";
      open(TTAG, "$TSKDIR/$form{tid}/$form{tid}.tag" ) || print "CANNOT OPEN $TSKDIR/$form{tid}/$form{tid}.tag";
      while(<TTAG>) { chomp; print "$_<br>"; }
      close(TTAG);
      print "</font></td>\n";
    }
    else { print "<td></td>"; }
    #
    # DISPLAY ASSIGNEE
    #
    if ( -s "$TSKDIR/$form{tid}/$form{tid}.asn" )
    {
      print "<td valign=top nowrap><font $fsn>\n";
      open(TASN, "$TSKDIR/$form{tid}/$form{tid}.asn" ) || print "CANNOT OPEN $TSKDIR/$form{tid}/$form{tid}.asn";
      while(<TASN>) 
      { 
	chomp; 
        $userID="$_"; &convert_user;
        if ( $ulname || $ufname ) { print "$ulname, $ufname<br>\n" }
      }
      close(TASN);

      print "</font></td>\n";
    }
    else { print "<td></td>"; }
   print "<td valign=top>";
    if ( $form{taskid} ) 
    {
      $MINEDIR="$TSKDIR/$form{tid}";
      &display_mineaccess; 
    }
   print "</td>"; 
  print "</table>";
}



###
### LIST KNOWLEDGEBASE (KBASE)
###
sub list_kbase
{
  print qq~
    $hr_line
    <table width=100% bgcolor=$hdrcolor cellpadding=3>
    <td align=left>
      <font $fsbl>
      <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
      </font><font $fsb>
       | <b>List KnowledgeBase</b> |</font><font $fsbl>
      <a href=$ITKASM?act=ckbase class=\"hoverlink\" title="Create a KnowledgeBase" style=\"color:$lnkcolor\">Create KnowledgeBase</a> 
      </font>
    </td>
    </table>
    $hr_line
    <!--              -->
    <!-- LIST KBASE -->
    <!--              -->
    <font $fsn>Click to edit a Knowledge Base:</font><p>
<table border=0 width=100%>
<td>
  <table border=0 width=100%>
  <td valign=top width=50%>
    <table border=0>
    <tr valign=top>
      <td align=center><b><font $fsb>Knowledge Bases</font><br><hr size=1 ></b></td>
    </tr><td valign=top>
    <table border=0 cellpadding=3 cellspacing=3>
  ~;
    $foundrec="";
    if ( ! -f "$KBASE" ) { `touch $KBASE`; }
    open(KB, "$KBASE" ) || print "CANNOT OPEN KBASE $KBASE";
    while (<KB>)
    {
      chomp;
      $foundrec="1";
      ($kbtitle, $kbid)=split(/\t/, $_);
      open(KBPROF, "$KBASEDIR/$kbid/$kbid.pro") || print "CANNOT OPEN $KBASEDIR/$kbid/$kbid.pro";
      while(<KBPROF>) { chomp; if ( /desc/ ) { ($d1, $kbdesc)=split(/\t/, $_); } }
      close(KBPROF);

      if ( $form{tid} eq $kbid ) { $tline="<font $fsn><b>$kbtitle</b>"; $kbdesc="<b>$kbdesc</b>";}
      else { $tline="<font $fsnl><a href=$ITKASM?act=listkbase&tid=$kbid class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"View \'$kbtitle\' KBase Profile\">$kbtitle</a>";}
      print qq~
        <tr><td nowrap valign=top>
          <a href="$ITKASM?act=ckbase&kbid=$kbid&from=1" title="Edit \'$kbtitle\' profile"><img src=$IMAGES/edit.png height=12 border=0></a>
	  &nbsp;
          <a href=$ITKASMKBASE?ID=$kbid title="Go to \'$kbtitle\' page"><img src=$IMAGES/redirect.png height=12 border=0></a>
 	  &nbsp;
          $tline
        </font></td><td><font $fsn>$kbdesc</font></td></tr>
      ~;
    }
    close(KB);
    if ( ! "$foundrec" ) { print "<font $fsn><b>Nothing Defined...</b></font>"; }
    print "</table></td>\n";
  print qq~
    </td></table>
    <td valign=top>
  ~;
  if ( $form{tid} )
  {
    print "<table border=0>
  <td valign=top>
  <center><font $fsb><b>Access</b></font></center><hr size=1><br>";
    $MINEDIR="$KBASEDIR/$form{tid}";
    &display_mineaccess;
   print "</td></table>";
  }
  print qq~
    </td>
    </table>
  ~;
}


###
### CREATE A KNOWLEDGEBASE (KBASE)
###
sub create_kbase
{
#print "buffer = $buffer<p> $form{srchid}";
  # Check if coming from list to be editted
  # If so load the name and content
  if ( $form{sact} || $form{from} )
  {
    $form{kbname}="";
    open(KB, "$KBASEDIR/$form{kbid}/$form{kbid}.pro" ) || print "CANNOT read: $KBASEDIR/$form{kbid}/$form{kbid}.pro";
    while(<KB>)
    {
        chomp;
        if ( /^name\t/) { ($d, $form{kbname})=split(/\t/, $_); }
        if ( /^desc\t/) { ($d, $form{kbdesc})=split(/\t/, $_); }
    }
    close(KB);
   }
  $kbid="";
  if ( ! "$form{kbid}" && "$form{kbname}" )
  {
      $valid="";
      while ( ! $valid  )
      {
        my $random_string=&get_token(6);
        &get_token;
        $number="$random_string";
        if ( ! -d "$KBASEDIR/${number}" ) { $valid="1"; }
      }
      $kbid = "$number";
      if ( ! -d "$KBASEDIR/$kbid" )
      { `mkdir -p "$KBASEDIR/$kbid"`; }

      #
      # Write to Search index file
      #
      open(KBW, ">> $KBASE" ) || print "CANNOT WRITE SEARCH DATA: $SRCH";
      print KBW "$form{kbname}\t$kbid\n";
      close(KBW);
      $form{kbid} = "$kbid";

      # Sort file
      tie @LST, 'Tie::File', "$KBASE" or die;
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
  }
  #
  # IF KBASE NAME IS ENTERED OR CHANGED
  #
  if ( $form{kbname} )
  {
    $kbid="$form{kbid}";
    #
    # check if name changed and update index
    #
    $curName="";
    if ( ! -s "$KBASE" ) { `touch $KBASE`; }
    open(KB, "$KBASE" ) || print "CANNOT read: $KBASE";
    while (<KB>)
    {
        chomp;
        if ( /\t$form{kbid}/ ) { ($idxName,$d)=split(/\t/, $_); }
    }
    close(KB);
    if ( "$idxName" ne "$form{srchname}" )
    {
      $ID="$kbid"; $FILE="$KBASE";
      $NEWNAME="$form{kbname}"; index_namechg;
      # Sort file
      tie @LST, 'Tie::File', "$SRCH" or die;
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    }

    #
    # Create KBASE data structure.
    #
    open(KBW, "> $KBASEDIR/$form{kbid}/$form{kbid}.pro" ) || print "CANNOT write: $KBASEDIR/$form{kbid}/$form{kbid}.pro";
    print KBW "id\t$kbid\n";
    print KBW "name\t$form{kbname}\n";
    print KBW "desc\t$form{kbdesc}\n";
    close(KBW);
  }

  #
  # DISPLAY CREATE KBASE PAGE
  #
  if ( $form{kbid} )
  {
        $HiddenID="<input type=hidden name=kbid value=\"$form{kbid}\">";
        $createkave="<font $fsb>Step 2: </font><font $fsbl><a href=$ITKASM?act=ckave&kid=kbase:$form{kbid} class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create a KAVE</a></font>";
  }
  if ($form{kbid}) 
  { 
    $create_kbase="<font $fsb> | </font><font $fsbl><a href=$ITKASM?act=ckbase class=\"hoverlink\" title=\"Create a KnowledgeBase\" style=\"color:$lnkcolor\">Create KnowledgeBase</a></font>"; 
    $goto_kbase="<font $fsbl> | <a href=$ITKASMKBASE?ID=$kbid class=\"hoverlink\" title=\"Goto $kbname KnowledgeBase\" style=\"color:$lnkcolor\">$form{kbname}</a></font>"; 
    $CRTUPD="<font $fsb> | <b>Update KnowledgeBase</b></font>";
  }
  else { $create_kbase="<font $fsb> | <b>Create KnowledgeBase</b></font>"; $CRTUPD="";}
  print qq~
      $hr_line
      <table width=100% bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
      <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a></font>
	<font $fsb> | </font>
      <font $fsbl><a href=$ITKASM?act=listkbase class=\"hoverlink\" title="List available Search Mines" style=\"color:$lnkcolor\">List KnowledgeBase</a></font>
      $CRTUPD
      $create_kbase $goto_kbase
      </td><td valign=top align=right width=15%>
        $createkave
      </td>
      </table>
  <!--             -->
  <!-- CREATE KBASE -->
  <!--             -->
      $hr_line
  <table border=0 width=100%>
  <td valign=top>
      <p>
      <form method=post action=$ITKASM>
        <input type=hidden name=act value=ckbase>
        $HiddenID
      <table border=0 cellpadding=3>
      <tr><td align=right valign=top>
        <font $fsn><b>KnowledgeBase Title: </b></font>
        </td><td align=left>
        <input type=text size=20 name="kbname" value="$form{kbname}"><p>
        </td>
      </tr><tr><td align=right valign=top>
        <font $fsn><b>KnowledgeBase Description: </b></font><br>&nbsp;
        </td><td valign=top>
        <input type=text size=40 name="kbdesc" value="$form{kbdesc}">
        </td>
      </tr><tr>
	<td align=right valign=top><font $fsn><b>KnowledgeBase ID: </b></font></td>
	<td valign=top><font $fsn>$form{kbid}<p></font></td>
      </tr>
      </tr>
      </table>
      <p> $hr_line
        <input type=submit name=save value="Save">
      </form>
  </td>
  <td valign=top width=50%>
  ~;
    # SHOW KAVES DEFINED FOR MINE
    $mineid="$form{kbid}"; $minename="$form{kbname}";
    $MINEDIR="$KBASEDIR/$form{kbid}"; $minetype="knowledgebase";
    list_kaves_def;

    if ( $form{kbid} ) 
    {
     @MINEARGS=("act=ckbase","kbid=$form{kbid}","from=1");
     &mine_access;
    }
  print "</td></table>";
}


###
### GENERATE ON CALENDAR
sub generate_cal
{
  print "<p> $hr_line";
  #
  # Get list of users
  @USERS=();
  open(USR, "$USERS") || print "Cannot find $USERS";
  while (<USR>) { chomp; push @USERS, "$_"; }
  close(USR);
  #
  # Get list of OCL's
  open(ROCL, "$ONCDIR/$form{oncallid}/$form{oncallid}.ocl" )|| print "CANNOT WRITE $ONCDIR/$form{oncallid}/$form{oncallid}.ocl";
  while (<ROCL>){ chomp; push @OCL, $_; }
  close(ROCL);

  $x=0; $PLIST="";
  # Set up to show in Header
  foreach (@OCL)
  { 
    $x++;
    if ( $x > 1 ) { $PLIST="$PLIST : $_"; }
    else { $PLIST="$_"; }
  } 

  # Get list of oncall people
  @OCP=();
  $cntOCL=0; $cntASN=0;
  foreach $ocl (@OCL)
  {
    $cntOCL++; 
    $cntASN=0;
    open(ASN, "$ONCDIR/$form{oncallid}/$form{oncallid}.asn-${ocl}" )|| print "CANNOT WRITE $ONCDIR/$form{oncallid}/$form{oncallid}.asn-${ocl}";
    while (<ASN>)
    { 
	chomp; 
	$cntASN++;
	$OCP[$cntOCL][$cntASN]="$_";
#print "$_ $cntOCL.$cntASN<br>\n";
    } 
    close(ASN);
  }
#print "OCP = $OCP[2][2]<br>\n";

  #
  # Get the first starting day
  #
  $today=`date +%m/%d/%Y`;
  ($today_m, $today_d, $today_y) = split (/\//, $today);
  $date = Calendar::Any->new_from_Gregorian($today_m, $today_d, $today_y);
  $tday_wkday = $date->date_string("%W");
  $tday_DT = $date->date_string("%M %d %Y");
  chomp($tday_DT);
  if ( $form{occur} eq "Weekly" )
  {
    for (my $i=0; $i <= 6; $i++)
    {
      $found="";
      $newdate = $date + $i;
      $nxt_wkday = $newdate->date_string("%W");
      $SDT = $newdate->date_string("%D");
      if ( "$OCDAY" eq "$nxt_wkday" ) { $found="1"; $START_DAY="$SDT"; }
    }
  }
  elsif ( $form{occur} eq "Daily" )
  {
      $found="";
    for (my $i=0; $i <= 6; $i++)
    {
      $newdate = $date + $i;
      $nxt_wkday = $newdate->date_string("%W");
      $SDT = $newdate->date_string("%D");
      foreach $DY (@ALLDAYS)
      {
      if ( ("$ROTDAY[$DY-1]" eq "$nxt_wkday") && ! $found ) { 
	$found="1"; 
#print "$DY $ROTDAY[$DY-1] eq $nxt_wkday $found<br>";
	$START_DAY="$SDT"; }
      }
    }
  }
#print "today = ${tday_wkday} = $tday_DT / Starting on $OCDAY - $START_DAY<br>\n"; 

  #
  # List 3 years worth 1095 days
  #
  open(WCAL, "> $ONCDIR/$form{oncallid}/$form{oncallid}.cal" )|| print "CANNOT WRITE $ONCDIR/$form{oncallid}/$form{oncallid}.cal";
  ($start_m, $start_d, $start_y) = split (/\//, $START_DAY);
  $date = Calendar::Any->new_from_Gregorian($start_m, $start_d, $start_y); 
  $cntASN=0;
  for ($c=0; $c < 1095; $c++)
  {
    $calmo = $date->date_string("%M");
    $calyr = $date->date_string("%Y");
    $caldw = $date->date_string("%W");
    $caldy = $date->date_string("%d");
    $calall = $date->date_string("%F");
    
    #
    # Display the oncall people
    #
    if ( $form{occur} eq "Weekly" )
    {
      if ( "$caldw" eq "$OCDAY" ) 
      { 
	$OCWEEKs="$date"; $OCWEEKe=$date+6; $OCWEEK="\t${OCWEEKs}-${OCWEEKe}";
        $cntOCL=0;
        $cntASN++;
        foreach (@OCL)
        {
           $cntOCL++; 
           if ( ! $OCP[$cntOCL][$cntASN] ) { $cntASN=1; }
           foreach $u (@USERS)
           {
             ($UUID, $UPWD, $fname, $lname) = split (/\t/, $u);
	     if ( "$UUID" eq "$OCP[$cntOCL][$cntASN]") { $person="$fname $lname"; }
           }
           if ( $cntOCL > 1 ) { $people="$people:$person"; }
           else { $people="$person"; }
        }
      } # END WEEKLY 
    }
    if ( $form{occur} eq "Daily" )
    {
      $fndnxtday=""; $OCWEEK="";
      foreach $nxt_ocday (@ALLDAYS)
      {
        if ( "$caldw" eq "$ROTDAY[$nxt_ocday-1]") { $fndnxtday="1"; }
#print "$caldw - $ROTDAY[$nxt_ocday]<br>\n";
      }
      if ( "$fndnxtday" )
      {
        $cntOCL=0;
        $cntASN++;
        foreach (@OCL)
        {
           $cntOCL++;
           if ( ! $OCP[$cntOCL][$cntASN] ) { $cntASN=1; }
           foreach $u (@USERS)
           {
             ($UUID, $UPWD, $fname, $lname) = split (/\t/, $u);
             if ( "$UUID" eq "$OCP[$cntOCL][$cntASN]") { $person="$fname $lname"; }
           }
           if ( $cntOCL > 1 ) { $people="$people:$person"; }
           else { $people="$person"; }  
        }
      }
### COMMENT OUT IF ASSIGN LAST ONCALL DURING OFF DAYS
      else 
      {         
        $cntOCL=0;
        foreach (@OCL)
        {
           $cntOCL++;
           if ( $cntOCL > 1 ) { $people="$people:Unassigned"; }
           else { $people="Unassigned"; }  
        }
      }
###
    }       # END DAILY

    $date++;
    print WCAL "$calall\t$caldw\t${people}${OCWEEK}\n";
  }
  close(WCAL);
}


###
### Create Oncall
###
sub create_oncall
{
#print "buffer = $buffer<p>";
  $ck_name=""; $ck_occur=""; $ck_day=""; $ck_hr="";
  $ck_min=""; $ck_ocl=""; $ck_asn="";
  #
  # If a sub action is passed get Title and Desc
  #
  if ( "$form{sact}" || $form{from} )
  {
    if ( $form{ID} ) { $form{oncallid}="$form{ID}"; }
    @ALLDAYS=();
    open (PRO, "$ONCDIR/$form{oncallid}/$form{oncallid}.pro" )  || print "Profile $ONCDIR/$form{oncallid}/$form{oncallid}.pro does not exist";
    while (<PRO>)
    {
      chomp;
      if ( /^name\t/ ) { ($d, $form{oncname}) = split(/\t/, $_); $ck_name="1"; }
      if ( /^desc\t/ ) { ($d, $form{oncdesc}) = split(/\t/, $_); }
      if ( /^occur\t/ ) { ($d, $form{occur}) = split(/\t/, $_);  $ck_occur="1"; }
      if ( /^ocday\t/ ) { ($d, $form{ocday}) = split(/\t/, $_);  $ck_day="1"; }
      if ( /^ochr\t/ ) { ($d, $form{ochr}) = split(/\t/, $_);    $ck_hr="1"; }
      if ( /^ocmin\t/ ) { ($d, $form{ocmin}) = split(/\t/, $_);  $ck_min="1"; }
      if ( /^active\t/ ) { ($d, $form{ocactive}) = split(/\t/, $_); }
      if ( /^ocdays\t/ ) { ($d, $ocdays) = split(/\t/, $_); push @ALLDAYS, $ocdays;  }
    }
    close(PRO);

    if ( $form{sact} eq "dela" ) { $FILE="$ONCDIR/$form{oncallid}/$form{oncallid}.asn-$form{osubt}"; delete_task_gta; }
    if ( $form{sact} eq "delst" ) { $FILE="$ONCDIR/$form{oncallid}/$form{oncallid}.ocl"; delete_task_gta; `rm -f "$ONCDIR/$form{oncallid}/$form{oncallid}.asn-$del_line"`; }
  }

  $oncallid="";
  if ( ! "$form{oncallid}" && "$form{oncname}" )
  {
      $valid="";
      while ( ! $valid  )
      {
        my $random_string=&get_token(6);
        &get_token;
        $number="$random_string";
        if ( ! -d "$ONCDIR/${number}" ) { $valid="1"; }
      }
      $oncallid = "$number";
      if ( ! -d "$ONCDIR/$oncallid" )
      { `mkdir -p "$ONCDIR/$oncallid"`; }

      #
      # Write to oncall index file 
      #
      open(ONC, ">> $ONCALL" ) || print "CANNOT WRITE $ONCALL";
      print ONC "$form{oncallid}\t$oncallid\n";
      close(ONC);
      $form{oncallid} = "$oncallid";

      # Sort file
      tie @LST, 'Tie::File', "$ONCALL" or die;
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
  }

  #
  # Write out changes
  #
  if ( $form{oncname} )
  {
    $oncallid="$form{oncallid}";

    # $ID=form{Task/Track/FreeID} / $NEWNAME=$form{name} $FILE=/etc/file
    # check if name changed and update index
    #
    $curName="";
    open(ONCD, "$ONCALL" ) || print "CANNOT read: $ONCALL";
    while (<ONCD>)
    {
        chomp;
        if ( /\t$form{oncallid}/ ) { ($idxName,$d)=split(/\t/, $_); }
    }
    close(ONCD);
    if ( "$idxName" ne "$form{oncname}" )
    {
      $ID="$oncallid"; $FILE="$ONCALL";
      $NEWNAME="$form{oncname}"; index_namechg;
      # Sort file
      tie @LST, 'Tie::File', "$ONCALL" or die;
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    }

    #
    # Write Profile data structure.
    #
    if ( ! $form{from} ) 
    {
      open(ONCD, "> $ONCDIR/$oncallid/$oncallid.pro" ) || print "CANNOT write: $ONCDIR/$oncallid/$oncallid.pro";
      print ONCD "id\t$oncallid\n"; 
      print ONCD "name\t$form{oncname}\n"; $ck_name="1";
      print ONCD "desc\t$form{oncdesc}\n";
      print ONCD "occur\t$form{occur}\n";  $ck_occur="1";
      if ( $form{ocday} ) { print ONCD "ocday\t$form{ocday}\n"; $ck_day="1"; } 
      print ONCD "ochr\t$form{ochr}\n"; $ck_hr="1";
      print ONCD "ocmin\t$form{ocmin}\n"; $ck_min="1";
      print ONCD "active\t$form{ocactive}\n";
      @ALLDAYS=();
      foreach $alldays (@pairs)
      {
        if ( $alldays =~ /ocdays=/)
        {
          chomp($alldays);
          ($d1, $f) = split (/=/, $alldays);
	  if ( $f ) { print ONCD "ocdays\t$f\n"; push @ALLDAYS, $f; $ck_days="1"; }
        }
      }
      close(ONCD);
    }

    if ( -s "$ONCDIR/$oncallid/$oncallid.ocl" ) 
    {
      open (OCL, "$ONCDIR/$oncallid/$oncallid.ocl" );
      while (<OCL>) { chomp; $ons="$_";}
      close(OCL);
      if ( -s "$ONCDIR/$form{oncallid}/$form{oncallid}.asn-${ons}" ) { $ck_asn="1";}
    }


  #
  # IF ONCALL SUBTITLE NAME  ENTRY IS MOVED
  #
  if ( $form{sact} eq "movesubt" && $form{num} )
  {
    $MOVEFILE="$ONCDIR/$form{oncallid}/$form{oncallid}.ocl";
    $MOVEREC="$form{num}";
    move_record_down;
  }
  #
  # IF ONCALL ASSIGNEE ENTRY IS MOVED
  #
  if ( $form{sact} eq "moveasn" && $form{num} )
  {
    $MOVEFILE="$ONCDIR/$form{oncallid}/$form{oncallid}.asn-$form{osubt}";
    $MOVEREC="$form{num}";
    move_record_down;
  }
    #
    # WRITE ASSIGNEE
    #
  foreach $buff2 (@pairs)
  {
     if ( $buff2 =~ /oncassn=/)
     {
        chomp($buff2);
	$buff2 =~ s/%3A/\:/;
        ($d1, $f) = split (/=/, $buff2);
	if ( $f ) { ($osubt,$oncassn) = split(/:/, $f); }
     }
  }
    if ( "$osubt" && "$oncassn" )
    {
      open(WASN, ">> $ONCDIR/$form{oncallid}/$form{oncallid}.asn-${osubt}" )|| print "CANNOT WRITE $ONCDIR/$form{oncallid}/$form{oncallid}.asn-${osubt}";
        print WASN "$oncassn\n";
        close(WASN);
    } # End write assignee


    #
    # WRITE SUBTITLE - Primary/Secondary/....
    #
    if ( "$form{oncsubt}" )
    {
      open(WASN, ">> $ONCDIR/$form{oncallid}/$form{oncallid}.ocl" )|| print "CANNOT WRITE $ONCDIR/$form{oncallid}/$form{oncallid}.ocl";
        print WASN "$form{oncsubt}\n";
      close(WASN);
      $ck_ocl="1";
    } # End write subtitle
    if ( -s "$ONCDIR/$form{oncallid}/$form{oncallid}.ocl" )  { $ck_ocl="1";}

  } # end of writes


  #
  # DISPLAY CREATE ONCALL PAGE
  #
  if ( $form{oncallid} )
  {
        $HiddenID="<input type=hidden name=oncallid value=\"$form{oncallid}\">";
        $createkave="Step 2: <a href=$ITKASM?act=ckave&kid=oncall:$form{oncallid} class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create a KAVE</a>";
  }
    @ROTOCC=("Weekly","Daily");
    @ROTDAY=@DAYS;
    @ROTDAYS=@DAYSABR;
  if ( $form{ocactive} == 0 ) { $selectN="checked"; $selectY=""; }
  else { $selectN=""; $selectY="checked"; }

  # TRANSLATE DAY NUMBER TO NAME
  $cntday="0";
  foreach $dofw (@ROTDAY)
  { 
    $cntday++;  
    if ( $form{ocday} == $cntday ) { $OCDAY="$dofw"; }
  } 

  #
  # Check if Generate Button can be displayed
  #
#print "n $ck_name && o $form{occur} $ck_occur && h $ck_hr && m $ck_min && ocl $ck_ocl && asn $ck_asn";
  if ( $ck_name && $ck_hr && $ck_min && $ck_ocl && $ck_asn) 
  {
    if ( $form{sact} eq "delsa" || $form{sact} eq "delst" || $form{sact} eq "moveasn" || $form{sact} eq "dels" || ($form{occur} eq "Daily" && $ck_days ) || $form{occur} eq "Weekly" && $ck_day ) 
    { $form{gencal}="1"; }
  }
      if ( $form{oncallid} && $form{oncname} ) 
      { 
         $goto_oncall=" | <a href=${ITKASMONC}?ID=$form{oncallid} class=\"hoverlink\" title=\"Go To $form{oncname}\" style=\"color:$lnkcolor\">$form{oncname}</a>"; 
         $CRTUPD="Update"; 
         $CRTLINK=" | <a href=$ITKASM?act=concall class=\"hoverlink\" title=\"Create On-Call Mine\" style=\"color:$lnkcolor\">Create On-Call</a>";
       }
       else { $CRTUPD="Create"; $CRTLINK=""; }
  print qq~
      $hr_line
      $genform
      <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
      <font $fsbl> <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
      | <a href=$ITKASM?act=listoc class=\"hoverlink\" title="List available On-Call Mines" style=\"color:$lnkcolor\">List On-Call</a></font><font $fsb>
      | <b>$CRTUPD On-Call</b></font><font $fsbl> $CRTLINK
      $goto_oncall
      </font>
      </td><td align=right width=15% valign=top><font $fsbl>
        $createkave
      </td>
      </table>
  <!--             -->
  <!-- CREATE ON-CALL -->
  <!--             -->
      $hr_line
<table border=0>
<td>
      <p>
      <form method=post action=$ITKASM>
        <input type=hidden name=act value=concall>
        $HiddenID
      <table border=0 cellpadding=3 cellspacing=3>
      <td>
        <table border=0>
          <tr><td valign=top nowrap><font $fsn><b>On-Call Mine Title: </b></font></td>
	  <td><input type=text size=25 name="oncname" value="$form{oncname}"><p></td></tr>
          <tr><td valign=top nowrap><font $fsn><b>On-Call Description: </b></font></td>
	  <td><input type=text size=40 name="oncdesc" value="$form{oncdesc}"><p></td></tr>
	<tr>
	  <td align=right valign=top><font $fsn><b>On-Call ID:</b></font></td>
	  <td valign=top><font $fsn>$form{oncallid}</font><p></td>
        </tr>
	<tr>
	  <td align=right valign=top><font $fsn><b>Active:</b></font></td>
	  <td valign=top>
		<input type="radio" name="ocactive" value="1" $selectY><font $fsn>Yes</font>
		<input type="radio" name="ocactive" value="0" $selectN><font $fsn>No</font>
 	  </td>
  	</tr>
        </table>
       </td>
       <td>&nbsp;&nbsp;&nbsp;<td>
         <table border=0>
         <tr>
	   <td valign=top align=right><font $fsn><b>Rotation Occurance:</b></font></td>
          <td><select name="occur" onchange='this.form.submit()'>
   ~;
   if ( ! $form{occur} ) { $form{occur} = "Weekly"; }
   foreach $arr (@ROTOCC)
   {
     if ( "$arr" eq "$form{occur}" ) { $selected="selected"; }
     else { $selected=""; }
     print "<option value=\"$arr\" $selected>$arr</option>\n"; 
   }
   print qq~
	 </select>
 	 </td>
         </tr>
         <tr>
   ~;
   if ( ! -s "$ONCDIR/$form{oncallid}/$form{oncallid}.ocl" ) { `rm -f "$ONCDIR/$form{oncallid}/$form{oncallid}.cal"`; }
   if ( $form{occur} eq "Weekly" ) 
   { 
     #
     # Weekly has no day selected, make sure cal is deleted. 
     #
     if ( ! $form{ocday} ) { `rm -f "$ONCDIR/$form{oncallid}/$form{oncallid}.cal"`; }
     print qq~
	   <td valign=top align=right><b><font $fsn>Select Day:</b></font></td>
          <td><select name="ocday">
     	  <option value=\"\"></option>
     ~;
     $cntday=0;
     foreach $arr (@ROTDAY)
     {
       $cntday++;
       if ( "$cntday" eq "$form{ocday}" ) { $selected="selected"; }
       else { $selected=""; }
       print "<option value=\"$cntday\" $selected>$arr</option>\n"; 
     }
     print "</select>\n";
   }
   else 
   {
     print qq~
	   <td valign=top align=right><b><font $fsn>Select On-Call Days:</b></font></td>
	   <td valign=top align=left>
     ~;
     $dcnt=0;
     $foundone="";
     foreach $d (@ROTDAYS)
     { 
  	$dcnt++;
        if ( $dcnt == 5 ) { print "<br>";}
        $checked="";
        foreach $chk (@ALLDAYS)
	{ if ( $chk == $dcnt ) { $checked="checked";  $foundone="1";} }
	print "<input type=\"checkbox\" name=\"ocdays\" value=\"$dcnt\" $checked><font $fsn>$d</font>\n";
     }
     print qq~
 	  </td>
     ~;
     #
     # Delete the calendar if nothing is entered.
     #
     if ( ! $foundone ) { `rm -f "$ONCDIR/$form{oncallid}/$form{oncallid}.cal"`;  }
   
   }
     print qq~
           </td></tr>
   	   <tr><td valign=top align=right>
             <b><font $fsn>Time:</b></font></td><td>
             <select name="ochr">
     ~;
   foreach $arr (@TIMEHR)
   {
     if ( "$arr" eq "$form{ochr}" ) { $selected="selected"; }
     else { $selected=""; }
     print "<option value=\"$arr\" $selected>$arr</option>\n"; 
   }
   print qq~
	   </select>
          :
          <select name="ocmin">
   ~;
   foreach $arr (@TIMEMN)
   {
     if ( "$arr" eq "$form{ocmin}" ) { $selected="selected"; }
     else { $selected=""; }
     print "<option value=\"$arr\" $selected>$arr</option>\n"; 
   }
   print qq~
	   </select>
   	   </td>
         </tr>
         </table>
       </td><td valign=bottom> <input type=submit name=save value="Update"> </td>
       </table>
      <br>

      <table border=0 cellpadding=5 cellspacing=0> 
      <td valign=top><font $fsn><b>On-Call Name: </b></font>
	<input type=text size=25 name="oncsubt" list="oncsubt" placeholder="Ex: Primary, Backup, ..." pattern="[^' ']+" title="ALPHA-NUMERIC ONLY, NO SPACES ALLOWED">
        <br><hr size=1>
  ~;
# no spaces - pattern="[^' ']+" 
# alpha numeric / no spaces - 
# all alpha numeric pattern="A-z0-9À-ž" 

  # GET THE AUTOFILL LIST
  if ( -s "$ETC/oncall.aft" ) 
  {
    print "<datalist id=\"oncsubt\">\n";
    open(AFT, "$ETC/oncall.aft" )|| print "CANNOT FIND $ETC/oncall.aft";
    while(<AFT>)
    {
	chomp;
	print "<option value=\"$_\">\n";
    }
    close(AFT);
    print "</datalist>";
  }

  #
  # LIST On-Call Subtitle Names'S
  #
  if ( -s "$ONCDIR/$form{oncallid}/$form{oncallid}.ocl" )
  {
    print "<table width=100% border=0>\n";
    $subtcnt=0;
    open(NAM, "$ONCDIR/$form{oncallid}/$form{oncallid}.ocl" )|| print "CANNOT FIND  $ONCDIR/$form{oncallid}/$form{oncallid}.ocl";
    while(<NAM>)
    {
      chomp;
      $subtcnt++;
      print qq~
        <tr><td valign=top><font $fsn>
        <a href="$ITKASM?act=concall&oncallid=$form{oncallid}&sact=movesubt&num=$subtcnt&from=1" height=15 class=\"hoverlink\" style=\"color:$lnkcolor\">$_</font></td>
        <td>
          <a href="$ITKASM?act=concall&oncallid=$form{oncallid}&sact=delst&num=$subtcnt&from=1" height=15>
          <img src=$IMAGES/trashcan.png height=15 border=0>
        </td></tr>
      ~;
    }
    close(NAM);
    print "</table>\n";
  }


  ### ARE ON-CALL Subtitles DEFINED
  if ( -s "$ONCDIR/$form{oncallid}/$form{oncallid}.ocl" )
  {
    # Collect all the On-Call Subtitle Names
    @OSUBT=();
    open(ONC, "$ONCDIR/$form{oncallid}/$form{oncallid}.ocl");
    while (<ONC>) { chomp; push @OSUBT, "$_"; }
    close(ONC);

    foreach $osubt (@OSUBT)
    {
      print qq~
      <td valign=top>
        <table border=0 cellpadding=5 cellspacing=0> 
        <td valign=top align=left>
	  <font $fsn><b>List $osubt:</b></font>
          <select name="oncassn" onchange='this.form.submit()'>
          <option value=\"\" selected></option>
      ~;
      open(USR, "sort -k 3 $USERS |") || print "Cannot find $USERS";
      while (<USR>)
      {
          chomp;
          ($UUID, $UPWD, $ufname, $ulname) = split (/\t/, $_);
          if ( ! /Administrator/i )
          { print "<option value=\"${osubt}:${UUID}\" >${ufname} ${ulname}</option>\n"; }
      }
      close(USR);
      print "</select><hr size=1>";
      print "</td></table>";

  # LIST ASSIGNEE'S
  if ( -f "$ONCDIR/$form{oncallid}/$form{oncallid}.asn-${osubt}" )
  {
    print "<table width=100% border=0>\n";
    $asncnt=0;
    open(ASN, "$ONCDIR/$form{oncallid}/$form{oncallid}.asn-${osubt}" )|| print "CANNOT FIND  $ONCDIR/$form{oncallid}/$form{oncallid}.asn-${osubt}";
    while(<ASN>)
    {
        chomp;
        $assign="$_";
        open(USR, "$USERS" )|| print "CANNOT FIND  $USERS";
        while(<USR>)
        {
   	  chomp;
          if ( /^$assign/ )
          {
            ($UU, $PWD, $FN, $LN) = split (/\t/, $_);
            $asncnt++;
            print qq~
                <tr><td valign=top><font $fsn>
                <a href="$ITKASM?act=concall&oncallid=$form{oncallid}&sact=moveasn&osubt=${osubt}&num=$asncnt&from=1" class=\"hoverlink\" height=15 style=\"color:$lnkcolor\">$FN $LN</font></td>
                <td>
                <a href="$ITKASM?act=concall&oncallid=$form{oncallid}&sact=dela&osubt=${osubt}&num=$asncnt&from=1" class=\"hoverlink\" height=15>
                <img src=$IMAGES/trashcan.png height=15 border=0>
                </td></tr>
            ~;
          }
        }
        close(USR);
    }
    close(ASN);
    print "</table>";
    } # for
  }
  }
  if ( $form{sact} || $form{ocdays} || $form{ocday} ) { $updatecal="<input type=submit name=save value=\"Update Calendar\">";}
  print qq~
        </table>
        <p> $hr_line
        <input type=submit name=save value="Save">
        $updatecal 
      </form>
  ~;

  #
  # GENERATE CALENDAR 
  #
  if ( $form{gencal} ) { generate_cal; }

  #
  # IF A CALENDAR IS GENERATED DISPLAY IT
  #
  if ( -s "$ONCDIR/$form{oncallid}/$form{oncallid}.cal" ) 
  {
   print qq~
     <table border=0 cellpadding=3>
     <tr>
        <td valign=top align=center><font $fsb><b>Month<br><hr size=1></b></font></td>
        <td valign=top align=center><font $fsb><b>Date<br><hr size=1></b></font></td>
        <td valign=top align=center><font $fsb><b>Year<br><hr size=1></b></font></td>
        <td valign=top align=center><font $fsb><b>Day of Week<br><hr size=1></b></font></td>
        <td  valign=top align=center><font $fsb><b>$PLIST<br><hr size=1></b></font></td>
     </tr>
  ~;

    $cnt=0;
    open(CAL, "$ONCDIR/$form{oncallid}/$form{oncallid}.cal" ) || print "CANNOT OPEN $ONCDIR/$form{oncallid}/$form{oncallid}.cal";
    while(<CAL>)
    {
      chomp;
      ($d_date, $d_dowk, $d_people) = split(/\t/, $_);
      ($d_year, $d_month, $d_day) = split(/\-/, $d_date);
      $date = Calendar::Any->new_from_Gregorian($d_month, $d_day, $d_year);
      $calmo = $date->date_string("%M"); 
  
      # BOLD THE DAY OF THE ROTATION
      if ( "$d_dowk" eq "$OCDAY" ) 
      { 
	$cnt++;
	if ( $cnt > 1 ) { print "<tr><td colspan=5>$hr_line</td></tr>\n";}
      }
      # DISPLAY WHO IS ONCALL WHEN
      print qq~
        <tr>
          <td valign=top align=right><font $fsn>$calmo</font></td>
          <td valign=top align=center><font $fsn>${d_day}</font></td>
          <td valign=top><font fsn>$d_year</font></td>
          <td valign=top><font fsn>$d_dowk</font></td>
          <td valign=top><font fsn>$d_people</td>
      ~;
    }
    close(CAL);
    print qq~
      </table>
      <td valign=top>
    ~;

    # SHOW KAVES DEFINED FOR MINE
    $mineid="$form{oncallid}"; $minename="$form{ocname}";
    $MINEDIR="$ONCDIR/$form{oncallid}"; $minetype="oncall";
    list_kaves_def;
    if ( $form{oncallid} ) 
    {
      @MINEARGS=("act=concall", "ID=$form{oncallid}", "from=1");
      &mine_access;
    }

    print qq~
      </td>
      </table>
    ~;
  }

}




###
### LIST ALL ON-CALLS CREATED
###
sub list_oncall
{
    if ( ! -f "$ONCALL" ) { `touch $ONCALL`; }
    if ( $form{tid} ) 
    { $createkave="Step 2: <a href=\"$ITKASM?act=ckave&kid=oncall:$form{tid}\" class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create A Kave</a>"; }
    print qq~
        $hr_line
        <table width=100% border=0 bgcolor=$hdrcolor cellpadding=3>
	<td align=left>
          <font $fsbl>
          <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
	  </font><font $fsb>
           | <b>List On-Calls</b> | 
	  </font><font $fsbl>
          <a href=$ITKASM?act=concall class=\"hoverlink\" title="Create an On-Call" style=\"color:$lnkcolor\">Create On-Call</a> 
	  </font>
	</td><td align=right valign=top>
          <font $fsbl>
  	  $createkave
	  </font>
	</td>
	</table>
        $hr_line
    ~;
    if ( ! -s "$ONCALL" ) { print "<font $fsberr><b>No On-Call Mines Defined</b></font>"; exit;}
    print qq~
        <!--               -->
        <!-- LIST ON-CALLS -->
        <!--               -->
        <font $fsn>Click to View On-Call Profile or Edit:</font><p>
        <table border=0 width=100%>
        <tr valign=top>
        <td align=center nowrap><b><font $fsb>On-Calls</font><br><hr size=1 ></b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td align=center width=60% ><b><font $fsb>Profile<br><hr size=1 ></font></b></td>
	<td align=center width=60% ><b><font $fsb>Access<br><hr size=1 ></font></b></td>
        </tr><td valign=top>
        <table border=0 cellpadding=3 cellspacing=3>
    ~;
    #
    # Read the on-call dat file and get the titles and id's.
    #
    $foundrec="";

    open(ONC, "$ONCALL" ) || print "CANNOT OPEN ONCALL $ONCALL";
    while (<ONC>)
    {
      chomp;
      $foundrec="1";
      ($ttitle, $tid)=split(/\t/, $_);
      #
      # Get all the profile info
      #
      @ONCPRO=();
      open(OPROF, "$ONCDIR/$tid/$tid.pro") || print "CANNOT OPEN $ONCDIR/$tid/$tid.pro";
      while(<OPROF>) { chomp; push @ONCPRO, "$_"; }
      close(OPROF);
      foreach (@ONCPRO)
      { 
	if ( /^desc\t/ ) { ($d1, $tdesc)=split(/\t/, $_); } 
	if ( /^active\t/ ) 
        { 
	  ($d1, $tactive)=split(/\t/, $_);
	  if ( $tactive == 1 ) { $ball="<img src=$IMAGES/ball-green.png height=10 title=\"Active\">"; }
	  else { $ball="<img src=$IMAGES/ball-red.gif height=11 title=\"Disabled\">"; }
        } 
      }
      #
      # Diplay the title and description
      #
      if ( $tid eq $form{tid} ) { $tline="<b>$ttitle</b>"; $clTITLE="$ttitle"; @vONCPRO=@ONCPRO; }
      else { $tline="<a href=$ITKASM?act=listoc&view=$tid class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"View \'$ttitle\' On-Call Profile\">$ttitle</a>"; }
      print qq~
          <tr><td nowrap valign=top><font $fsn>
              <a href=$ITKASM?act=concall&ID=$tid&from=1 class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"Edit \'$ttitle\' On-Call Profile\"><img src=$IMAGES/edit.png height=12 border=0></a>
&nbsp;
              <a href=$ITKASMONC?ID=$tid title=\"Go to \'$ttitle\' On-Call page\"><img src=$IMAGES/redirect.png height=12 border=0></a>
&nbsp;
              $ball &nbsp; $tline
          </font></td><td nowrap><font $fsn>$tdesc</font></td></tr>
      ~;
    }
    close(ONC);
    if ( ! "$foundrec" ) { print "<font $fsn><b>Nothing Defined...</b></font>"; }
    print "</table></td>\n";
    #
    # If a Profile is selected for viewing
    #
    if ( ! $form{view}  )
    {
        print "";
    }
    else
    {
      print "<td >&nbsp;</td>";
      $fcnt=0;
      $kavecnt=0;
      print qq~
        <td valign=top>
        <table border=0 cellpadding=3 cellspacing=3>
      ~;
      open(OPROF, "$ONCDIR/$form{view}/$form{view}.pro") || print "CANNOT OPEN $ONCDIR/$form{view}/$form{view}.pro";
      while(<OPROF>) 
      {
        ($tfield,$tval) = split(/\t/, $_);
        if ( /^name\t/ ) {  $tfield="Title"; $tval= "<b>$tval</b>"; }
        if ( /^id\t/ ) { $tfield="ID:"; }
        if ( /^desc\t/ ) { $tfield="Description:"; }
        if ( /^occur\t/ ) { $tfield="Rotation Occurance:"; }
        if ( /^ocday\t/ || /^ocdays/ ) 
	{ 
	   $tfield="Rotation Day:";  $cntday=0;
           foreach $dofw (@DAYS)
           { 
    	     $cntday++;  
    	     if ( $tval == $cntday ) { $tval="$dofw"; }
           } 
 	}
  
        if ( /^ochr\t/ ) { $tfield="Hour:"; $desc="$tval"; }
        if ( /^ocmin\t/ ) { $tfield="Minute:"; $desc="$tval"; }
        if ( /^active\t/ ) 
	{ 
	  $tfield="Active:"; 
	  if ( $tval == 1 ) { $tval="Yes"; }
	  else { $tval="<b>No</b>"; }
   	}

        print qq~
          <tr><td align=right nowrap><font $fsn>$tfield</font></td><td><font $fsn>$tval</font></td></tr>
        ~;
      }
      close(OPROF);
      #
      # DISPLAY THE OCL FILE AND ASSIGNEES
      #
      open(OCL, "$ONCDIR/$tid/$tid.ocl") || print "CANNOT OPEN $ONCDIR/$tid/$tid.ocl";
      while(<OCL>) 
      { 
	chomp; 
        $ocl="$_";
        print "<tr><td align=right valign=top><font $fsn>${ocl}:</font></td><td><font $fsn>";
        open(ASN, "$ONCDIR/$tid/$tid.asn-$ocl") || print "CANNOT OPEN $ONCDIR/$tid/$tid.ocl";
        while(<ASN>) 
        { 
	  chomp; 
          $userID="$_"; &convert_user;
          if ( $ulname || $ufname ) { print "$ufname $ulname<br>\n" }
	}
	close(ASN);
	print "</font></td></tr>\n";
      }
      close(OCL);
      print "</table></td>";
     print "<td valign=top>";
     if ( $form{view} ) 
     {
 	$MINEDIR="$ONCDIR/$form{view}";
 	&display_mineaccess;
     }
     print "</td>"; 
    }
    print "</table>";
}


###
### CLONE A TRACKER MINE
###
sub clone_tracker
{
  if ( ! $form{cw} ) 
  { 
    print qq~
        <form method=post action=$ITKASM>
        <input type=hidden name=act value=clonetrk>
        $hr_line
	<table width=100% bgcolor=$hdrcolor cellpadding=3><td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> |
        <a href=$ITKASM?act=listtrk class=\"hoverlink\" title="List available Tracker Mines" style=\"color:$lnkcolor\">List Tracker</a> | 
        <a href=$ITKASM?act=ctracker class=\"hoverlink\" title="Create a Tracker Mine" style=\"color:$lnkcolor\">Create Tracker</a> | 
	</font><font $fsb>
        <b> Clone Tracker</b>
	</font>
	</td></table>
        $hr_line
   	<!--               -->
   	<!-- CLONE TRACKER -->
   	<!--               -->
	<font $fsn>Click to View Tracker Profile, Select to clone:<p></font>
	<table border=1>
	<tr valign=top>
	<td align=center><b>Tracker</b></td><td align=center><b>Profile</b></td><td align=center><b>Clone Name</b></td>
	</tr><td valign=top>
	<table cellpadding=3 cellspacing=3>
    ~;
    #
    # Read the tracker dat file and get the titles and id's.
    #
    $foundrec="";
    if ( ! -s "$TRACKER" ) { `touch $TRACKER`; }
    open(TRK, "$TRACKER" ) || print "CANNOT OPEN TRACKER $ITKASMTRCK";
    while (<TRK>)
    {
      chomp;
      ($ttitle, $tid)=split(/\t/, $_);
      #
      # Get all the profile info
      #
      @TRKPRO="";
      open(TPROF, "$TRKDIR/$tid/$tid.pro") || print "CANNOT OPEN $TRKDIR/$tid/$tid.pro";
      while(<TPROF>) { chomp; push @TRKPRO, "$_"; } 
      close(TPROF);
      shift @TRKPRO;
      $foundrec="1";
      foreach (@TRKPRO) 
      { if ( /desc/ ) { ($d1, $tdesc)=split(/\t/, $_); } }
      #
      # Diplay the title and description
      #
      if ( $tid eq $form{tid} ) { $tline="<b>$ttitle</b>"; $clTITLE="$ttitle"; $chck="checked"; @vTRKPRO=@TRKPRO; }
      else { $tline="<a href=$ITKASM?act=clonetrk&view=1&tid=$tid class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"View \'$ttitle\' Tracker Profile\">$ttitle</a>"; $chck=""; }
      print qq~
	  <tr><td nowrap valign=top>
          	<input type="radio" name="cw" value="$tid" $chck>
		<font $fsn>$tline</font>
	  </td><td><font $fsn>$tdesc</font></td></tr>
      ~;
    }
    close(TRK);
    if ( ! "$foundrec" ) { print "<font $fsn><i><b>Nothing Defined.<br>Create Tracker First...</b></i></font>"; }
    print "</td></table>";
    #
    # If a Profile is selected for viewing
    #
    if ( $form{view}  ) 
    { 
      $fcnt=0;
      print qq~
 	<td valign=top>
  	<table border=0 cellpadding=3 cellspacing=3>
      ~; 
      foreach (@vTRKPRO)
      { 
        ($tfield,$tval, $f1,$f2,$f3,$f4,$f5) = split(/\t/, $_);
        if ( /^name\t/ ) { $tval= "<b>$tval</b>"; $tfield="Title"; }
        if ( /^id\t/ ) { $tfield="ID:"; }
        if ( /^desc\t/ ) { $tfield="Description:"; $desc="$tval"; }
        if ( /^recname\t/ ) { $tfield="Record Name:"; $recname="$tval"; }
        if ( /^recnum\t/ ) { $tfield="Record Num:"; $recnum="$tval"; }
        if ( /^field\t/ ) { $tfield="Field:"; $tval="$tval / $f1, $f2, $f3, $f4, $f5"; $fcnt++; }
        if ( /^dsplst\t/ ) { $tfield="Display:"; $dsplst="$tval";
	  if ( $tval eq "n" ) { $tval="Normal"; }
	  else { $tval="Reverse"; }
   	}
        if ( /^rechide\t/ ) { $tfield="Hide Record:"; $rechide="$tval";
	  if ( $tval eq "n" ) { $tval="No"; }
	  else { $tval="Yes"; }
  	}
        if ( /^wopsact\t/ ) { $tfield="Update Ops Activity:"; $wopsact="$tval";
	  if ( $tval eq "n" ) { $tval="No"; }
	  else { $tval="Yes"; }
	}
 	
        if ( $fcnt == 1 && -s "$TRKDIR/$form{tid}/$form{tid}.cmt" ) 
        {
 	  print "<tr><td valign=top align=right><font $fsn>Comment:</font></td><td valign=top><font $fsn>";
          open(CMT, "$TRKDIR/$form{tid}/$form{tid}.cmt") || print "CANNOT OPEN: $TRKDIR/$form{tid}/$form{tid}.cmt";
          while(<CMT>) 
          { 
	  print "$_<br>";
	  } 
          close(CMT);
	  print "</font></td></tr>";
        }

        print qq~
 	  <tr><td valign=top align=right nowrap><font $fsn>$tfield</font></td><td valign=top><font $fsn>$tval</font></td></tr>
        ~;
      }
      print "</table></td>";
    }
    else { print "<td valign=top width=250 align=center><i><font $fsn>No Profile Selected</font></i></td>"; }
    if ( "$foundrec" ) 
    { 
      print qq~
 	<td valign=top align=center>
	    &nbsp;<br>
	    &nbsp;<input type=text size=30 name="trckname">&nbsp; <p> 
	    <Input TYPE="submit" VALUE="Clone $clTITLE">
       </td>
      ~;
    }
    print "</table>";
  }
  else 
  {
    $valid="";
    while ( ! $valid  )
    {
      my $random_string=&get_token(6);
      &get_token;
      $number="$random_string";
      if ( ! -d "$TRKDIR/${number}" ) { $valid="1"; }
    }
    $TrackerID="$number";
    if ( ! -d "$TRKDIR/$TrackerID" ) { `mkdir -p "$TRKDIR/$TrackerID"`; }
    open(CLONE, "> $TRKDIR/$TrackerID/${TrackerID}.pro") || print "CANNOT WRITE: $TRKDIR/$TrackerID/${TrackerID}.pro\n";
    open(TPROF, "$TRKDIR/$form{cw}/$form{cw}.pro") || print "CANNOT OPEN $TRKDIR/$form{cw}/$form{cw}.pro";
    while(<TPROF>) 
    { 
        $BOO="";
        if ( /^id\t/ ) { print CLONE "id\t${TrackerID}\n"; $BOO="1"; }
        if ( /^name\t/ ) { print CLONE "name\t$form{trckname}\n";  $BOO="1"; }
        if ( ! "$BOO" ) { print CLONE "$_"; }
        if ( /^recnum\t/ ) { ($d1,$recnum)=split(/\t/, $_); chomp($recnum); }
    } 
    close(TPROF);
    close(CLONE);
    #
    # Write out Tracker starting number    
    open(TRKN, "> $TRKDIR/$TrackerID/${TrackerID}.num" ) || print "CANNOT write: $TRKDIR/$TrackerID/${TrackerID}.num";
    print TRKN "$recnum";
    close(TRKN);
    `cp $TRKDIR/$form{cw}/$form{cw}.cmt $TRKDIR/$TrackerID/${TrackerID}.cmt`;
    #
    # Write to tracker index file
    #
    open(TRKR, ">> $TRACKER" ) || print "CANNOT WRITE $TRACKER";
    print TRKR "$form{trckname}\t$TrackerID\n";
    close(TRKR);
      # Sort file
      tie @LST, 'Tie::File', "$TRACKER" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    print qq~
        $hr_line
        <font $fsb><p>Clone Completed... </font>
	<META HTTP-EQUIV="Refresh" CONTENT="2;URL=$ITKASM?act=modtrk&ID=$TrackerID">
    ~;
    $META="1";
  }
}


###
### LIST ALL TRACKERS CREATED
###
sub list_trackers
{
    if ( $form{tid} ) 
    { $createkave="Step 2: <a href=\"$ITKASM?act=ckave&kid=tracker:$form{tid}\" class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create A Kave</a>"; }
    print qq~
        $hr_line
        <table width=100% bgcolor=$hdrcolor cellpadding=3>
	<td align=left>
          <font $fsbl>
          <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
	  </font><font $fsb>
           | <b>List Tracker</b> | 
	  </font><font $fsbl>
          <a href=$ITKASM?act=ctracker class=\"hoverlink\" title="Create a Tracker Mine" style=\"color:$lnkcolor\">Create Tracker</a> |
          <a href=$ITKASM?act=clonetrk class=\"hoverlink\" title="Clone a Tracker Mine" style=\"color:$lnkcolor\">Clone Tracker</a> 
	  </font>
	</td><td align=right valign=top>
          <font $fsbl>
  	  $createkave
	  </font>
	</td>
	</table>
        $hr_line
        <!--              -->
        <!-- LIST TRACKER -->
        <!--              -->
        <font $fsn>Click to View Tracker Profile or Edit:</font><p>
        <table border=0 width=100%>
        <tr valign=top>
        <td align=center><b><font $fsb>Trackers</font><br><hr size=1 ></b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td align=center width=60% ><b><font $fsb>Profile<br><hr size=1 ></font></b></td>
	<td align=center width=60% ><b><font $fsb>Access<br><hr size=1 ></font></b></td>
        </tr><td valign=top>
        <table border=0 cellpadding=3 cellspacing=3>
    ~;
    #
    # Read the tracker dat file and get the titles and id's.
    #
    $foundrec="";
    if ( ! -f "$TRACKER" ) { `touch $TRACKER`; }
      tie @LST, 'Tie::File', "$TRACKER" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    open(TRK, "$TRACKER" ) || print "CANNOT OPEN TRACKER $TRACKER";
    while (<TRK>)
    {
      chomp;
      $foundrec="1";
      ($ttitle, $tid)=split(/\t/, $_);
      #
      # Get all the profile info
      #
      @TRKPRO="";
      open(TPROF, "$TRKDIR/$tid/$tid.pro") || print "CANNOT OPEN $TRKDIR/$tid/$tid.pro";
      while(<TPROF>) { chomp; push @TRKPRO, "$_"; }
      close(TPROF);
      shift @TRKPRO;
      foreach (@TRKPRO)
      { if ( /desc/ ) { ($d1, $tdesc)=split(/\t/, $_); } }
      #
      # Diplay the title and description
      #
      if ( $tid eq $form{tid} ) { $tline="<b>$ttitle</b>"; $clTITLE="$ttitle"; @vTRKPRO=@TRKPRO; $tdesc="<b>$tdesc</b>";}
      else { $tline="<a href=$ITKASM?act=listtrk&view=1&tid=$tid class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"View \'$ttitle\' Tracker Profile\">$ttitle</a>"; }
      print qq~
          <tr><td nowrap valign=top><font $fsn>
                <a href=$ITKASM?act=modtrk&ID=$tid><img src=$IMAGES/edit.png height=12 border=0></a> 
&nbsp;
                <a href=$ITKASMTRCK?ID=$tid><img src=$IMAGES/redirect.png height=12 border=0></a> 
&nbsp;
		$tline
          </font></td><td nowrap><font $fsn>$tdesc</font></td></tr>
      ~;
    }
    close(TRK);
    if ( ! "$foundrec" ) { print "<font $fsn><b>Nothing Defined...</b></font>"; }
    print "</table></td>\n";
    #
    # If a Profile is selected for viewing
    #
    if ( ! $form{view}  )
    {
	#print "<td >&nbsp;</td>";
	print "";
    }
    else
    {
	print "<td >&nbsp;</td>";
      $fcnt=0;
      $kavecnt=0;
      print qq~
        <td valign=top>
 	<table border=0 width=100%>
        <td>
        <table border=0 cellpadding=3 cellspacing=3>
      ~;
      foreach (@vTRKPRO)
      {
        ($tfield,$tval, $f1,$f2,$f3,$f4,$f5) = split(/\t/, $_);
        if ( /^name\t/ ) { $tval= "$tval"; $tfield="Title"; }
        if ( /^id\t/ ) { $tfield="ID:"; }
        if ( /^desc\t/ ) { $tfield="Description:"; $desc="$tval"; }
        if ( /^recname\t/ ) { $tfield="Record Name:"; $recname="$tval"; }
        if ( /^recnum\t/ ) { $tfield="Record Num:"; $recnum="$tval"; }
        if ( /^field\t/ ) { $tfield="Field:"; $tval="$tval / $f1, $f2, $f3, $f4, $f5"; $fcnt++; }
        if ( /^dsplst\t/ ) { $tfield="Display:"; $dsplst="$tval";
          if ( $tval eq "n" ) { $tval="Normal"; }
          else { $tval="Reverse"; }
        }
        if ( /^rechide\t/ ) { $tfield="Hide Record:"; $rechide="$tval";
          if ( $tval eq "n" ) { $tval="No"; }
          else { $tval="Yes"; }
        }
        if ( /^wopsact\t/ ) { $tfield="Update Ops Activity:"; $wopsact="$tval";
          if ( $tval eq "n" ) { $tval="No"; }
          else { $tval="Yes"; }
        }

        if ( $fcnt == 1 && -s "$TRKDIR/$form{tid}/$form{tid}.cmt" )
        {
          print "<tr><td valign=top align=right><font $fsn>Comment:</font></td><td valing=top><font $fsn>\n";
          open(CMT, "$TRKDIR/$form{tid}/$form{tid}.cmt") || print "CANNOT OPEN: $TRKDIR/$form{tid}/$form{tid}.cmt";
          while(<CMT>)
          {
	  print "$_";
          }
          close(CMT);
	  print "</font><br></td>";
        }

        print qq~
          <tr><td align=right nowrap><font $fsn>$tfield</font></td><td><font $fsn>$tval</font></td></tr>
        ~;
      }
          print qq~
  	  <tr><td valign=top align=right><font $fsn>Kave Code:</font></td>
	  <!-- <td><font $fsn><a href=$ITKASM?act=kave&type=tracker&tid=$form{tid} class=\"hoverlink\" style=\"color:$lnkcolor\">%%%tracker.$form{tid}</a></font></td></tr> -->
	  <td><font $fsn>%%%tracker.$form{tid}</a></font></td></tr>
          ~;
      print "</table></td></table></td>";
      print "<td valign=top> "; 
      if ( $form{tid} ) 
      {
        $MINEDIR="$TRKDIR/$form{tid}";
        &display_mineaccess; 
      }
      print "</td></tr>";
    }
    print "</table>";
}


###
### CREATE FREEFORM START
###
sub create_freeform
{
#print "buffer = $buffer<p> $form{FreeID}";
  # Check if coming from list to be editted
  # If so load the name and content
  if ( $form{sact} )
  {
    $rawform{fbox}="";
    $form{freename}="";
    open(FRE, "$FREDIR/$form{FreeID}/$form{FreeID}.pro" ) || print "CANNOT read: $FREDIR/$form{FreeID}/$form{FreeID}.pro";
    while(<FRE>)
    {chomp;  
	chomp;
	if ( /^name\t/) { ($d, $form{freename})=split(/\t/, $_); }
    }
    close(FRE);
    open(FRE, "$FREDIR/$form{FreeID}/$form{FreeID}.dat" ) || print "CANNOT read: $FREDIR/$form{FreeID}/$form{FreeID}.dat";
    while(<FRE>){ chomp; $rawform{fbox}="$rawform{fbox}$_";}
    close(FRE);
   }   
  $FreeID="";
  if ( ! "$form{FreeID}" && "$form{freename}" )
  {
    $valid="";
    while ( ! $valid  )
    {
      my $random_string=&get_token(6);
      &get_token;
      $number="$random_string";
      if ( ! -d "$FREDIR/${number}" ) { $valid="1"; }
    }
      $FreeID = "$number";
      if ( ! -d "$FREDIR/$FreeID" ) 
      { `mkdir -p "$FREDIR/$FreeID"`; }

      #
      # Write to Freeform index file
      #
      open(FRE, ">> $FREE" ) || print "CANNOT WRITE $FREE";
      print FRE "$form{freename}\t$FreeID\n";
      close(FRE);
      $form{FreeID} = "$FreeID";

      # Sort file
      tie @LST, 'Tie::File', "$FREE" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
  }
  if ( $form{freename} ) 
  {
    $FreeID="$form{FreeID}";
    # $ID=form{Task/Track/FreeID} / $NEWNAME=$form{name} $FILE=/etc/file
    # check if name changed and update index
    #
    $curName="";
    open(FRED, "$FREE" ) || print "CANNOT read: $FREE";
    while (<FRED>) 
    { 
	chomp; 
	if ( /\t$form{FreeID}/ ) { ($idxName,$d)=split(/\t/, $_); } 
    }
    close(FRED);
    if ( "$idxName" ne "$form{freename}" ) 
    { 
      $ID="$FreeID"; $FILE="$FREE"; 
      $NEWNAME="$form{freename}"; index_namechg; 
      # Sort file
      tie @LST, 'Tie::File', "$FREE" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    }
    #
    # Create data structure.
    #
    open(FRE, "> $FREDIR/$form{FreeID}/$form{FreeID}.pro" ) || print "CANNOT write: $FREDIR/$form{FreeID}/$form{FreeID}.pro";
    print FRE "id\t$FreeID\n";
    print FRE "name\t$form{freename}\n";
    close(FRE);

    open(FRE, "> $FREDIR/$form{FreeID}/$form{FreeID}.dat" ) || print "CANNOT write: $FREDIR/$form{FreeID}/$form{FreeID}.dat";
    #$rawform{fbox} =~ s/\r/\n/g;
    print FRE "$rawform{fbox}";
    close(FRE);
  }

  #
  # DISPLAY CREATE FREEFORM PAGE
  #
  if ( $form{FreeID} ) 
  { 
	$HiddenID="<input type=hidden name=FreeID value=\"$form{FreeID}\">";
	$createkave="Step 2: <a href=$ITKASM?act=ckave&kid=freeform:$form{FreeID} class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create a KAVE</a>";
        $CRTUPD="Update"; $CRTLINK=" | <a href=$ITKASM?act=cfree class=\"hoverlink\" title=\"Create Freeform Mine\" style=\"color:$lnkcolor\">Create Freeform</a>";
  }
  else { $CRTUPD="Create"; $CRTLINK=""; }
  print qq~
      $hr_line
      <table width=100% bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
      <font $fsbl>
      <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> |
      <a href=$ITKASM?act=listfree class=\"hoverlink\" title="List available Freeform Mines" style=\"color:$lnkcolor\">List Freeforms</a> 
      </font><font $fsb>
      | <b>$CRTUPD Freeform</b>
      $CRTLINK
      </font>
      </td><td align=right valign=top width=15%><font $fsbl>
      $createkave
      </font>
      </td>
      </table>
      $hr_line
    <table border=0>
    <td valign=top>
      <form method=post action=$ITKASM>
        <input type=hidden name=act value=cfree>
	$HiddenID
      <table border=0>
       <tr>
        <td valign=top halign=left ><font $fsn>
         Freeform provides the ability to place information, data, images, 
         anything you want to put in a a Kave. <br> Embedded commands are avaialble. 
	 Make sure it fits in the Kave that your create.<p>
        <table><td valign=top nowrap>
        <b>Freeform Title: </b> 
        <input type=text size=20 name="freename" value="$form{freename}">
        </td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td nowrap> <b>Freeform ID:</b> $form{FreeID} </td></table>
        <p>
        <b>Freeform Box: </b><br>
        <textarea rows=15 cols=80 name="fbox" wrap="off">$rawform{fbox}</textarea><br>
	</font>
      </td>
      </tr><tr>
      <td valign=top>
~;
        open(TMP, "$ETC/kave-templates.dat") || print "ERROR: Cannot find $ETC/kave-templates.dat";
       	while (<TMP>)
	{
	  chomp;
  	  if ( /:Default,/ ) 
	  { 
		$kconfig="$_"; 
        	($d1,$khtx,$kfbg,$kbrd,$kwdt,$kbkg1,$kbkg2,$kbdybrd,$khrclr,$ktxt,$klnk)=split(/,/, $_);
	  }
  	}
	close(TMP);
        if ( ! $form{TW} ) { $form{TW} = 300; }
        print qq~
     	  &nbsp;<br>
          <font $fsn>Sample Kave Template below: 
	  Width = <input type=text name=TW value=$form{TW} size=5>
          </font> 
 	  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
    	 <input type=submit name=ksave value="Save"><p>
	</center>
	~;
        $kwdt=$form{TW};
     	@FFORM=();
#print "dat=$FREDIR/$form{FreeID}/$form{FreeID}.dat";
        if ( ! -s "$FREDIR/$form{FreeID}/$form{FreeID}.dat" ) 
	{ 
	   $FFLINE="&nbsp;<p><i><center><font $fsn>This will populate <br>with your entry</font></center></i><p>&nbsp;<p>&nbsp;<p>&nbsp;<p>"; 
	   push(@FFORM, $FFLINE);
	}
	else
	{
	  $FreeFormFile="$FREDIR/$form{FreeID}/$form{FreeID}.dat";
	  &freeform_process;
   	}
 	$kconfig="%%%open.none:$kavename,$khtx,$kfbg,$kbrd,$kwdt,$kbkg1,$kbkg2,$kbdybrd,$khrclr,$ktxt,$klnk";
        &open_kave; 
        print qq~
	<tr><td bgcolor=$gbgx2>
 	~;	
	foreach (@FFORM) { print "$_"; }
	print qq~
	</td></tr>
	~;
	&close_kave;
    print qq~
      </td>
      <br>
         </form>
      </table>
      </td>
      <td valign=top>
    ~;
    # SHOW KAVES DEFINED FOR MINE
    $mineid="$form{FreeID}"; $minename="$form{freename}"; 
    $MINEDIR="$FREDIR/$form{FreeID}"; $minetype="freeform";
    list_kaves_def;
    if ( $form{FreeID} ) 
    {
      @MINEARGS=("act=cfree","FreeID=$form{FreeID}","sact=1");
      &mine_access;
    }
  
   print qq~
   </td></table>
  ~;

}


###
### LIST ALL RESOURCES CREATED
###
sub list_resource
{
    if ( $form{tid} )
    { $createkave="Step 2: <a href=\"$ITKASM?act=ckave&kid=resource:$form{tid}\" class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create A Kave</a>"; }
    print qq~
        $hr_line
	<table width=100% bgcolor=$hdrcolor cellpadding=3><td align=left>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
	</font><font $fsb>
	 | <b>List Resources</b> | 
	</font><font $fsbl>
        <a href=$ITKASM?act=crlist class=\"hoverlink\" title="Create a Resource Mine" style=\"color:$lnkcolor\">Create Resource</a>
	</font></td><td valign=top align=right><font $fsbl>
	$createkave
	</font></td></table>
        $hr_line
        <font $fsn>Click to View or Edit a Resource Mine List:</font><p>
        <table border=0 width=100%>
        <td valign=top>
        <table cellpadding=3 cellspacing=3 border=0 >
        <tr><td align=center><b><font $fsb>Resource Mines</font><br><hr size=1 ></b></td></tr>
    ~;
    #
    # Read the task.dat file and get the titles and id's.
    #
    if ( ! -f "$RESRC" ) { `touch $RESRC`; } 
    $foundrec=""; $showall="";
    open(RSV, "$RESRC" ) || print "CANNOT OPEN RESOURCE LIST: $RESRC";
    while (<RSV>)
    {
      chomp; $foundrec="1";
      ($ttitle, $tid)=split(/\t/, $_);
      if ( $GOD ) { $showall="1"; }
      elsif ( ! $GOD && ! index($ttitle, "SETTINGS\.")) {$showall="";}
      else { $showall="1"; }
      if ( $showall )
      {
        if ( $tid eq $form{tid} ) { $tline="<b>$ttitle</b>"; }
        else { $tline="<a href=$ITKASM?act=listres&tid=$tid class=\"hoverlink\" title=\"Display \'$ttitle\' Profile\" style=\"color:$lnkcolor\">$ttitle</a>"; }
        print qq~
	  <tr><td nowrap valign=top><font $fsn>
            <a href=$ITKASM?act=crlist&ResID=$tid&from=1 class=\"hoverlink\" title="Edit $ttitle"><img src=$IMAGES/edit.png height=12 border=0></a>&nbsp;&nbsp; $tline </font></td></tr>
        ~;
      }
    }
    close(RSV);
    if ( ! "$foundrec" ) { print "<td><font $fsb><b><i>Create A Resource First</i></b></font></td>\n";}
    print qq~
	</table>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td valign=top><table border=0 width=100%>
  	<td valign=top><table border=0>
        <tr><td align=center valign=top colspan=2><font $fsb><b>Resources</b></font><font $fsn> - ID: $form{tid} <br><hr size=1 ></font></b></td></tr>
    ~;
    if ( $form{tid} )
    { 
      if ( ! -f "$RESDIR/$form{tid}/$form{tid}.dat") { `touch $RESDIR/$form{tid}/$form{tid}.dat`; }
      open(RES, "$RESDIR/$form{tid}/$form{tid}.dat" ) || print "CANNOT READ resource file: $RESDIR/$form{tid}/$form{tid}.dat";
        while (<RES>)
        {
	  chomp;
          ($frname,$frurl) = split(/\t/, $_); 
	  ($mine,$mtype, $mineID) = split (/:/, $_);
          if ( /{hr}/ ) { $frname = "--- Separator ---"; $frurl=""; }
          if ( /{newline}/ ) { $frname = "--- NewLine ---"; $frurl=""; }
 	  if ( /^%%%tracker:/ ) { $FILE="$TRACKER"; get_title_in_file;  $frname="$title"; $frurl="$ITKASMTRCK?ID=$mineID"; }
 	  if ( /^%%%task:/ ) { $FILE="$TASK"; get_title_in_file;  $frname="$title"; $frurl="$ITKASMTSK?ID=$mineID"; }
 	  if ( /^%%%oncall:/ ) { $FILE="$ONCALL"; get_title_in_file;  $frname="$title"; $frurl="$ITKASMONC?ID=$mineID"; }
 	  if ( /^%%%kbase:/ ) { $FILE="$KBASE"; get_title_in_file;  $frname="$title"; $frurl="$ITKASMKBASE?ID=$mineID"; }
 	  if ( /^%%%asm:/ ) 
          {
#kirk
		if ( $mineID ne "ALL" ) 
		{ $FILE="$ONCALL"; get_title_in_file;  $frname="$title"; $frurl="$ITKASMONC?ID=$mineID"; }
		else 
	        { $rurl="$ITKASMASM"; $rname="Asset Management"; $embed="";}
	  }
 	  #elsif ( /^%%%reserve:/ ) { 
 	#	if ( $mtype eq "tracker" ) { $FILE="$TRACKER"; 
	#	$FILE="$RESERVE"; get_title_in_file; $frname="$title"; $frurl="?????ID=$mineID"; 
	#  }
	  $len = length $frurl;
   	  if( $len > 60 ) { $frurl = substr ($frurl, 0, 60); $frurl = "${frurl}..."; }
	  print "<tr><td valign=top nowrap width=35%><font $fsn>$frname</font></td><td valign=top nowrap width=100%><font $fsn>$frurl</font></td></tr>\n"; 
        }
        close(RES);
    }
      print "</table>";
   print "<td align=center valign=top colspan=2><b><font $fsb>Access<br><hr size=1 ></font></b>";
    if ( $form{tid} ) 
    {
      $MINEDIR="$RESDIR/$form{tid}";
      &display_mineaccess;
    }
    print "</td>";
    print "</table>";
    print "</td></table>";

}


###
### LIST ALL SEARCHES CREATED
###
sub list_search
{
    if ( $form{sid} )
    { $createsearch="Step 2: <a href=\"$ITKASM?act=ckave&kid=search:$form{sid}\" class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create A Kave</a>"; }
    print qq~
        $hr_line
	<table width=100% bgcolor=$hdrcolor cellpadding=3><td align=left>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
	</font><font $fsb>
	 | <b>List Searches</b> | 
	</font><font $fsbl>
        <a href=$ITKASM?act=crsearch class=\"hoverlink\" title="Create a Search Mine" style=\"color:$lnkcolor\">Create Search</a>
	</font></td><td valign=top align=right><font $fsbl>
	$createkave
	</font></td>
	</table>
        $hr_line
   ~;
if ( ! -s  "$SRCH" ) { print "<td><font $fsberr><b><i>No Search Mines defined</i></b></font></td>\n"; exit;}
   print qq~
        <font $fsn>Click to View or Edit a Search Mine:</font><p>
   <!-- Master Table -->
    <table border=0>
    <td>
        <table cellpadding=3 cellspacing=3 border=0 >
        <tr>
	  <td align=center colspan=1 ><b><font $fsb>Edit</font><br><hr size=1></b></td>
	  <td align=center colspan=1><b><font $fsb>Mines</font><br><hr size=1></b></td>
	  <td align=center colspan=1><b><font $fsb>Description</font><br><hr size=1></b></td>
	</tr>
    ~;
    #
    # Read the search.dat file and get the titles and id's.
    #
    if ( ! -f "$SRCH" ) { `touch $SRCH`; } 
    $foundrec="";
    open(SRV, "$SRCH" ) || print "CANNOT OPEN SEARCH LIST: $SRCH";
    while (<SRV>)
    {
      chomp; $foundrec="1";
      ($ttitle, $tid, $tdesc)=split(/\t/, $_);
      $srchdesc="";
      open(SRP, "$SRCHDIR/$tid/${tid}.pro" ) || print "CANNOT OPEN SEARCH PROFILE $SRCHDIR/$tid/${tid}.pro";
      while(<SRP>)
      {
	if ( /^desc\t/) { ($d, $srchdesc) = split(/\t/, "$_"); }
      }
      close(SRP);
      if ( $tid eq $form{srchid} ) 
{ $tline="<font $fsn><b>$ttitle</b>"; $tdesc="<b>$srchdesc</b>";}
      else 
{ $tline="<font $fsn><a href=$ITKASM?act=listsearch&srchid=$tid class=\"hoverlink\" title=\"Display \'$ttitle\' Profile\" style=\"color:$lnkcolor\">$ttitle</a>"; $tdesc="$srchdesc"; }
      print qq~
	<tr><td nowrap valign=top align=center>
          <a href=$ITKASM?act=crsearch&srchid=$tid&from=1><img src=$IMAGES/edit.png height=12 border=0></a> 
	</td><td>$tline</font></td>
	<td><font $fsn>$tdesc</font></td>
	</tr>
      ~;
    }
    close(SRV);
    print qq~
	</td>
     </table>
   	<!-- DISPLAY PROFILE -->
	  <td valign=top align=center colspan=1><b><font $fsb>Profile</font><br><hr size=1></b>
	  <table cellpadding=3 cellspacing=3><td valign=top>

    ~;
    if ( $form{srchid} ) 
    {
      open(SRP, "$SRCHDIR/$form{srchid}/$form{srchid}.pro" ) || print "CANNOT OPEN SEARCH PROFILE $SRCHDIR/$form{srchid}/$form{srchid}.pro";
      while (<SRP>)
      {
	chomp; 
        ($tfield,$tval) = split(/\t/, $_);
        if ( /^name\t/ ) { $tval= "$tval"; $tfield="Title:"; }
        if ( /^id\t/ ) { $tfield="ID:"; }
        if ( /^desc\t/ ) { $tfield="Description:"; $desc="$tval"; }
        if ( /^srchwhat\t/ ) 
	{ 
	  $tfield="Search What:";
	  if ($tval eq "mines" ) { $tval="Specific Mines"; } 
	  else { $tval = "All Mines";  }
	}
        if ( /^mine\t/ ) { $tval= "$tval"; $tfield="Mine"; }
        print "<tr><td valign=top align=right><font $fsn>$tfield</font>
	  </td><td valign=top align=left><font $fsn>$tval</font></td></tr>\n";
      }
      close(SRP);
    }
    print qq~
</td></table>
	  </td>
   	<!-- DISPLAY ACCESS LEVELS -->
	  <td valign=top align=center colspan=1><b><font $fsb>Access</font><br><hr size=1></b>
    ~;
    if ( $form{srchid} )
    {
      $MINEDIR="$SRCHDIR/$form{srchid}";
      &display_mineaccess;
    }
    print "</td>";
    print qq~
	</table>
    ~;

}

###
### CREATE SEARCH
###
sub create_search
{
#print "buffer = $buffer<p> $form{srchid}";
  # Check if coming from list to be editted
  # If so load the name and content
  if ( $form{sact} || $form{from} )
  {
    $form{srchname}="";
    @mines=();
    open(SRV, "$SRCHDIR/$form{srchid}/$form{srchid}.pro" ) || print "CANNOT read: $SRCHDIR/$form{srchid}/$form{srchid}.pro";
    while(<SRV>)
    {
        chomp;
        if ( /^name\t/) { ($d, $form{srchname})=split(/\t/, $_); }
        if ( /^desc\t/) { ($d, $form{srchdesc})=split(/\t/, $_); }
        if ( /^srchwhat\t/) { ($d, $form{srchwhat})=split(/\t/, $_); }
        if ( /^mine\t/ ) { ($d, $form{mine})=split(/\t/, $_); }
	 
    }
    close(SRV);
   }
  $srchid="";
  if ( ! "$form{srchid}" && "$form{srchname}" )
  {
    $valid="";
    while ( ! $valid  )
    {
      my $random_string=&get_token(6);
      &get_token;
      $number="$random_string";
      if ( ! -d "$SRCHDIR/${number}" ) { $valid="1"; }
    }
      $srchid = "$number";
      if ( ! -d "$SRCHDIR/$srchid" )
      { `mkdir -p "$SRCHDIR/$srchid"`; }

      #
      # Write to Search index file
      #
      open(SRV, ">> $SRCH" ) || print "CANNOT WRITE SEARCH DATA: $SRCH";
      print SRV "$form{srchname}\t$srchid\n";
      close(SRV);
      $form{srchid} = "$srchid";

      # Sort file
      tie @LST, 'Tie::File', "$SRCH" or die;
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
  }
  #
  # IF SEARCH NAME IS ENTERED OR CHANGED
  #
  if ( $form{srchname} ) 
  {
    $srchid="$form{srchid}";
    #
    # check if name changed and update index
    #
    $curName="";
    open(SRV, "$SRCH" ) || print "CANNOT read: $SRCH";
    while (<SRV>) 
    { 
	chomp; 
	if ( /\t$form{srchid}/ ) { ($idxName,$d)=split(/\t/, $_); } 
    }
    close(SRV);
    if ( "$idxName" ne "$form{srchname}" ) 
    { 
      $ID="$srchid"; $FILE="$SRCH"; 
      $NEWNAME="$form{srchname}"; index_namechg; 
      # Sort file
      tie @LST, 'Tie::File', "$SRCH" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    }
    #
    # Create data structure.
    #
    open(SRV, "> $SRCHDIR/$form{srchid}/$form{srchid}.pro" ) || print "CANNOT write: $SRCHDIR/$form{srchid}/$form{srchid}.pro";
    print SRV "id\t$srchid\n";
    print SRV "name\t$form{srchname}\n";
    print SRV "desc\t$form{srchdesc}\n";
    print SRV "srchwhat\t$form{srchwhat}\n";
    print SRV "mine\t$form{mine}\n";
  }

  #
  # DISPLAY CREATE SEARCH PAGE
  #
  if ( $form{srchid} )
  {
        $HiddenID="<input type=hidden name=srchid value=\"$form{srchid}\">";
        $createkave="<font $fsb>Step 2: </font><font $fsbl><a href=$ITKASM?act=ckave&kid=search:$form{srchid} class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create a KAVE</a></font>";
  }
  if ( ! "$form{srchwhat}" ) { $achecked="checked"; $mchecked=""; }
  if ( "$form{srchwhat}" eq "mines" ) { $mchecked="checked"; $achecked="checked"; }
  else { $achecked="checked"; $mchecked=""; }
  if ($form{srchid}) { $create_search=" <font $fsb><b>Update Search</b> | <font $fsbl><a href=$ITKASM?act=crsearch class=\"hoverlink\" style=\"color:$lnkcolor\">Create Search</a></font>"; }
  else { $create_search="<font $fsb><b>Create Search</b></font>"; }
  print qq~
      $hr_line
      <table width=100% bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
      <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> |
      <a href=$ITKASM?act=listsearch class=\"hoverlink\" title="List available Search Mines" style=\"color:$lnkcolor\">List Search</a> | </font>
      $create_search
      </td><td valign=top align=right >
        $createkave
      </td>
      </table>
  <!--             -->
  <!-- CREATE Search -->
  <!--             -->
      $hr_line
<table border=0 width=100%>
<td>
      <p>
      <form method=post action=$ITKASM>
        <input type=hidden name=act value=crsearch>
        $HiddenID
      <table border=0 cellpadding=3>
      <tr><td align=right valign=top>
        <font $fsn><b>Search Title: </b></font>
        </td><td align=left>
        <input type=text size=20 name="srchname" value="$form{srchname}">
        </td>
      </tr><tr><td align=right valign=top>
        <font $fsn><b>Search Description: </b></font>
        </td><td valign=top>
        <input type=text size=40 name="srchdesc" value="$form{srchdesc}">
        </td>
      </tr>
      <tr><td align=right valign=top>
        <font $fsn><b>Search ID: </b></font>
        </td><td align=left><font $fsn>$form{srchid}</font>
      </td>
      </tr>
     <tr><td valign=top align=right>
        <font $fsn><b>Search What:</b></font><br>&nbsp;
	</td><td align=left valign=top>
        <input type="radio" name="srchwhat" value="all" $achecked> <font $fsn>Everything &nbsp; </font>
        <input type="radio" name="srchwhat" value="mines" $mchecked> <font $fsn>Specific Mine</font>
	</td>
     </tr>
  ~;
  
  #
  # Add which MINE to SEARCH
  #

  if ( "$form{srchwhat}" eq "mines" ) 
  {
    print "<tr><td align=right valign=top><b><font $fsn>Select MINES to Search:</font></b></td><td><table border=0 cellpadding=0>\n";
    @mtypes=("Tracker:$TRACKER","Task:$TASK", "KnowledgeBase:$KBASE");
    @rtypes=("Assets:$PROFILES");
    foreach $mt (@mtypes)
    {
      ($minetype,$minefile)=split(/:/, "$mt");
      $lcmine=lc($minetype);
      print "<tr><td colspan=2><font $fsn><b><u>$minetype</b></u></font></td></tr>\n";

      #
      # Collect mines out of the 
      #
      if ( -f "$minefile" )
      {
        open(SRCHMN, "$minefile" ) || print "Cannot find mine file: $minefile<br>\n";
        while (<SRCHMN>)
        {
          chomp;
          ($mtitle,$mid)=split(/\t/, "$_");
	  $mline="$lcmine-$mid";
	  $checked="";
	  if ( "$mline" eq "$form{mine}" ) { $checked="checked"; }
          else { $checked=""; }
	  $mdesc="";
  	  #print "$mtitle - $mid<p>";
          open(PRO, "$DPATH/$lcmine/$mid/${mid}.pro" ) || print "Cannot find mine file: $DPATH/$mine/$mid/${mid}.pro\n";
          while (<PRO>)
          { 
	    if ( /desc/ ) { ($d,$mdesc)=split(/\t/, "$_"); $mdesc=" - $mdesc"; } 
 	  }
	  close(PRO);
          print qq~
	    <tr><td><input name='mine' type="radio" value="$mline" $checked></td>
	    <td><font $fsn>$mtitle</font></td><td><font $fsn>$mdesc</font></td></tr>
	  ~;
        }
        close(SRCHMN);
      } #if minefile
	print "<tr><td>&nbsp;</td></tr>\n";
    } #for
    print "<tr><td colspan=2><font $fsn><b><u>Reserved Mines</b></u></font></td></tr>\n";
    foreach $r (@rtypes)
    {
      ($minetype, $minefile)=split(/:/, "$r");
      $lcmine=lc($minetype);
      $checked="";
      foreach $m (@mmines)
      {
	if ( "$lcmine" eq "$m" ) { $checked="checked"; }
      }
      print qq~
	<tr><td><input name='mine' type="radio" value="$lcmine" $checked></td>
	<td><font $fsn>$minetype</font></td></tr>
      ~;
    }
    print "</table>";
  } # if what=mines

  print qq~
	</table>
        <p> $hr_line
        <input type=submit name=save value="Save">
      </form>
     <td valign=top>
  ~;
    # SHOW KAVES DEFINED FOR MINE
    $mineid="$form{srchid}"; $minename="$form{srchname}"; $minetype="search";
    $MINEDIR="$DPATH/search/$form{srchid}"; 
    list_kaves_def;
    if ( $form{srchid} ) 
    {
      @MINEARGS=("act=crsearch", "srchid=$form{srchid}","from=1");
      &mine_access;
    }
  print qq~
</td>
</table>
   ~; 

}


###
### CREATE RESOURCE
###
sub create_resource
{
#print "buffer = $buffer<p>";
  # Check if coming from list to be editted
  # If so load the name and content
  if ( $form{sact} || $form{from} )
  {
    #$form{resource}="";
    open(RES, "$RESDIR/$form{ResID}/$form{ResID}.pro" ) || print "CANNOT read: $RESDIR/$form{ResID}/$form{ResID}.pro";
    while(<RES>)
    { 
	chomp;
	if ( /^name\t/ && ! $form{resource}) { ($d, $form{resource})=split(/\t/, $_); }
	if ( /^restype\t/ && ! $form{restype}) { ($d, $form{restype})=split(/\t/, $_); }
    }
    close(RES);
   }   
  $ResID="";
  if ( ! "$form{ResID}" && "$form{resource}" )
  {
    $valid="";
    while ( ! $valid  )
    {
      my $random_string=&get_token(6);
      &get_token;
      $number="$random_string";
      if ( ! -d "$RESDIR/${number}" ) { $valid="1"; }
    }
      $ResID = "$number";
      if ( ! -d "$RESDIR/$ResID" ) 
      { `mkdir -p "$RESDIR/$ResID"`; }

      #
      # Write to Resource index file
      #
      open(RES, ">> $RESRC" ) || print "CANNOT WRITE $RESRC";
      print RES "$form{resource}\t$ResID\n";
      close(RES);
      $form{ResID} = "$ResID";

      # Sort file
      tie @LST, 'Tie::File', "$RESRC" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
  }

  #
  # DELETE the ITEM
  #
  if ( $form{sact} eq "delr" ) { $FILE="$RESDIR/$form{ResID}/$form{ResID}.dat"; delete_task_gta; }

  #
  # GET THE NAME AND URL TO EDIT
  #
  if ( $form{sact} eq "edit" ) 
  { 
	# GET ENTRY
	$rCOUNT=0;
        open(RES, "$RESDIR/$form{ResID}/$form{ResID}.dat" ) || print "CANNOT READ resource file: $RESDIR/$form{ResID}/$form{ResID}.dat";
	while (<RES>)
	{
  	  $rCOUNT++;
          if ( $rCOUNT == $form{num} ) 
	  { ($frname,$frurl) = split(/\t/, $_); }
	}
	close(RES);
  }
  else { $frname=""; $frurl=""; }
#print "$form{mineam}";
  #
  # IF A MINE WAS SELECTED
  #
  if ( $form{sact} ne "update" )
  {
  if ( ($form{minetrk} || $form{minetsk} || $form{minemsc} || $form{resname}) 
	|| $form{mineonc} || $form{minekb} || $form{mineam} && ! $form{num} ) 
  {
    open(RES, ">> $RESDIR/$form{ResID}/$form{ResID}.dat" ) || print "CANNOT WRITE resource file: $RESDIR/$form{ResID}/$form{ResID}.dat";
    if ( $form{minetrk} ) { print RES "$form{minetrk}\n"; }
    elsif ( $form{minetsk} ) { print RES "$form{minetsk}\n"; }
    elsif ( $form{minersv} ) { print RES "$form{minersv}\n"; }
    elsif ( $form{mineonc} ) { print RES "$form{mineonc}\n"; }
    elsif ( $form{mineam} ) { print RES "$form{mineam}\n"; }
    elsif ( $form{minekb} ) { print RES "$form{minekb}\n"; }
    elsif ( $form{minemsc} ) { print RES "$form{minemsc}\n"; }
    else
    {
      print RES "$form{resname}\t";
      if ( $form{resurl} )  { print RES "$rawform{resurl}\n"; }
      else { print RES "\n"; }
    }
    close(RES);
  }
  }

  #
  # IF RESOURCE ENTRY WAS MOVED
  #
  if ( $form{sact} eq "move" && $form{num} )
  {
    @LST=(); @NEWLST=();
    tie @LST, 'Tie::File', "$RESDIR/$form{ResID}/$form{ResID}.dat" or die; 
    $COUNT=0; $found="";
    $len = scalar @LST;
    foreach (@LST)
    {
      $COUNT++;
      if ( ! $moved )
      {
        if ( $len == $form{num} )
        {
           $found="$LST[$len-1]"; $moved="1"; 
            push@NEWLST, "$LST[$len-1]";  $found="";
        }
      }
      if ( $COUNT == $form{num} )  { $found="$_";  }
      else
      {
            if ( "$found" ) { push@NEWLST, "$_";  push@NEWLST, "$found"; $found=""; }
            else {  push@NEWLST, "$_"; $found=""; }
      }
    }
    @LST=@NEWLST;
    untie(@LST);
  }

  #
  # IF A RESOURCE ENTRY OR URL WAS EDITTED
  #
  if ( $form{num} && $form{sact} eq "update" ) 
  {
    @LST=(); @NEWLST=();
    tie @LST, 'Tie::File', "$RESDIR/$form{ResID}/$form{ResID}.dat" or die; 
    $COUNT=0; 
    foreach (@LST)
    {
      $COUNT++;
      if ( $COUNT == $form{num} )  { push@NEWLST, "$form{resname}\t$rawform{resurl}"; }
      else { push@NEWLST, "$_"; }
    }
    @LST=@NEWLST;
    untie(@LST);
  }
  #
  # IF RESOURCE NAME IS ENTERED OR CHANGED
  #
  if ( $form{resource} ) 
  {
    $ResID="$form{ResID}";
    #
    # check if name changed and update index
    #
    $curName="";
    open(RESD, "$RESRC" ) || print "CANNOT read: $RESRC";
    while (<RESD>) 
    { 
	chomp; 
	if ( /\t$form{ResID}/ ) { ($idxName,$d)=split(/\t/, $_); } 
    }
    close(RESD);
    if ( "$idxName" ne "$form{resource}" ) 
    { 
      $ID="$ResID"; $FILE="$RESRC"; 
      $NEWNAME="$form{resource}"; index_namechg; 
      # Sort file
      tie @LST, 'Tie::File', "$RESRC" or die; 
      @NEWLST=sort @LST;
      @LST=@NEWLST;
      untie(@LST);
    }
    #
    # Create data structure.
    #
    open(RES, "> $RESDIR/$form{ResID}/$form{ResID}.pro" ) || print "CANNOT write: $RESDIR/$form{ResID}/$form{ResID}.pro";
    print RES "id\t$ResID\n";
    print RES "name\t$form{resource}\n";
    print RES "restype\t$form{restype}\n";
    close(RES);

  }

  #
  # DISPLAY CREATE RESOURCE PAGE
  #
  if ( $form{ResID} ) 
  { 
	$HiddenID="<input type=hidden name=ResID value=\"$form{ResID}\">";
	$createkave="Step 2: <a href=$ITKASM?act=ckave&kid=resource:$form{ResID} class=\"hoverlink\" title=\"Goto Create A Kave\" style=\"color:$lnkcolor\">Create a KAVE</a>";
          $CRTLINK=" | <font $fsbl><a href=$ITKASM?act=crlist class=\"hoverlink\" title=\"Create a Resource Mine\" style=\"color:$lnkcolor\">Create Resource</a></font>";
	  $CRTUPD="Update";
  }
  else { $CRTUPD="Create"; $CRTLINK="";}

  if ( $frname ) { $HiddenUPD="<input type=hidden name=sact value=\"update\">"; }
  if  ( $form{restype} eq "verticle" ) { $vselected="selected"; $hselected=""; }
  else  { $vselected=""; $hselected="selected"; }
  print qq~
      $hr_line
      <table width=100% bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
      <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN class=\"hoverlink\" title="Go To Settings" style=\"color:$lnkcolor\">Settings</a> |
      <a href=$ITKASM?act=listres class=\"hoverlink\" title="List available Resource Mines" style=\"color:$lnkcolor\">List Resources</a> 
      </font><font $fsb>
      | <b>$CRTUPD Resource</b> 
      </font>
      $CRTLINK
      </td><td valign=top align=right width=15%><font $fsbl>
      $createkave
      </font>
      </td>
      </table>
      $hr_line
      <form method=post action=$ITKASM >
        <input type=hidden name=act value=crlist>
	$HiddenID
	$HiddenUPD
      <table border=0>
        <td valign=top halign=left ><font $fsn>
        <b>Resource List Title: </b>
        <input type=text size=20 name="resource" value="$form{resource}" required>
        <p>
        <b>Resource ID:</b> $form{ResID}
	<p>
	<font $fsn><b>Resource Type: </font></b>
        <select name='restype' onchange='this.form.submit()'>
        <option value="verticle" $vselected>Verticle</option>
        <option value="horizontal" $hselected>Horizontal</option>
	</select><p>
        <table border=0 cellpadding=3>
	<tr><td valign=top>
        <font $fsn><b>Name:</b></font>
        <input type=text size=25 name="resname" value="$frname" title="Resource Name"><br>
	</td><td>&nbsp;</td><td valign=top>
        <font $fsn><b>URL:</b></font>
        <!-- <input type="url" size=40 name="resurl" pattern="https?://.+" value="$frurl"><p> -->
        <input size=40 name="resurl" value="$frurl" title="Enter URL or leave blank for bold text. Enter 'nolink' for straight text to be displayed"><p> 
	</td></tr>
	<tr><td colspan=3>
<!-- <font $fsn><b>Add: </font></b> -->
        <select name='minetrk' onchange='this.form.submit()'>
        <option value="">Trackers</option>
      ~;
      # SELECT TRACKERS TO ADD
      open(TRK, "$TRACKER") || print "Cannot find $TRACKER";
      while (<TRK>)
      {
        chomp;
        ($trktitle, $ktypeid) = split(/\t/, "$_");
	print "<option value=\"%%%tracker:$ktypeid\">$trktitle</option>\n";
      }
      close(TRK); 
      print "</select>&nbsp;&nbsp;&nbsp;";

      # SELECT TASKS TO ADD
      print "<select name='minetsk' onchange='this.form.submit()'>\n";
      print "<option value=\"\">Tasks</option>\n";
      open(TSK, "$TASK") || print "Cannot find $TASK";
      while (<TSK>)
      {
        chomp;
        ($tsktitle, $ktypeid) = split(/\t/, "$_");
        print "<option value=\"%%%task:$ktypeid\" >$tsktitle</option>\n";
      }
      close(TSK);
      print "</select>&nbsp;&nbsp;&nbsp;";

      # SELECT ONCALL TO ADD
      print "<select name='mineonc' onchange='this.form.submit()'>\n";
      print "<option value=\"\">On-Call</option>\n";
      open(ONC, "$ONCALL") || print "Cannot find $TASK";
      while (<ONC>)
      {
        chomp;
        ($onctitle, $ktypeid) = split(/\t/, "$_");
        print "<option value=\"%%%oncall:$ktypeid\" >$onctitle</option>\n";
      }
      close(ONC);
      print "</select>&nbsp;&nbsp;&nbsp;<p>";

      # SELECT ASSET TO ADD
      print "<select name='mineam' onchange='this.form.submit()'>\n";
      print "<option value=\"\">Assets</option>\n";
      print "<option value=\"%%%asm:ALL\">ALL Assets</option>\n";
      open(PRO, "$PROFILES") || print "Cannot find $RESERVE";
      while (<PRO>)
      {
        chomp;
        ($profile) = split(/\t/, $_);
        if ( $profile ) { print "<option value=\"%%%asm:$profile\" >$profile</option>\n"; }
      }
      close(RSV);
      print "</select>&nbsp;&nbsp;&nbsp;";

      # SELECT KBASE TO ADD
      print "<select name='minekb' onchange='this.form.submit()'>\n";
      print "<option value=\"\">KnowledgeBase</option>\n";
      open(KB, "$KBASE") || print "Cannot find $TASK";
      while (<KB>)
      {
        chomp;
        ($kbtitle, $ktypeid) = split(/\t/, "$_");
        print "<option value=\"%%%kbase:$ktypeid\" >$kbtitle</option>\n";
      }
      close(KB);
      print "</select>&nbsp;&nbsp;&nbsp;";

      # SELECT MISCELLANEOUS TO ADD
      print "<select name='minemsc' onchange='this.form.submit()'>\n";
      print "<option value=\"\">Miscellaneous</option>\n";
      print "<option value=\"{hr}\">Separator</option>\n";
      print "<option value=\"{newline}\">New Line</option>\n";
      close(RSV);
      print "</select>";

      print qq~
        &nbsp;
	</td></tr>
	</table>
        <hr size=1>
        <table width=100% border=0 cellpadding=3 cellspacing=0>
	<tr><td align=center><font $fsn>Edit</font></td>
	<td align=center><font $fsn>Click to move</font></td>
	<td align=center><font $fsn>Click to test link</font></td>
	<td align=center><font $fsn>Delete entry</font></td></tr>
	<tr><td colspan=4><hr size=1></td></tr>
      ~;

  # IF editting, pass the line number being editted so it can be replaced.
  if ( $frname ) { print "<input type=hidden name=num value=$form{num}>\n"; }
  if ( -f "$RESDIR/$form{ResID}/$form{ResID}.dat" )
  {
    $rescnt=0; $bxc="";
    open(RESD, "$RESDIR/$form{ResID}/$form{ResID}.dat" ) || print "CANNOT read dat: $RESDIR/$form{ResID}/$form{ResID}.dat";
    while (<RESD>)
    {
      chomp;
      $rescnt++;
      ($rname, $rurl) = split(/\t/, $_);
      if ( $bxc ) { $bgc="$gbxbg2"; $bxc=""; }
      else { $bgc="$gbxbg1"; $bxc="1"; }
      print qq~
        <tr>
      ~;
      if ( /^%%%tracker:/ ) 
      { 
        $_ =~ s/%%%//;
   	($mine,$mineID) = split (/:/, $_);
	$FILE="$TRACKER"; get_title_in_file;
        print qq~
          <td valign=top></td>
          <td valign=top nowrap bgcolor="$bgc"><font $fsn>
          <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" title="Click to move down" style=\"color:$lnkcolor\">$title</a></font></td>
          <td valign=top bgcolor=$bgc><font $fsn>
          <a href="$ITKASMTRCK?ID=$mineID" target=test style=\"color:$lnkcolor\">$ITKASMTRCK?ID=$mineID</font></td>
        ~;
      }
      elsif ( /^%%%task:/ ) 
      {
        $_ =~ s/%%%//;
        ($mine,$mineID) = split (/:/, $_);
        $FILE="$TASK"; get_title_in_file;
        print qq~
          <td valign=top></td>
          <td valign=top nowrap bgcolor=$bgc><font $fsn>
          <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" title="Click to move down" style=\"color:$lnkcolor\">$title</a></font></td>
          <td valign=top bgcolor=$bgc><font $fsn>
          <a href="$ITKASMTSK?ID=$mineID" target=test style=\"color:$lnkcolor\">$ITKASMTSK?task&ID=$mineID</font></td>
        ~;
      }
      elsif ( /^%%%oncall:/ ) 
      {
        $_ =~ s/%%%//;
        ($mine,$mineID) = split (/:/, $_);
        $FILE="$ONCALL"; get_title_in_file;
        print qq~
          <td valign=top></td>
          <td valign=top nowrap bgcolor=$bgc><font $fsn>
          <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" title="Click to move down" style=\"color:$lnkcolor\">$title</a></font></td>
          <td valign=top bgcolor=$bgc><font $fsn>
          <a href="$ITKASMONC?ID=$mineID" target=test style=\"color:$lnkcolor\">$ITKASMONC?task&ID=$mineID</font></td>
        ~;
      }
      elsif ( /^%%%kbase:/ ) 
      {
        $_ =~ s/%%%//;
        ($mine,$mineID) = split (/:/, $_);
        $FILE="$KBASE"; get_title_in_file;
        print qq~
          <td valign=top></td>
          <td valign=top nowrap bgcolor=$bgc><font $fsn>
          <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" title="Click to move down" style=\"color:$lnkcolor\">$title</a></font></td>
          <td valign=top bgcolor=$bgc><font $fsn>
          <a href="$ITKASMKBASE?ID=$mineID" target=test style=\"color:$lnkcolor\">$ITKASMKBASE?task&ID=$mineID</font></td>
        ~;
      }
      elsif ( /^%%%asm:/ ) 
      {
        $_ =~ s/%%%//;
        ($mine,$mineID) = split (/:/, $_);
        $FILE="$KBASE"; get_title_in_file;
        if ( $mineID ne "ALL" ) { $urlargs="act=dp&sact=pro&h=$mineID"; }
        else { $urlargs=""; $mineID="All Assets"}
        print qq~
          <td valign=top></td>
          <td valign=top nowrap bgcolor=$bgc><font $fsn>
          <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" title="Click to Move Down" style=\"color:$lnkcolor\">$mineID</a></font></td>
          <td valign=top bgcolor=$bgc><font $fsn>
          <a href="$ITKASMASM?${urlargs}" target=test style=\"color:$lnkcolor\">$ITKASMASM?${urlargs}</font></td>
        ~;
      }
      elsif ( /^%%%reserve:/ ) 
      { 
        $_ =~ s/%%%//;
	($mine,$mineID) = split (/:/, $_);
        $FILE="$RESERVE"; get_title_in_file;
        print qq~
          <td valign=top></td>
          <td valign=top nowrap bgcolor=$bgc><font $fsn>
          <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" title="Click to move down" style=\"color:$lnkcolor\">$title</a></font></td>
          <td valign=top bgcolor=$bgc><font $fsn>
          <a href="$ITKASM?????&ID=$mineID" target=test style=\"color:$lnkcolor\">$ITKASM?????&ID=$mineID</font></td>
        ~;
############## See ??????? above #############

      }
      elsif ( /{hr}/ ) 
      {
	print qq~  
	  <td></td>
	  <td valin=top colspan=2 align=left bgcolor=$bgc><font $fsn>
	  <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" style=\"color:$lnkcolor\"> --- Separator ---</a></font></td> </td>
	~;
      }
      elsif ( /{newline}/ ) 
      {
	print qq~  
	  <td></td>
	  <td valin=top colspan=2 align=left bgcolor=$bgc><font $fsn>
	  <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" style=\"color:$lnkcolor\"> --- New Line ---</a></font></td> </td>
	~;
      }
      else
      { 
	if ( ! "$rurl" ) { $NEWrname="<b>$rname</b>"; }
	else { $NEWrname="$rname"; }
   	$rurllen = length($rurl);
        if ( $rurllen > 60 )
	{
  	  $NEWrurl = substr $rurl, 0, 60;	
	  $NEWrurl = "${NEWrurl}...";
	}
	else { $NEWrurl="$rurl";}
         print qq~ 
	  <td valign=top align=center>
              <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=edit&num=$rescnt title="Edit Resource Link"><img src=$IMAGES/edit.png height=12 border=0></a> $fline
	  </td>
	  <td valign=top nowrap bgcolor=$bgc><font $fsn>
	  <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=move&num=$rescnt class=\"hoverlink\" title="Click to Move Down" style=\"color:$lnkcolor\">$NEWrname</a></font></td>
          <td valign=top bgcolor=$bgc><font $fsn>
	  <a href="$rurl" target=test class=\"hoverlink\" title="Click to Test" style=\"color:$lnkcolor\">$NEWrurl</font></td>
  	~; 
      }
        print qq~
	  <td valign=top align=center bgcolor=$bgc>
          <a href=$ITKASM?act=crlist&ResID=$form{ResID}&sact=delr&num=$rescnt title="Delete Resource Link">
          <img src=$IMAGES/trashcan.png height=15 border=0>
        </td></tr>
      ~;
    }
    close(RESD);
  }  

    print qq~
      </table>
      </td valign=top><td>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp</td><td valign=top>
    ~;
    # SHOW KAVES DEFINED FOR MINE
    $mineid="$form{ResID}"; $minename="$form{resource}";
     $MINEDIR="$RESDIR/$form{ResID}"; $minetype="resource";
    list_kaves_def;

    if ( $form{ResID} ) 
    {
      #@MINEARGS=("act=crlist","ResID=$form{ResID}","sact=1");
      @MINEARGS=("act=crlist","ResID=$form{ResID}","from=1");
      &mine_access;
    }
     print qq~
       </td></table>
    	 <br>
     ~;

        open(TMP, "$ETC/kave-templates.dat") || print "ERROR: Cannot find $ETC/kave-templates.dat";
       	while (<TMP>)
	{
	  chomp;
  	  if ( /:Default,/ ) 
	  { 
		$kconfig="$_"; 
        	($d1,$khtx,$kfbg,$kbrd,$kwdt,$kbkg1,$kbkg2,$kbdybrd,$khrclr,$ktxt,$klnk)=split(/,/, $_);
	  }
  	}
	close(TMP);
	if ( ! $form{TW} ) { $form{TW} = 300; }
	  #width=$kwdt</font>
        print qq~
	  $hr_line
          <font $fsn>Sample Kave Template: 
          &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; Width = <input type=text name=TW value=$form{TW} size=5>
          &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
 	   <input type=submit name=ksave value=\"Save\">
	  </font><p>
        ~;
        $kwdt=$form{TW};
        $kconfig="%%%open.none:$kavename,$khtx,$kfbg,$kbrd,$kwdt,$kbkg1,$kbkg2,$kbdybrd,$khrclr,$ktxt,$klnk";
        $kavename= "$form{resource}";
        &open_kave; 
        print qq~
	<tr><td bgcolor=$gbxbg2>
 	~;	
        if ( ! -s "$RESDIR/$form{ResID}/$form{ResID}.dat" ) 
	{ 
	   print "&nbsp;<p><i><center><font $fsn>This will populate <br>with your entries</font></center></i><p>&nbsp;<p>&nbsp;<p>&nbsp;<p>"; 
        }
   	else
	{
          # GET THE RESOURCE TYPE
          open (RESTY, "$RESDIR/$form{ResID}/$form{ResID}.pro") || print "CANNOT OPEN $RESDIR/$form{ResID}/$form{ResID}.dat";
   	  while (<RESTY>)
	  { chomp; if ( /^restype\t/) { ($d, $form{restype})=split(/\t/, $_); } }
          close(RESTY);
	  $cnt=0;
          open (RES, "$RESDIR/$form{ResID}/$form{ResID}.dat") || print "CANNOT OPEN $RESDIR/$form{ResID}/$form{ResID}.dat";
   	  while (<RES>)
  	  {
    	    chomp;
	    $embed="";
      	    ($rname, $rurl) = split(/\t/, $_);
	    ($mine,$mineID) = split (/:/, $_);
 	    if ( /^%%%tracker:/ ) { $FILE="$TRACKER"; get_title_in_file; $rurl="$ITKASMTRCK?ID=$mineID"; $rname="$title"; $embed="";}
 	    if ( /^%%%task:/ ) { $FILE="$TASK"; get_title_in_file;  $rurl="$ITKASMTSK?ID=$mineID"; $rname="$title"; $embed="";}
 	    if ( /^%%%oncall:/ ) { $FILE="$ONCALL"; get_title_in_file;  $rurl="$ITKASMONC?ID=$mineID"; $rname="$title"; $embed="";}
 	    if ( /^%%%kbase:/ ) { $FILE="$KBASE"; get_title_in_file;  $rurl="$ITKASMKBASE?ID=$mineID"; $rname="$title"; $embed="";}
 	    if ( /^%%%asm:/ ) 
	    {
              if ( "$mineID" ne "ALL" )
                { $rurl="$ITKASMASM?act=dp&sact=pro&h=$mineID"; $rname="$mineID"; $embed="";}
              else
                { $rurl="$ITKASMASM?&ID=$mineID"; $rname="Asset Management"; $embed="";}
	    }

 	    #if ( /^%%%reserve:/ ) { $FILE="$RESERVE"; get_title_in_file; $rurl="<a href=$ITKASMTRCK/task&ID=$mineID class=\"hoverlink\" style=\"color:$lnkcolor\""; $rname="$title"; $embed="";}
	
	     if ( /^{hr}/ ) { print "$hr_line\n"; $cnt=0; $emb="1"}
	     elsif ( /^{newline}/ ) { print "<font $fsn><p></font>"; $cnt=0;$emb="1"}
             elsif ( "$rurl" eq "nolink" )
             {
                  if ( $form{restype} eq "verticle" ) { $BR="<br>"; }
                  else { $BR=""; }
                  print "<font $fsn>$rname</font>$BR\n";
             }
   	     else 
	     {
	       if ( $form{restype} eq "verticle" ) 
	       {
	         if ( $rurl ) 
 	         { print "<font $fsn><a href=\"$rurl\" target=test title=\"Test Link to $rname\" style=\"color:$lnkcolor\">$rname</a></font><br>\n"; }
	         else 
	         { 
		   # IF THE LINE IS NOT AN EMBEDDED COMMAND (SEPARATOR/NEWLINE) JUST PRINT
		   #if ( ! $emb ) { print "<font $fsn><b><u>$rname</u></b><br>\n"; } 
		     print "<font $fsn><b><u>$rname</u></b><br>\n"; 
	         }
   	       }
               # IF HORIZONTAL
	       else 
 	       { 
	         if ( $rurl ) 
 	         { 
		    if ( $cnt > 0  ) { print " | "; $cnt++; }
		    print "<font $fsn><a href=\"$rurl\" class=\"hoverlink\" target=test style=\"color:$lnkcolor\">$rname</a></font>\n"; 
		    $cnt++;
	         }
	         else 
	         { 
		  if ( ! /^{hr}/ && ! /^{newline}/ )
		  {
		      if ( $emb ) { print "<font $fsn><b>${rname}:</b>\n"; $cnt=0; $emb=""; }
		      else { print "<br><font $fsn><b>${rname}:</b>\n"; $cnt=0; }
		  }
		    
	         }
	       }
	     }
  	  }
  	  close(RES);
   	}
	print qq~
	<p>
	</td></tr>
	~;
	&close_kave;
    print qq~
        </td>
        </table>
        <br>
        </form>
        $hr_line
    ~;

}


###
### LIST ALL TASKS CREATED
###
sub list_freeform
{
#print "$buffer";
    print qq~
        $hr_line
        <table width=100% bgcolor=$hdrcolor cellpadding=3><td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
	</font><font $fsb>
	| <b>List Freeform</b> | 
	</font><font $fsbl>
        <a href=$ITKASM?act=cfree title"Create a Freeform Mine" style=\"color:$lnkcolor\">Create Freeform</a>
	</font>
	</td></table>
        $hr_line
        <font $fsn>Click to View Freeform or Edit:</font><p>

        <table border=0 width=100%>
        <tr valign=top>
        <td align=center><b><font $fsb>Freeform Profiles</font><br><hr size=1 ></b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td align=center ><b><font $fsb>Content<br><hr size=1 ></font></b></td>
	<td align=center ><b><font $fsb>Access<br><hr size=1 ></font></b></td>
	</tr>
    ~;
    #
    # Read the freeform.dat file and get the titles and id's.
    #
    $foundrec="";
    if ( ! -f "$FREE" ) { `touch $FREE`; }
    print "<td valign=top ><table border=0 cellpadding=3 cellspacing=3>";
    if ( ! -s "$FREE" ) { print "<font $fsb><b><i>Nothing Created...</i></b></font>"; }
    open(FRE, "$FREE" ) || print "CANNOT OPEN $FREE";
    while (<FRE>)
    {
      chomp;
      ($ttitle, $tid)=split(/\t/, $_);
      $displayit="";
      if ( /SETTINGS\./ && $GOD )  { $displayit="1"; }
      elsif ( ! /SETTINGS\./ ) { $displayit="1"; }
      #
      # Get all the profile info
      #
      if ( $displayit ) 
      {
        if ( $tid eq $form{tid} ) { $fline="<b>$ttitle</b>"; $clTITLE="$ttitle"; @vTSKPRO=@TSKPRO; }
        else { $fline="<a href=$ITKASM?act=listfree&tid=$tid class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"View \'$ttitle\' Freeform Profile\">$ttitle</a>"; }
        print qq~
          <tr><td nowrap valign=top><font $fsn>
              <a href=$ITKASM?act=cfree&FreeID=$tid&sact=1><img src=$IMAGES/edit.png height=12 border=0></a>&nbsp;&nbsp; $fline
          </font></td></tr>
        ~;
      }
    }
    close(FRE);
    #
    # Display the contents if selected
    #
    print "</table></td><td></td>";
    if ( $form{tid} ) 
    {
      @FFORM=();
      $FreeFormFile="$FREDIR/$form{tid}/$form{tid}.dat";
      &freeform_process;
      print "<td valign=top><table border=0 width=100%><td>";
      print qq~
      <table><tr><td align=right><font $fsn><b>Title:</b></font></td><td><font $fsn>$ttitle</font></td></tr><tr>
      <td align=right><font $fsn><b>ID:</b></font></td><td><font $fsn>$form{tid}</font></td></tr><tr><td>&nbsp;</td></tr></table>
      ~;
      foreach (@FFORM) 
      { print "$_"; }
      print "</td></table><td valign=top>";
      if ( $form{ResID} ) 
      {
        $MINEDIR="$FREDIR/$form{tid}";
        &display_mineaccess; 
      }
    }
    print "</td></tr></td></table>";
}


#
# GET THE IT KASM LOCATIONS A,B,C,D,etc...
# FOR SELECT STATEMENT
#
sub get_select_kloc
{
  open(KLOC, "$ETC/itkasm-location${locnum}.dat" ) || print "CANNOT OPEN LOCATION: $ETC/itkasm-location${locnum}.dat";
  while (<KLOC>)
  {
    chomp;
    print "<option value=\"$_\" >$_</option>\n"; 
  }
  close(KLOC);
}

#
# GET RADIO KAVES FOR IT KASM PAGES
#
sub get_radio_kaves
{
  # COLLECT ALL THE KAVES USED SO FAR
  @KID=();
  opendir(KDIR, "$KPGDIR/$form{pageid}") || die "CANT OPEN DIRECTORY: $KAVESn";
  while ( $_ = readdir(KDIR))
  {
    if ( ! m/^\./ && /\.dat/ )
    {  
	$KF="$_";
	open(KLOC, "$KPGDIR/$form{pageid}/$KF" ) || print "CANT OPEN KLOC FILE: $KPGDIR/$form{pageid}/$KF";
	while(<KLOC>) 
        {
   	  chomp;
          ($n, $klkaveID)=split (/\t/, $_);
    	  push(@KID, $klkaveID); 
	}
	close(KLOC);
     }
  }
  close(KDIR);
  opendir(DIR, "$KAVES") || die "CANT OPEN DIRECTORY: $KAVESn";
  while ( $_ = readdir(DIR))
  {
    chomp;
    $kfile="$_";
    if ( ! m/^\./ )
    {
      ($kid, $pro)=split(/\./, $kfile);
      open(KAVES, "$KAVES/$kfile") || print "CANNOT OPEN $KAVES/$kfile";
      while(<KAVES>)
      {
        chomp;
        if ( /^kavename\t/ ) { ($d1, $kavename) = split(/\t/, $_); }
        if ( /^kavedesc\t/ ) { ($d1, $kavedesc) = split(/\t/, $_); }
        if ( /^ktype\t/ ) { ($d1, $kavetype) = split(/\t/, $_); }
      }
      close(KAVES);
        $push="$kavetype\t$kavename\t$kavedesc\t$kid";
        if ( "$push" =~ /SETTINGS/ && $GOD ) { push(@KLST, $push); }
        if ( "$push" !~ /SETTINGS/ ) { push(@KLST, $push); }
    }
  }
  close(DIR);
  print "<table with=100% cellpadding=5 border=0>";
  @KLST = sort @KLST;
  $oldktype="";
  foreach (@KLST)
  {
    ($kavetype, $kavename, $kavedesc, $kid) = split (/\t/, $_);
    if ( "$oldktype" ne "$kavetype" ) 
    {
	$oldktype="$kavetype";
  	$selktype= ucfirst "$kavetype";
	print "<tr><td colspan=3><font $fsb><p><b><u>$selktype Kaves:</u></b></font></td></tr>\n";
    }
    $found=""; $color="";
    foreach $i (@KID) { if ( "$kid" eq "$i" ) { $found="1"; } }
    if ($found ) { $color="color=gray"; $input=""; }
    else { $input="<input type=\"radio\" name=\"kave\" value=\"$kid\" >"; }
    print qq~
	<tr>
    	  <td valign=top>$input</td><td valign=top><font $fsn $color>$kavename</font></td>
          <td align=left valign=top><font $fsn $color>$kavedesc</font></td>
	</tr>
    ~;
  }
  print "</table>";
}

###
### PROCESS SETTINGS IT KASM PAGE LAYOUT FROM TEMPLATE
###
sub proc_settings_lay
{
     open(LAY, "$WEBFILE" ) || print "CANNOT OPEN $WEBFILE";
     while(<LAY>)
     {
       chomp;
       if ( /%%%/ ) 
       {
	 ($d, $getwhat) = split(/:/, $_);
         if ( "$getwhat" eq "hr_line" ) { print "$hr_line\n"; }
	 elsif ( /%%%DISPLAY:LOGO/ ) { print "LOGO"; }
         elsif ( /%%%TABS:/ && $form{act} ne "listpages" && $form{act} ne "ckpage") { &display_itkasmtabs; }
         elsif ( /%%%TABS:/ ) { print ""; }
         elsif ( /%%%SETTING:/ )
         {
  	   print "$getwhat";
         }
	 # IF A LOCATION FILE HAS CONTENT, PROCESS IT , OTHERWISE SHOW EMPTY
  	 elsif ( -s "$KPGDIR/$form{pageid}/${getwhat}.dat" ) 
	 { 
           $loccnt=0;
	   print "<table border=0>";
	   open(LOC, "$KPGDIR/$form{pageid}/${getwhat}.dat") || print "CANNOT OPEN GETWHAT $KPGDIR/$form{pageid}/${getwhat}.dat";
	   while(<LOC>) 
	   { 
	     $loccnt++;
	     ($kavename,$kaveid)=split(/\t/, $_); 
             if ( $form{act} eq "listpages" ) 
  	     {
	     print qq~
               <tr><td valign=top nowrap><font $fsn>$kavename</font></td>
	       </tr>
	     ~;
 	     }
       	     else 
	     {
	       print qq~
                 <tr><td nowrap><a href=$ITKASM?act=ckpage&pageid=$form{pageid}&kloc=$getwhat&sact=move&num=$loccnt style=\"color:$lnkcolor\"><font $fsnl>$kavename</a></font></td>
	         <td nowrap>&nbsp; &nbsp; <a href=$ITKASM?act=ckpage&pageid=$form{pageid}&kloc=$getwhat&sact=delp&num=$loccnt height=15>
	         <img src=$IMAGES/x1.png height=13 border=0></td>
	         </tr>
 	       ~;
	     }
  	   }
           close(LOC);
           print "</table>";
	 }
	 else { print "<center>EMPTY</center>"; }
       }
       else { print "$_\n"; }
     }
     close(LAY) ;
}



###
### CREATE A IT KASM PAGE
###
sub create_kpage
{
#print "$buffer<p>";
  $pageid="";
  #
  # If a sub action is passed get Title and Desc
  #
  if ( ! $form{kpgname} && -s "$KPGDIR/$form{pageid}/$form{pageid}.pro" ) 
  {
    open (PRO, "$KPGDIR/$form{pageid}/$form{pageid}.pro" )  || print "Profile $KPGDIR/$form{pageid}/$form{pageid}.pro does not exist";
    while (<PRO>)
    { 
      chomp;
      if ( /^name\t/ ) { ($d, $form{kpgname}) = split(/\t/, $_); }
      if ( /^desc\t/ ) { ($d, $form{kpgdesc}) = split(/\t/, $_); }
      if ( /^layout\t/ ) { ($d, $form{lay}) = split(/\t/, $_); }
      if ( /^active\t/ ) { ($d, $form{kactive}) = split(/\t/, $_); }
      if ( /^visitor\t/ ) { ($d, $form{vis}) = split(/\t/, $_); }
    }
    if ( ! $form{vis} ) { $form{vis}=0; }
    close(PRO);
    #
    # IF DELETE IS SELECTED
    if ( $form{sact} eq "delp" ) { $FILE="$KPGDIR/$form{pageid}/$form{kloc}.dat"; delete_task_gta; }
  }
  if ( ! "$form{pageid}" && "$form{kpgname}" )
  {
    $valid="";
    while ( ! $valid  )
    {
      my $random_string=&get_token(6);
      &get_token;
      $number="$random_string";
      if ( ! -d "$KPGDIR/${number}" ) { $valid="1"; }
    }
      $pageid = "$number";

      #
      # Write to itkasm page index file
      #
      #open(KPG, ">> $ITKASMPAGE" ) || print "CANNOT WRITE $ITKASMPAGE";
      #print KPG "$form{kpgname}\t$pageid\n";
      #close(KPG);
      $form{pageid} = "$pageid";

  }
  if ( "$form{pageid}" && "$form{kpgname}" )
  {
      if ( ! -d "$KPGDIR/$form{pageid}" )
      { `mkdir -p "$KPGDIR/$form{pageid}"`; }
      open(KPG, "> $KPGDIR/$form{pageid}/$form{pageid}.pro" ) || print "CANNOT WRITE $KPGDIR/$pageid";
      print KPG "name\t$form{kpgname}\n";
      print KPG "desc\t$form{kpgdesc}\n";
      print KPG "id\t$form{pageid}\n";
      print KPG "layout\t$form{lay}\n";
      print KPG "active\t$form{kactive}\n";
      print KPG "visitor\t$form{vis}\n";
      close(KPG);
      ### WRITE TO ITKASMPAGE FILE IF IT ISN'T THERE FOR SOME REASON
 	$found="";
        open(KMP, "$ITKASMPAGE") || print "CANNOT OPEN ITKASMPAGE: $ITKASMPAGE";
	while (<KMP>) { if ( /$form{pageid}\t/) { $found="1"; } }
  	close(KMP);
        if ( ! "$found" ) 
        {
      	  open(KMP, ">> $ITKASMPAGE" ) || print "CANNOT WRITE ITKASMPAGE: $ITKASMPAGE";
 	  print KMP "$form{kpgname}\t$form{pageid}\t$form{lay}\t$form{kactive}\t$form{vis}\n";
	  close(KMP);
	}
      # UPDATE THE ITKASMPAGE IN ETC
      @LST=(); @NEWLST=();
      tie @LST, 'Tie::File', "$ITKASMPAGE" or die;
      foreach (@LST)
      {
        if ( /$form{pageid}/ )  { $new="$form{kpgname}\t$form{pageid}\t$form{lay}\t$form{kactive}\t$form{vis}\n"; push@NEWLST, "$new"; }
        else {  push@NEWLST, "$_"; }
      }
      @LST = sort @NEWLST;
      untie(@LST);
      #
      # IF ACTIVE, ADD TO ITKASMPAGE-TABS FILE
      #
      if ( $form{kactive} == 1 )
      {
 	$found="";
        open(KPGT, "$ETC/itkasmpage-tabs.dat") || print "CANNOT OPEN TABS FILE TO GET ACTIVES: $ETC/itkasmpage-tabs.dat";
	while (<KPGT>) 
	{ 
	  if ( /$form{pageid}/) { $found="form{pageid}"; ($cname,$cid)=split(/\t/, "$_");  } 
	}
  	close(KPGT);
        if ( ! "$found" ) 
        {
      	  open(KPGT, ">> $ETC/itkasmpage-tabs.dat" ) || print "CANNOT WRITE ACTIVE TO TABS FILE: $ETC/itkasmpage-tabs.dat";
 	  print KPGT "$form{kpgname}\t$form{pageid}\t0\n";
	  close(KPGT);
	}
        else
	{
           # CHECK THERE WAS A NAME CHANGE IN TABS FILE
	   if ( "$form{kpgname}" ne "$cname" )
	   { 
		@LST=(); @NEWLST=();
      		tie @LST, 'Tie::File', "$ETC/itkasmpage-tabs.dat" or die;
      		foreach (@LST) 
	 	{ 
		  if ( /$form{pageid}/ ) 
 	  	  {  
		    chomp;
		    ($d,$cpid,$cdef,)=split(/\t/, "$_");
		    $NEWLINE="$form{kpgname}\t$cpid\t$cdef\n";
		    push@NEWLST, "$NEWLINE";  
		  }
		  else { push@NEWLST, "$_";}
		}
        	  @LST=@NEWLST;
        	  untie(@LST);
	   }
        }
      }
      else 
      {
        #
        # MAKE SURE NOT IN ITKASMPAGE-TABS IF DISABLED
        #
	@LST=(); @NEWLST=();
      	tie @LST, 'Tie::File', "$ETC/itkasmpage-tabs.dat" or die;
      	foreach (@LST) { if ( ! /$form{pageid}/) {  push@NEWLST, "$_"; } }
        @LST=@NEWLST;
        untie(@LST);
      }
  }
  
  if ( $form{kloc} && ! $form{sact} ) 
  {
    if ( $form{kloc} =~ "Header" && -s "$KPGDIR/$form{pageid}/$form{kloc}.dat" ) { $ERROR1="$form{kloc} occupied: Only one Kave can be in a Header location"; }
    elsif ( ! $form{kave} ) {  $ERROR2="A Kave must be selected"; }
    else 
    {
      open(KAV, "$KAVES/$form{kave}.pro" ) ||print "CANNOT FIND KAVE $KAVES/$form{kave}/$form{kave}.pro";
      while(<KAV>) 
      { chomp; if ( /^kavename\t/ ) { ($d1,$kavename)=split(/\t/,$_); } }
      close(KAV);
      open(LAY, ">> $KPGDIR/$form{pageid}/$form{kloc}.dat" ) || print "CANNOT WRITE LOC  $KPGDIR/$form{pageid}/$form{kloc}.dat";
      print LAY "$kavename\t$form{kave}\n";
      close(LAY);
    }
  }

  #
  # CHECK IF THERE IS MOVE IS SELECTED
  #
  if ( $form{sact} eq "move" && $form{num} )
  {
    @LST=(); @NEWLST=();
    tie @LST, 'Tie::File', "$KPGDIR/$form{pageid}/$form{kloc}.dat" or die;
    $COUNT=0; $found="";
    $len = scalar @LST;
    foreach (@LST)
    {
      $COUNT++;
      if ( ! $moved )
      {
        if ( $len == $form{num} )
        {
           $found="$LST[$len-1]"; $moved="1";
            push@NEWLST, "$LST[$len-1]";  $found="";
        }
      }
      if ( $COUNT == $form{num} )  { $found="$_";  }
      else
      {
            if ( "$found" ) { push@NEWLST, "$_";  push@NEWLST, "$found"; $found=""; }
            else {  push@NEWLST, "$_"; $found=""; }
      }
    }
    @LST=@NEWLST;
    untie(@LST);
  }

  #
  # DISPLAY CREATE ITKASM PAGE
  #
  if ( $form{pageid} )
  {
        $HiddenID="<input type=hidden name=pageid value=\"$form{pageid}\">";
        $LayoutID="<input type=hidden name=lay value=\"$form{lay}\">";
	$CRTUPD="Update";
	$CRTLINK="<font $fsbl> | <a href=$ITKASM?act=ckpage title=\"Create a Page\" class=\"hoverlink\" style=\"color:$lnkcolor\">Create Page</a></font>";

  }
  else { $CRTUPD="Create"; $CRTLINK="";}
  if ( $form{kactive} == 0 ) { $selectN="checked"; $selectY=""; }
  else { $selectN=""; $selectY="checked"; }
  print qq~
      $hr_line
      <table width=100% bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
      <font $fsbl>
      <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" class=\"hoverlink\" style=\"color:$lnkcolor\">Settings</a> |
      <a href=$ITKASM?act=listpages title="List All Pages" class=\"hoverlink\" style=\"color:$lnkcolor\">List Pages</a>
      $CRTLINK
 | 
      <b>$CRTUPD Page</b> 
   ~;
  if ( $form{kpgname} ) { print " | <a href=$ITKASM?wp=$form{pageid} class=\"hoverlink\" title=\"Go to $form{kpgname} Page\" style=\"color:$lnkcolor\" >$form{kpgname} Page</a>\n"; }
  print qq~
      </font>
      </td><td align=right width=15%><font $fsbl>
        <a href=$ITKASM?act=listkaves title="List available Kaves" class=\"hoverlink\" style=\"color:$lnkcolor\">List Kaves</a> </font>
      </td>
      </table>
      $hr_line
      <p>
<table width=100% border=0>
<td valign=top alight=left>
      <form method=post action=$ITKASM>
        <input type=hidden name=act value=ckpage>
        $HiddenID
        $LayoutID
        <input type=hidden name=vis value=$form{vis}>
      <table border=0>
        <tr>
          <td align=right valign=top><font $fsn><b>Page Title: </b></font></td>
	  <td valign=top><input type=text size=20 name="kpgname" value="$form{kpgname}" required><p></td>
	</tr>
	<tr>
	  <td align=right valign=top><font $fsn><b>Page Description: </b></font></td>
	  <td valign=top><input type=text size=40 name="kpgdesc" value="$form{kpgdesc}"><p></td>
	</tr>
	<tr>
	  <td align=right valign=top><font $fsn><b>Page ID: </b></font></td>
	  <td valign=top>$form{pageid}<p></td>
	</tr>
	<tr>
	  <td align=right valign=top><font $fsn><b>Active:</b></font></td>
	  <td valign=top>
		<input type="radio" name="kactive" value="1" $selectY><font $fsn>Yes</font>
		<input type="radio" name="kactive" value="0" $selectN><font $fsn>No</font>
 	  </td>
  	</tr>
       </table>
       </td>
         <td align=right valign=top>
  ~;
  #
  # DELETE - CHECK THAT NO KAVES ARE DEFINE IN THE PAGE
  #
  if ( $form{pageid} || $pageid ) 
  {
     $found=""; 
     opendir(PGD, "$KPGDIR/$form{pageid}") || die "CANT OPEN PAGEID DIRECTORY: $KPGDIR/$form{pageid}";
     while ( $_ = readdir(PGD))
     {
        if ( ! m/^\./ && /\.dat/ )
        {  
#print "$form{pageid} - $KPGDIR/$form{pageid} / $_<br>";
           if ( -s "$KPGDIR/$form{pageid}/$_" ) { $found="1"; }
        }
     }
     close(PGD);
     ###
     ### MAKE SURE A SETTING PAGE CANNOT BE DELETED
     ###
     if ( "$form{kpgname}" =~ "SETTINGS" ) { }
     else 
     { 
       if ( $found ) { print "<img src=$IMAGES/trashcan-x.png height=20 title=\"To delete '$form{kpgname}', remove all KAVES.\">\n"; }
       else 
       { 
         print "<a href=\"$ITKASM?act=delpage&pageid=$form{pageid}\" class=\"hoverlink\" style=\"color:$lnkcolor\" ><img src=$IMAGES/trashcan.png border=0 height=20 title=\"All Kaves have been removed, '$form{kpgname}' can be deleted\">\n";
       }
     }

  }
print "</td> </table>";
   if ( ! "$form{lay}" ) 
   {
     print qq~
	<font $fsn><b>Select a Layout:</b></font>
        <table border=0 cellpadding=15 cellspacing=1>
	<tr>
	<tr>
	  <td align=center valign=top><input type="radio" name="lay" value="1" checked>
	  1<br><img src="$IMAGES/lay1.jpg"><br><font $fsn>4 Vertical</font></td>
	  <td align=center valign=top><input type="radio" name="lay" value="2" >
	  2<br><img src="$IMAGES/lay2.jpg"><br><font $fsn>3 Vertical, 1 Single,<br>1 Long Verticle</font></td>
	  <td align=center valign=top><input type="radio" name="lay" value="3" >
	  3<br><img src="$IMAGES/lay3.jpg"><br><font $fsn>3 Vertical, Single,<br>3 Verticle</font></td>
	  <td align=center valign=top><input type="radio" name="lay" value="4" >
	  4<br><img src="$IMAGES/lay4.jpg"><br><font $fsn>4 Vertical, <br>5 Horiz Resources,<br> 1 Single</td>
  	</tr>
        </table>
     ~;
   }
   # GET KAVES TO INSERT
   if ( $form{pageid}) {$val="Update"; }
   else {$val="Continue";}
   if ( $form{lay} )
   {
     print qq~
        <br>
	<font $fsb>Select a Location and Kave to use:</font>
	<!-- Select KAVES and Location for layout -->
        <table width=100% border=0>
	<td valign=top nowrap>
          <font $fserr>$ERROR1</font><br>
	  <font $fsn><b>Select Location :</b></font>
          <select name="kloc">
	  <option value="">
     ~;
     $locnum=$form{lay}; get_select_kloc;
     print "</select>";
     print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n";
     print "<input type=submit name=ksave value=\"$val\"><p>\n";
     print "<font $fserr>$ERROR2</font><br>\n";
     get_radio_kaves;
     print "</td><td valign=top>";
   }
   # PROCESS/DISPLAY THE LAYOUT FILES BEING USED
   if ( $form{lay} ) 
   { 
    $WEBFILE="$ETC/itkasm-header.dat"; proc_settings_lay;
    $WEBFILE="$ETC/itkasm-layout$form{lay}.dat"; proc_settings_lay;
   }

   print qq~
         $hr_line
    	 <Input type=submit name=ksave value="$val">
         </form>
    ~;
  
}


###
### LIST ALL PAGES CREATED
###
sub list_page
{

#print "$buffer";
    print qq~
        $hr_line
        <table width=100% bgcolor=$hdrcolor cellpadding=3><td valign=top align=left>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" class=\"hoverlink\" style=\"color:$lnkcolor\">Settings</a> |
	<b>List Pages</b> | 
        <a href=$ITKASM?act=ckpage title="Create a Page" class=\"hoverlink\" style=\"color:$lnkcolor\">Create Page</a>
	</font>
	</td></table>
        $hr_line
    ~;

    #
    # UPDATE ACTIVE STATE CHANGES IN ITKASMPAGE FILE 
    #
    if ( $form{sact} eq "chgact" || $form{sact} eq "chgvis") 
    { 
      @LST=(); @NEWLST=();
      tie @LST, 'Tie::File', "$ITKASMPAGE" or die;
      foreach (@LST)
      {
        if ( /$form{pageid}/ )  
	{ 
	  ($form{kpgname},$kpid,$form{lay},$act1,$vis1) = split (/\t/, $_);
          $form{kactive}=$act1;
          $form{kvis}=$vis1;

          if ( $form{sact} eq "chgact") 
	  { 
		if ( $act1 == 0 ) { $form{kactive}=1; } 
	  	else { $form{kactive}=0; }
	  } 
          if ( $form{sact} eq "chgvis") 
	  { 
            	if ( $vis1 == 0 ) { $form{kvis}=1; }
	  	else { $form{kvis}=0; }
	  }
	  $newline="$form{kpgname}\t$form{pageid}\t$form{lay}\t$form{kactive}\t$form{kvis}";
	  push@NEWLST, "$newline";
        }
        else {  push@NEWLST, "$_"; }
      }
      @LST = sort @NEWLST;
      untie(@LST);

      #
      # ADD TO THE END OF THE TABS or VISITOR FILE
      #
     
      if ( $form{sact} eq "chgact") 
      { 
      	if ( $form{kactive} == 1 )
      	{
      	  open(KPGT, ">> $ETC/itkasmpage-tabs.dat" ) || print "CANNOT WRITE TO THE END OF THE TABS FILE: $ETC/itkasmpage-tabs.dat";
 	  print KPGT "$form{kpgname}\t$form{pageid}\t$form{lay}\t$form{vis}\n";
	  close(KPGT);
      	}
      	else 
      	{
          #
          # MAKE SURE NOT IN ITKASMPAGE-TABS IF DISABLED
          #
	  @LST=(); @NEWLST=();
      	  tie @LST, 'Tie::File', "$ETC/itkasmpage-tabs.dat" or die;
      	  foreach (@LST) { if ( ! /$form{pageid}/) {  push@NEWLST, "$_"; } }
          @LST=@NEWLST;
          untie(@LST);
      	}
      }
      if ( $form{sact} eq "chgvis") 
      { 
      	if ( $form{kvis} == 1 )
      	{
      	  open(KPGT, ">> $ETC/itkasmpage-visitor.dat" ) || print "CANNOT WRITE TO THE END OF VISITORS TABS FILE: $ETC/itkasmpage-visitor.dat";
 	  print KPGT "$form{kpgname}\t$form{pageid}\t$form{lay}\n";
	  close(KPGT);
      	}
      	else 
      	{
          #
          # MAKE SURE NOT IN ITKASMPAGE-VISITOR IF DISABLED
          #
	  @LST=(); @NEWLST=();
      	  tie @LST, 'Tie::File', "$ETC/itkasmpage-visitor.dat" or die;
      	  foreach (@LST) { if ( ! /$form{pageid}/) {  push@NEWLST, "$_"; } }
          @LST=@NEWLST;
          untie(@LST);
        }
      }


      #
      # CHANGE IN THE ITKASM PAGE .PROFILE  
      #
      @LST=(); @NEWLST=();
      tie @LST, 'Tie::File', "$KPGDIR/$form{pageid}/$form{pageid}.pro" or die;
      foreach (@LST) 
      {
      	if ( $form{sact} eq "chgact") 
      	{			 
          if ( /^active\t/ )  
          { 
	    ($d1,$kactive) = split (/\t/, $_);
	    $newline="active\t$form{kactive}\n";
	    push@NEWLST, "$newline";
          }
          else {  push@NEWLST, "$_"; }
        }
      	if ( $form{sact} eq "chgvis") 
      	{			 
          if ( /^visitor\t/ )
          {
	    ($d1,$kvis) = split (/\t/, $_);
	    $newline="visitor\t$form{kvis}\n";
	    push@NEWLST, "$newline";
          }
          else {  push@NEWLST, "$_"; }
	}
      }
      @LST=@NEWLST;
      untie(@LST);

      print "<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0;URL=$ITKASM?act=listpages\">";
      $META="1";
    } # END MAIN IF


    #
    # CHANGE VISITOR PAGE FROM SETTINGS LIST
    #
    if ( ! -f "$ITKASMPAGE" ) { `touch $ITKASMPAGE`; }
    else { $foundrec="1"; }

    # GET A LIST OF ALL ITKASM PAGES
      $found="";
      @LST=();
      open(KPG, "$ITKASMPAGE" ) || print "CANNOT OPEN ITKASMPAGE $ITKASMPAGE";
      while (<KPG>) { push (@LST, $_); }
      close(KPG);
   


    #
    # IF ITKASMPAGE-TABS NOT EXIST, CREATE IT 
    #
    if ( ! -s "$ETC/itkasmpage-tabs.dat" ) 
    {
      open(KPGT, ">> $ETC/itkasmpage-tabs.dat" ) || print "CANNOT CREATE TABS FILE: $ETC/itkasmpage-tabs.dat";
      foreach (@LST)
      {
        chomp;
        ($ttitle, $tid, $form{lay}, $form{kactive},$form{vis})=split(/\t/, $_);
        if ( $form{kactive} == 1 ) 
        { 
          print KPGT "$ttitle\t$tid\n"; 
        }
      }
      close(KPGT);
    }

    #
    # IF ITKASMPAGE-VISITOR NOT EXIST, CREATE IT 
    #
    if ( ! -s "$ETC/itkasmpage-visitor.dat" ) 
    {
      open(KPGT, ">> $ETC/itkasmpage-visitor.dat" ) || print "CANNOT CREATE VISITOR TABS FILE: $ETC/itkasmpage-visitor.dat";
      foreach (@LST)
      {
        chomp;
        ($ttitle, $tid, $form{lay}, $kactive, $form{kvis})=split(/\t/, $_);
        if ( $form{kvis} == 1 ) 
        { 
          print KPGT "$ttitle\t$tid\n"; 
        }
      }
      close(KPGT);
    }

    #
    # GET LIST OF ACTIVE IN TAB
    #
    @ALST=();
    open(KPG, "$ETC/itkasmpage-tabs.dat" ) || print "CANNOT OPEN TABS FILE: $ETC/itkasmpage-tabs.dat";
    while (<KPG>) { push (@ALST, $_);   }
    close(KPG); 

    #
    # MOVE ACTIVE HORIZONTALLY IF SELECTED
    #
    if ( $form{mid} eq "act" && $form{sact} eq "move" && $form{num} )
    {
      @ALST=(); @NEWLST=();
      tie @ALST, 'Tie::File', "$ETC/itkasmpage-tabs.dat" or die;
      $COUNT=0; $found="";
      $len = scalar @ALST;
      foreach (@ALST)
      {
        $COUNT++;
        if ( ! $moved )
        {
          if ( $len == $form{num} )
          {
             $found="$ALST[$len-1]"; $moved="1";
              push@NEWLST, "$ALST[$len-1]";  $found="";
          }
        }
        if ( $COUNT == $form{num} )  { $found="$_";  }
        else
        {
            if ( "$found" ) { push@NEWLST, "$_";  push@NEWLST, "$found"; $found=""; }
            else {  push@NEWLST, "$_"; $found=""; }
        }
      }
      @ALST=@NEWLST;
      untie(@ALST);
      # Fill again, the untie clears the array
      @ALST=@NEWLST;
      print "<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0;URL=$ITKASM?act=listpages\">";
      $META="1";
    }

    #
    # GET LIST OF VISITORS IN TAB
    #
    @VLST=();
    open(KPG, "$ETC/itkasmpage-visitor.dat" ) || print "CANNOT OPEN VISITOR TABS FILE: $ETC/itkasmpage-visitor.dat";
    while (<KPG>) { push (@VLST, $_);   }
    close(KPG); 

    #
    # MOVE ACTIVE HORIZONTALLY IF SELECTED
    #
    if ( $form{mid} eq "vis" && $form{sact} eq "move" && $form{num} )
    {
      @VLST=(); @NEWLST=();
      tie @VLST, 'Tie::File', "$ETC/itkasmpage-visitor.dat" or die;
      $COUNT=0; $found="";
      $len = scalar @VLST;
      foreach (@VLST)
      {
        $COUNT++;
        if ( ! $moved )
        {
          if ( $len == $form{num} )
          {
             $found="$VLST[$len-1]"; $moved="1";
              push@NEWLST, "$VLST[$len-1]";  $found="";
          }
        }
        if ( $COUNT == $form{num} )  { $found="$_";  }
        else
        {
            if ( "$found" ) { push@NEWLST, "$_";  push@NEWLST, "$found"; $found=""; }
            else {  push@NEWLST, "$_"; $found=""; }
        }
      }
      @VLST=@NEWLST;
      untie(@VLST);
      # Fill again, the untie clears the array
      @VLST=@NEWLST;
      print "<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0;URL=$ITKASM?act=listpages\">";
      $META="1";
    }



    #
    # DISPLAY ACTIVE ITKASM PAGE POSITIONS HORIZONTALLY
    #
    $pagecount=0;
    print qq~
	<font $fsb>Active Authenticated User Tabs:</font><br>
	<table cellpadding=5 cellspacing=5 border=0 >
    ~;
    foreach (@ALST)
    {
      chomp;
      $pagecount++;
      ($ttitle, $tid, $lay)=split(/\t/, $_);
      $ktitle="<font $fsnl>$ttitle</font>"; 
      print "<td style=\"border: 1px solid #000000; border-collapse: collapse;\"><a href=$ITKASM?act=listpages&pageid=$tid&mid=act&sact=move&num=$pagecount class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"Move \'$ttitle\' to the right one tab\">$ktitle</a></font></td>\n";
    }
    print "</table>&nbsp;<p>\n";

    #
    # DISPLAY VISITOR ITKASM PAGE POSITIONS HORIZONTALLY
    #
    $pagecount=0;
    print qq~
        <font $fsb>Visitor Unauthenticated Tabs:</font><br>
        <table cellpadding=5 cellspacing=5 border=0 >
    ~;
    foreach (@VLST)
    {
      chomp;
      $pagecount++;
      ($ttitle, $tid, $lay)=split(/\t/, $_);
      $ktitle="<font $fsnl>$ttitle</font>"; 
      print "<td style=\"border: 1px solid #000000; border-collapse: collapse;\"><a href=$ITKASM?act=listpages&pageid=$tid&mid=vis&sact=move&num=$pagecount class=\"hoverlink\" style=\"color:$lnkcolor\" title=\"Move \'$ttitle\' to the right one tab\">$ktitle</a></font></td>\n";
    }
    print "</table>&nbsp;<p>\n";

    #
    # DISPLAY THE PAGE PROFILES
    #
    if ( $foundrec ) 
    {
    print qq~

	<!--- Table For PAGE PROFILES--->
        <table border=0 width=100%>
        <td valign=top width=35%>
          <table border=0 cellspacing=5 cellpadding=0 width=100%>
          <tr>
	    <td align=center><b><font $fsb>Edit<br><hr size=1></font></b></td>
            <td align=center><b><font $fsb>Profiles<br><hr size=1></font></b></td>
            <td align=center><b><font $fsb>Active<br><hr size=1></font></b></td>
	    <td align=center><b><font $fsb>Visitor<br><hr size=1></font></b></td>
	  </tr>
    ~;
    }
    #
    # Read the ITKASMPAGE.dat file and get the titles, id's, active, visitor
    #
    @reserved=();
    open(KPG, "$ITKASMPAGE" ) || print "CANNOT OPEN ITKASMPAGE $ITKASMPAGE";
    while (<KPG>)
    {
      chomp;
      ($ttitle, $tid, $form{lay}, $form{kactive}, $form{vis})=split(/\t/, $_);
      if ( ! index($tid, "SETTINGS" )  )
      { 
	push(@reserved,$_);
      }
      else
      {
	 if ( $form{vis} == 1 ) 
	 { $vis="<img src=\"$IMAGES/box-checked.jpg\">"; }
	 else { $vis="<img src=\"$IMAGES/box-unchecked.jpg\">"; }

	 if ( $form{kactive} == 1 ) { $active="<img src=\"$IMAGES/box-checked.jpg\">"; }
	 else { $active="<img src=\"$IMAGES/box-unchecked.jpg\">"; }

      if ( $tid eq $form{tid} ) { $fline="<font $fsn><b>$ttitle</b>"; $clTITLE="$ttitle"; @vKPGPRO=@KPGPRO; }
      else { $fline="<font $fsnl><a href=$ITKASM?act=listpages&tid=$tid class=\"hoverlink\" style=\"color:$lnkcolor\">$ttitle</a>"; }
      print qq~
          <tr>
	  <td valign=top align=center>
          <a href=$ITKASM?act=ckpage&pageid=$tid title="Edit \'$ttitle\' Profile"><img src=$IMAGES/edit.png height=12 border=0></a> 
          &nbsp;&nbsp;<a href=$ITKASM?wp=$tid title="Go to \'$ttitle\' IT KASM Page"><img src=$IMAGES/redirect.png height=12 border=0></a>
	  </td> 
          <td>$fline</font></td>
          <td align=center><a href=$ITKASM?act=listpages&pageid=$tid&sact=chgact style=\"color:$lnkcolor\">$active</a></td>
          <td align=center><a href=$ITKASM?act=listpages&pageid=$tid&sact=chgvis style=\"color:$lnkcolor\">$vis</a></td>
	  </tr>
      ~;
     }
    }
    close(PKG);
      print "<p>";
    if ( $GOD ) 
    {
      print "</table>\n";
	print "<table><p>";
        print "<tr><td><font $fsn><b><u>Reserved</u></b></font></td></tr>\n";
	foreach $res (@reserved)
	{
          ($ttitle, $tid)=split(/\t/, $res);
          if ( $tid eq $form{tid} ) { $fline="<b>$ttitle</b>"; $clTITLE="$ttitle"; @vKPGPRO=@KPGPRO; }
          else { $fline="<a href=$ITKASM?act=listpages&tid=$tid class=\"hoverlink\" style=\"color:$lnkcolor\">$ttitle</a>"; }
  	  print qq~
	    <tr>
            <td valign=top align=center>
            <a href=$ITKASM?act=ckpage&pageid=$tid><img src=$IMAGES/edit.png height=12 border=0></a>
            &nbsp;&nbsp;<a href=$ITKASM?wp=$tid><img src=$IMAGES/redirect.png height=12 border=0></a>
            </td>
            <td><font $fsn>$fline</font></td>
            </tr>
	  ~;
	}
    }
    print qq~
      </table>
      <td valign=top >
    ~;
    #
    # Display the contents if selected
    #
    if ( $form{tid} ) 
    { 
	$form{pageid}="$form{tid}"; 
    	$WEBFILE="$ETC/itkasm-header.dat"; proc_settings_lay;
	$WEBFILE="$ETC/itkasm-layout$form{lay}.dat"; proc_settings_lay; 
    } 
    print qq~
          </td>
	</tr>
	</table>
      </td></table>
    ~;
}


###
### CREATE GROUP
###
sub display_groups
{
#print "$buffer";
  if ( ! -d "$GRPDIR" ) { `mkdir -p $GRPDIR`; }
  if ( $form{fini} ) { `rm -f $GRPDIR/$form{grp}`; }
  @grplist=();
  #
  # Collect the list of groups
  #
  opendir(GRP, "$GRPDIR") or die $!;
  while ($grpfile = readdir(GRP))
  { next if ($grpfile =~ m/^\./); push(@grplist, $grpfile)  }
  closedir(DIR);
  print qq~
        $hr_line
 	<table width=100% bgcolor=$hdrcolor cellpadding=3>
	<td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
	 | <b> Groups</b>
         | <a href=$ITKASM?act=settings&sact=users&hd=Users title="Go To Settings" style=\"color:$lnkcolor\">Users</a>
        </font>
	</td></table>
        $hr_line
  ~;
  if ( ! @grplist ) { print "<font $fserr><i>No Groups have been defined</font><p>"; }
  print qq~
    <form method=post action=$ITKASM>
    <input type=hidden name=act value=groups>
    <table border=0>
    <td valign=top>
    <table border=0>
    <tr>
      <td valign=top><font $fsb>
        Create a group: <input type=text name=gname size=15 pattern="[^' ']+" title="ALPHA-NUMERIC ONLY, NO SPACES ALLOWED">
        </font></form>
     </td valign=top>
    </tr>
   <tr><td>
  ~;
  if ( $form{gname} )
  {
    if ( ! -f "$GRPDIR/$form{gname}" ) { `touch $GRPDIR/$form{gname}`; }
  }
  #
  # DISPLAY THE LIST OF GROUPS
  #
  print "$hr_line";
  @grplist=();
  opendir(GRP, "$GRPDIR") or die $!;
  while ($grpfile = readdir(GRP))
  { next if ($grpfile =~ m/^\./); push(@grplist, $grpfile)  }
  closedir(DIR);
  print "<table border=0 width=100%>";
  @grplist = sort @grplist;
  foreach (@grplist)
  {
    if ( $form{grp} ne "$_" ) { $HREF="<a href=$ITKASM?act=groups&grp=$_&adu=1 title=\"Click to View/Edit Users in $_ group\" style=\"color:$lnkcolor\"><font $fsnl>$_</font></a>";}
    else { $HREF="<font $fsn><b>$_</b></font>"; }
    print qq~
      <tr>
        <td valign=top>$HREF</td>
        <td valign=top><a href=$ITKASM?act=groups&grp=$_&del=1 title="Delete $_ group" style=\"color:$lnkcolor\" >
          <img src=$IMAGES/trashcan.png height=15 border=0>
        </td>
      </tr>
    ~;
  }
  print "</td></tr></table>";
  print "</td></table>";
  print qq~
    <td valign=top>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </td>
    <td valign=top>
  ~;
  #
  # CONFIRM REALLY WANT TO DELETE
  #
  if ( $form{del} && ! $form{fini} )
  {
    print qq~
      <center><form method=post action=$ITKASM>
      <input type=hidden name=act value=groups>
      <input type=hidden name=grp value=$form{grp}>
      <p> <font $fsb>
      <b>Are you sure you want to DELETE <p>
        The $form{grp} Group<p></b>
      <input type=radio name="" value="" checked> NO
      &nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;
      <input type=radio name="fini" value="1"> YES
      <p>
      <input type=submit name="submit" value="Confirm">
      </font>
      </form>
    ~;
  }
  if ( $form{adu} )
  {
    #
    # Delete user from a group
    #
    if ( $form{userdel} )
    {
        @LST=(); @NEWLST=();
        tie @LST, 'Tie::File', "$GRPDIR/$form{grp}" or die;
        foreach (@LST)
        {
          if ( ! /^$form{userdel}\t/ ) { push(@NEWLST, "$_"); }
          else { $del_line="$_"; }
        }
        @LST=@NEWLST;
        untie(@LST);
    }
    if ( $form{grpuser} )
    {
      # CHECK IF USER ALREADY EXISTS IN GROUP
      $found="";
      open(IN, "$GRPDIR/$form{grp}") || print "CANNOT READ GROUP $GRPDIR/$form{grp}";
      while(<IN>) { if ( /^$form{grpuser}\t/) { $found="1" }; }
      close(IN);
      if ( ! $found )
      {
        open(OUT, ">> $GRPDIR/$form{grp}") || print "CANNOT WRITE TO GROUP $GRPDIR/$form{grp}";
        print OUT "$form{grpuser}\t\n";
        close(OUT);
      }
    }
    print qq~
      <form method=post action=$ITKASM>
      <input type=hidden name=act value=groups>
      <input type=hidden name=grp value=$form{grp}>
      <input type=hidden name=adu value=$form{adu}>
      <font $fsb>Add Users to <b>$form{grp}</b> Group:</font><br>
      <center>
      <select name='grpuser' onchange='this.form.submit()'>
      <option value=\"\" selected></option>
   ~;
    @users=();
    open(USR, "$USERS") || print "Cannot find $USERS for GROUPS";
    while (<USR>)
    { chomp; ($UUID, $UPWD, $ufname, $ulname) = split (/\t/, $_); push(@users, "$ulname\t$ufname\t$UUID"); }
    close(USR);
    @users = sort @users;
    foreach (@users)
    {
          ($ulname, $ufname, $UUID) = split (/\t/, $_);
          if ( ! /Administrator/i )
          { print "<option value=\"$UUID\" >${ulname}, ${ufname}</option>\n"; }
    }
    print "</select></form>$hr_line</center>";
    #
    # DISPLAY THE GROUP FILE
    #
    @grpusers=();
    open(IN, "$GRPDIR/$form{grp}" ) || print "CANNOT OPEN THE $GRPDIR/$form{grp} TO LIST USERS";
    while(<IN>)
    {
      chomp;
      ($userID) = split(/\t/, $_);
      &convert_user;
      push @grpusers, "$userID\t$ulname, $ufname";
    }
    close(IN);
    print "<table border=0 width=100% >";
    @grpusers = sort @grpusers;
    foreach (@grpusers)
    {
      ($userID, $fname) = split(/\t/, $_);
      print qq~
        <tr><td valign=top><font $fsn>$fname</font></td>
        <td valign=top><a href=$ITKASM?act=groups&grp=$form{grp}&adu=1&userdel=$userID height=15>
          <img src=$IMAGES/trashcan.png height=15 border=0>
        </td>
      </tr>
      ~;
    }
    print "</table>";

  }
  print qq~
  </td>
  </table>
  ~;
  exit;
}



###
### WRITE OUT NEW USER AS ADMIN FROM SETTINGS
###
sub write_newuser
{
  $passwd = encrypt($form{passwd});
  $form{fname}=ucfirst($form{fname});
  $form{lname}=ucfirst($form{lname});
  open(USR, "$USERS") || print "CANNOT FIND THE $USERS file";
  while(<USR>)
  {
    if ( /^$form{lid}\t/) 
    { 
       $ERRORLOG="User $form{lid} already exists."; create_newuser; exit; 
    }
  }
  close(USR);
  if ( ! -d "$USERDIR/$form{lid}" ) { `mkdir -p $USERDIR/$form{lid}`; }
  open(WUSR, "> $USERDIR/$form{lid}/profile") || print "CANNOT WRITE TO $USERDIR/$form{lid}/profile";
  print WUSR "$form{lid}\t$passwd\t$form{fname}\t$form{lname}\t$form{email}\t$form{phone}";
  close(WUSR);
  open(WUSR, ">> $USERS") || print "CANNOT WRITE TO $USERS";
  print WUSR "$form{lid}\t$passwd\t$form{fname}\t$form{lname}\t$form{email}\t$form{phone}\n";
  close(WUSR);
  print qq~
    <META HTTP-EQUIV="Refresh" CONTENT="0;URL=$ITKASM?act=accpro&pro=$form{lid}">
  ~;
  $META="1";
exit;

}



###


###
### WRITE OUT CHANGES TO THE VAR.PM FILE
###
sub write_vars
{
   @LST=(); @NEWLST=();
   tie @LST, 'Tie::File', "${ITKASMDIR}${CGIPATH}/varslocal.pm" or die "CHECK PERMISSIONS/OWNERSHIP ON $ITKASMDIR$CGIPATH/varslocal.pm"; 
   foreach (@LST)
   {
     $NEWVAL="\$${VAR}\=\"${VAL}\"\;";
     if ( /^\$${VAR}=/ ) { push (@NEWLST, "$NEWVAL"); }
     else { push (@NEWLST, "$_");  }
   }
   @LST=@NEWLST;
   untie(@LST);
}

###
### WRITE OUT CHANGES TO THE VAR.PM FILE
###
sub write_default_tmpl
{
   @LST=(); @NEWLST=();
   tie @LST, 'Tie::File', "$KAVETMPL" or die; 
# 	$khtx=$gbxtxt; $kfbg=$gbxframebg; $kbrd=$gbxbord;
#	$kwdt=$gbxwidth; $kbkg1=$gbxbg1; $kbkg2=$gbxbg2;
#	$kbdybrd=0; $khrclr=$gbxhr; $ktxt=$gbxtxt; $klnk=$gbxlnk; 
   $writeconfig="%%%Template.NoID:Default,$gbxframetxt,$gbxframebg,$gbxbord,$gbxwidth,$gbxbg1,$gbxbg2,0,$gbxhr,$gbxtxt,$gbxlnk";
   foreach (@LST)
   {
     if ( /^\%%%Template.NoID:Default/ ) { push (@NEWLST, "$writeconfig"); }
     else { push (@NEWLST, "$_"); }
   }
   @LST=@NEWLST;
   untie(@LST);
}


###
### CONFIGURE SYSTEM CONFIGS
###
sub display_sysconfigs
{
#print "buffer=$buffer";
  #
  # GET TEMPLATE COLORS
  #
  @CLRTMPLT=();
  open(ST, "$ETC/kave-templates.dat") || print "ERROR: Cannot find $ETC/kave-templates.dat";
  while(<ST>)
  {
    chomp;
    if ( /^%%%/ ) { push (@CLRTMPLT, $_); }
  }
  close(ST);
  #
  # IF A GLOBAL TEMPLATE WAS SELECTED
  if ( $form{gtmplt} || $form{ktmplt} )
  {
      foreach (@CLRTMPLT)
      {
        ($skema,$ddd) = split(/\,/, $_);
        ($skema,$seltmplt) = split(/:/, $skema);
        ($dd,$colorconf) = split(/\:/, $_);
	# IF GLOBAL WAS SELECTED
        if ( "$form{gtmplt}" eq "$seltmplt" ) 
        {
#	   Title,BoxText,BxBgnd,BxBrdr,Wdth,BodyBackground1,BodyBackground2,BodyBorder,HRcolor,BdyTxt,LinkText
          ($clrtitle,$d0,$form{hdrcolor},$d1,$d2, $form{bgcolor1},$form{bgcolor2},$d4,$form{hrclr},$form{txtcolor},$form{lnkcolor})=split(/,/, $colorconf);
          $form{update}="update";
        }
	# IF KAVE DEFAULT WAS SELECTED
        if ( "$form{ktmplt}" eq "$seltmplt" ) 
        {
#	   Title,    BoxText,  BxBgnd,   BxBrdr,Wdth,BodyBackground1,BodyBackground2,BodyBorder,HRcolor,BdyTxt,LinkText
          ($clrtitle,$form{gbxframetxt},$form{gbxframebg},$form{gbxbord},$form{gbxwidth},$form{gbxbg1}, $form{gbxbg2},$d1,$form{gbxhr},$form{gbxtxt},$form{gbxlnk})=split(/,/, $colorconf);
          $form{update}="update";
        }
      }
  }
#print "<p>txtcolor=$txtcolor / bgcolor1=$bgcolor1 / bgcolor2=$bgcolor2 / hrclr=$hrclr / lnkcolor=$lnkcolor"; 

  #
  # Write out any changes
  # 
  if ( $form{update} ) 
  { 
  #
  # ITKASM SETTINGS
  #
  if ( "$form{HTTP}" ne "$HTTP" ) {  $VAR="HTTP"; $VAL="$form{HTTP}"; write_vars; $HTTP="$form{HTTP}"; }
  if ( "$form{COMPANY_NAME}" ne "$COMPANY_NAME" ) {  $VAR="COMPANY_NAME"; $VAL="$form{COMPANY_NAME}"; write_vars; $COMPANY_NAME="$form{COMPANY_NAME}"; }
  if ( "$form{COMPANY_DEPT}" ne "$COMPANY_DEPT" ) {  $VAR="COMPANY_DEPT"; $VAL="$form{COMPANY_DEPT}"; write_vars; $COMPANY_DEPT="$form{COMPANY_DEPT}"; }
  if ( "$form{logosz}" ne "$logosz" ) {  $VAR="logosz"; $VAL="$form{logosz}"; write_vars; $logosz="$form{logosz}"; }
  if ( "$form{peoplequery}" ne "$peoplequery" ) {  $VAR="peoplequery"; $VAL="$form{peoplequery}"; write_vars; $peoplequery="$form{peoplequery}"; }
  if ( "$form{mail_prog}" ne "$mail_prog" ) {  $VAR="mail_prog"; $VAL="$form{mail_prog}"; write_vars; $mail_prog="$form{mail_prog}"; }
  if ( "$form{itkasmadmin}" ne "$itkasmadmin" ) {  $VAR="itkasmadmin"; $form{itkasmadmin} =~ s/@/\\@/; $VAL="$form{itkasmadmin}"; write_vars; $itkasmadmin="$form{itkasmadmin}"; }
  if (  $form{acctcreation} )
  {
    if ( $form{acctcreation} eq "yes" && $form{mail_prog} ) { $form{acctcreation}="yes";}
    else { $form{acctcreation}="no"; }
    $VAR="acctcreation"; $VAL="$form{acctcreation}"; write_vars; $acctcreation="$form{acctcreation}"; 
  }
  if ( "$form{itkasmowner}" ne "$itkasmowner" ) {  $VAR="itkasmowner"; $VAL="$form{itkasmowner}"; write_vars; $itkasmowner="$form{itkasmowner}"; }
  if ( "$form{itkasmgroup}" ne "$itkasmgroup" ) {  $VAR="itkasmgroup"; $VAL="$form{itkasmgroup}"; write_vars; $itkasmgroup="$form{itkasmgroup}"; }
  #
  # GLOBAL COLOR SETTINGS
  #
  if ( "$form{fontnorm}" ne "$fontnorm" ) {  $VAR="fontnorm"; $VAL="$form{fontnorm}"; write_vars; $fontnorm="$form{fontnorm}"; }
  if ( "$form{fontbig}" ne "$fontbig" ) {  $VAR="fontbig"; $VAL="$form{fontbig}"; write_vars; $fontbig="$form{fontbig}";}
  if ( "$form{fonthdr}" ne "$fonthdr" ) {  $VAR="fonthdr"; $VAL="$form{fonthdr}"; write_vars; $fonthdr="$form{fonthdr}";}
  if ( "$form{hdrcolor}" ne "$hdrcolor" ) {  $VAR="hdrcolor"; $VAL="$form{hdrcolor}"; write_vars; $hdrcolor="$form{hdrcolor}";}
  if ( "$form{bgcolor1}" ne "$bgcolor1" ) {  $VAR="bgcolor1"; $VAL="$form{bgcolor1}"; write_vars; $bgcolor1="$form{bgcolor1}";}
  if ( "$form{bgcolor2}" ne "$bgcolor2" ) {  $VAR="bgcolor2"; $VAL="$form{bgcolor2}"; write_vars; $bgcolor2="$form{bgcolor2}";}
  if ( "$form{txtcolor}" ne "$txtcolor" ) {  $VAR="txtcolor"; $VAL="$form{txtcolor}"; write_vars; $txtcolor="$form{txtcolor}";}
  if ( "$form{lnkcolor}" ne "$lnkcolor" ) {  $VAR="lnkcolor"; $VAL="$form{lnkcolor}"; write_vars; $lnkcolor="$form{lnkcolor}";}
  if ( "$form{attcolor}" ne "$attcolor" ) {  $VAR="attcolor"; $VAL="$form{attcolor}"; write_vars; $attcolor="$form{attcolor}";}
  if ( "$form{hrclr}" ne "$hrclr" ) {  $VAR="hrclr"; $VAL="$form{hrclr}"; write_vars; $hrclr="$form{hrclr}";}
  if ( "$form{hrsize}" ne "$hrsize" ) {  $VAR="hrsize"; $VAL="$form{hrsize}"; write_vars; $hrsize="$form{hrsize}";}
  #
  # DEFAULT KAVE COLOR SETTINGS
  #
  if ( "$form{gbxframebg}" ne "$gbxframebg" ) {  $VAR="gbxframebg"; $VAL="$form{gbxframebg}"; write_vars; write_default_tmpl; $gbxframebg="$form{gbxframebg}";}
  if ( "$form{gbxframetxt}" ne "$gbxframetxt" ) {  $VAR="gbxframetxt"; $VAL="$form{gbxframetxt}"; write_vars; write_default_tmpl; $gbxframetxt="$form{gbxframetxt}";}
  if ( "$form{gbxbord}" ne "$gbxbord" ) {  $VAR="gbxbord"; $VAL="$form{gbxbord}"; write_vars; write_default_tmpl; $gbxbord="$form{gbxbord}";}
  if ( "$form{gbxwidth}" ne "$gbxwidth" ) {  $VAR="gbxwidth"; $VAL="$form{gbxwidth}"; write_vars; write_default_tmpl; $gbxwidth="$form{gbxwidth}";}
  if ( "$form{gbxwidth}" ne "$gbxbdybrd" ) {  $VAR="gbxbdybrd"; $VAL="$form{gbxbdybrd}"; write_vars; write_default_tmpl; $gbxbdybrd="$form{gbxbdybrd}";}
  if ( "$form{gbxbg1}" ne "$gbxbg1" ) {  $VAR="gbxbg1"; $VAL="$form{gbxbg1}"; write_vars; write_default_tmpl; $gbxbg1="$form{bxbg1}";}
  if ( "$form{gbxbg2}" ne "$gbxbg2" ) {  $VAR="gbxbg2"; $VAL="$form{gbxbg2}"; write_vars; write_default_tmpl; $gbxbg2="$form{gbxbg2}";}
  if ( "$form{gbxtxt}" ne "$gbxtxt" ) {  $VAR="gbxtxt"; $VAL="$form{gbxtxt}"; write_vars; write_default_tmpl; $gbxtxt="$form{gbxtxt}";}
  if ( "$form{gbxlnk}" ne "$gbxlnk" ) {  $VAR="gbxlnk"; $VAL="$form{gbxlnk}"; write_vars; write_default_tmpl; $gbxlnk="$form{gbxlnk}";}
  if ( "$form{gbxhr}" ne "$gbxhr" ) {  $VAR="gbxhr"; $VAL="$form{gbxhr}"; write_vars; write_default_tmpl; $gbxhr="$form{gbxhr}";}
  #
  # Write KAVE TEMPLATE DEFAULT
  #
  @LST=();@NEWLST=();
  tie @LST, 'Tie::File', "$ETC/kave-templates.dat" or die "Cannot find KAVE Template file: $ETC/kave-templates.dat";
  foreach (@LST)
  {
    if ( /^%%%Template.NoID:Default\,/)
    {
      $NEWLINE="%%%Template.NoID:Default,$gbxframetxt,$gbxframebg,$gbxbord,$gbxwidth,$gbxbg1,$gbxbg2,$gbxbdybrd,$gbxhr,$gbxtxt,$gbxlnk\n";
      push@NEWLST, "$NEWLINE";
    }
    else { push@NEWLST, "$_";}
  }
  @LST=@NEWLST;
  untie(@LST);
    print qq~
	<META HTTP-EQUIV="Refresh" CONTENT="0;URL=$ITKASM?act=sysconfigs">
    ~;
    $META="1";
    exit;
  }
    if ( ${acctcreation} eq "yes" ) { $checkedy="checked"; $checkedn=""; }
    else { $checkedn="checked"; $checkedy=""; }
    print qq~
        $hr_line
	<table width=100% cellpadding=3 bgcolor=$hdrcolor>
        <td>
        <font $fsbl>
        <a href=$ITKASM?wp=SETTINGS-MAIN title="Go To Settings" style=\"color:$lnkcolor\">Settings</a>
        </font>
	</td></table>
        $hr_line

      <table border=0 width=100% bgcolor="$bgcolor1">
      <td valign=top align=center>
      <font $fsb><u><b>IT KASM Settings</b></u></font><p>
        <table border=0  bgcolor="$bgcolor1" cellpadding=3> 
          <tr>
	      <td align=right valign=top><font $fsn>Company Logo:</font></td>
	      <td>
		<table border=0><td>
		<img src=$IMAGES/$LOGOFILE height=55>
		<form method=post action=/exec/logo_upload.pl enctype="multipart/form-data">
		</td><td align=center valign=top>
		or <input type=file name="logofile"><p>
	          <input type=submit name="upload" value="Upload Logo">
	        </form>
		</td></table>
              </td></tr>
	  <form method="post" action="$ITKASM">
	      <input type="hidden" name="act" value="sysconfigs">
          <tr><td align=right><font $fsn>Logo Height:</font></td>
	      <td><input type=number name="logosz" value="${logosz}" style="width: 6em;" title="Pixel height of Logo image. Maintains ratio"></td></tr>
          <tr><td align=right><font $fsn>IT KASM Administrator Email:</font></td>
	      <td><input type=text size=45 name="itkasmadmin" value="${itkasmadmin}" title="IT KASM Administrator Email Address"></td></tr>
          <tr> 
	      <td align=right><font $fsn>Server Base URL:</font>
	      </td><td><input type=url size=40 name="HTTP" pattern="https?://.+"  value="${HTTP}" title="Enter Base URL of this site. Include http:// and should not end with a slash /"> </td></tr>
          <tr><td align=right><font $fsn>Company Name:</font></td>
	      <td><input type=text size=40 name="COMPANY_NAME" value="${COMPANY_NAME}" title="Enter Company Name"></td></tr>
          <tr><td align=right><font $fsn>Company Department:</font></td>
	      <td><input type=text size=40 name="COMPANY_DEPT" value="${COMPANY_DEPT}" title="Enter the Department IT KASM is for"></td></tr>
          <tr><td align=right><font $fsn>Normal Font Size:</font></td>
	      <td><input type=number name="fontnorm" value="${fontnorm}" style="width: 4em;" min=1 max=10 title="Enter standard font size for all text"></td></tr>
          <tr><td align=right><font $fsb>Large Font Size:</font></td>
	      <td><input type=number name="fontbig" value="${fontbig}" style="width: 4em;" min=1 max=10 title="Font setting for Menu Selectors. See Menu bar above."></td></tr>
          <tr><td align=right><font $fsh>Header Font Size:</font></td>
	      <td><input type=number name="fonthdr" value="${fonthdr}" style="width: 4em;" min=1 max=10 title="Header Fonts found inside a Kave. See Sample to the right."></td></tr>
          <tr><td align=right><font $fsn>IT KASM Owner:</font></td>
	      <td><input type=text size=15 name="itkasmowner" value="${itkasmowner}" title="Enter IT KASM Ownership">
	      <font $fsn>Group:</font> <input type=text size=15 name="itkasmgroup" value="${itkasmgroup}" title="Enter IT KASM Group">
<tr><td>&nbsp;</td></tr>
	  </td></tr>
	  <tr><td><b><u>Services</u></b></td></tr>
          <tr><td align=right><font $fsn>Company People-Search query:</font></td>
	      <td><input type=url size=45 name="peoplequery" value="${peoplequery}" title="URL of Company employee search query. %%%%% is will be replaced with name to search. There MUST be 5 percent signs."></td></tr>
          <tr><td align=right><font $fsn>Mail Program:</font></td>
	      <td><input type=text size=45 name="mail_prog" value="${mail_prog}" title="Leave blank if mail is not configured, otherwise define Mail Program used to send Email: (ie. /bin/mail or /usr/sbin/sendmail. Users also will not be able to create accounts if not defined.)"></td></tr>
          <tr><td align=right><font $fsn>Users Create Accounts:</font></td>
	  <td>
	    <input type=radio name="acctcreation" value="yes" $checkedy title="Provides a 'Create Account' link on the Login page for users to create their own accounts. Since Email Validation is required, Mail must be configured and 'Mail Program' entry defined"> <font $fsn>Yes</font>
	    <input type=radio name="acctcreation" value="no" $checkedn title="Removes the 'Create Account' link off the Login Page so users cannot create an account. Account Management will then be managed by IT KASM Administrator"> <font $fsn>No</font>
	  </td></tr>

        </td></table>
      <p><input type=submit  name=update value="Update">
      </td>
      
      <td valign=top align=center> 
      <font $fsb><u><b>Global Page Color Settings</b></u></font><p>
        <table border=0 bgcolor="$bgcolor1" cellpadding=3>
          <tr><td align=right><font $fsn>Select a Template: $form{gtmplt}</font></td>
	      <td>
              <select name='gtmplt' onchange='this.form.submit()' title="Start with a template to build off">
              <option value=\"\" ></option>
	     
    ~;
    # DISPLAY THE GLOBAL TEMPLATE PULLDOWN
    foreach (@CLRTMPLT)
    {
         ($gtitle) = split(/\,/, $_);
	 ($dd, $gtitle) =split(/:/, $gtitle);
         print "<option value=\"$gtitle\" >$gtitle</option>\n";
    }
    print "</select>";
    print qq~
	  </td></tr>
          <tr><td align=right><font $fsn>Header Background Color: </font></td>
	      <td><input type=color name=hdrcolor value=${hdrcolor} title="Header Background color for all pages"></td></tr>
          <tr><td align=right><font $fsn>Background Color 1: </font></td>
	      <td><input type=color name=bgcolor1 value=${bgcolor1} title="Body Background color for all pages"></td></tr>
          <tr><td align=right><font $fsn>Background Color 2: </font></td>
	      <td><input type=color name=bgcolor2 value=${bgcolor2} title="Secondary Highlighted background. Typically for Menus."></td></tr>
          <tr><td align=right><font $fsn>Text Color:</font></td>
	      <td><input type=color name="txtcolor" value="${txtcolor}" title="Color for all main text"></td></tr>
          <tr><td align=right><font $fsnl color=$lnkcolor>Link Color:</font></td>
	      <td><input type=color name="lnkcolor" value="${lnkcolor}" title="Color for all links outside of Kaves"></td></tr>
             <tr><td align=right><font $fserr color=$attcolor><b>Attention/Error Color</b>:</font></td>
	      <td> <input type=color name="attcolor" value="${attcolor}" title="Errors and Attention banner color"></td></tr>
             <tr><td align=right><font $fsn>Horizontal Line Color:</font></td>
	      <td> <input type=color name="hrclr" value="${hrclr}" title="Color of all horizontal rules outside of a Kave"></td></tr>
             <tr><td align=right><font $fsn>Horizontal Line size:</font></td>
	      <td> <input type=number name="hrsize" value="${hrsize}" style="width: 4em;" min=1 max=10 title="Size in thickness of all horizontal rules outside of Kaves"></td></tr>
      </table>
      <p><input type=submit  name=update value="Update">
      </td>
            <td valign=top align=center>
            <font $fsb><u><b>Default Kave Color Settings</b></u></font><p>
	        <table border=0 bgcolor="$bgcolor1" cellpadding=3>
	      
          <tr><td align=right><font $fsn>Select a Template $form{ktmplt}:</font></td>
	      <td>
              <select name='ktmplt' onchange='this.form.submit()' title="Start with a template to build off of">
              <option value=\"\" ></option>
	     
    ~;
    # DISPLAY THE KAVE TEMPLATE PULLDOWN
    foreach (@CLRTMPLT)
    {
         ($ktitle) = split(/\,/, $_);
	 ($dd, $ktitle) =split(/:/, $ktitle);
         if ( ! /:Default\,/ ) { print "<option value=\"$ktitle\" >$ktitle</option>\n"; }
    }
    print "</select>";
    print qq~
	  </td></tr>
             <tr><td align=right><font $fsn>Kave Frame Background:</font></td>
	      <td><input type=color name="gbxframebg" value="${gbxframebg}" title="Primary Color for default Kave Frames"></td></tr>
              <tr><td align=right><font $fsn>Kave Frame Text:</font></td>
	      <td><input type=color name="gbxframetxt" value="${gbxframetxt}" title="Default text color for Kave Frames"></td></tr>
             <tr><td align=right><font $fsn>Kave Frame Border size:</font></td>
	      <td><input type=number name="gbxbord" value="${gbxbord}" style="width: 4em;" min=0 max=10 title="Default Kave border size"></td></tr>
             <tr><td align=right><font $fsn>Inside Border size:</font></td>
	      <td><input type=number name="gbxbdybrd" value="${gbxbdybrd}" style="width: 4em;" min=0 max=10 title="Default inside border size"></td></tr>
             <tr><td align=right><font $fsn>Kave Frame Border width:</font></td>
	      <td> <input type=number name="gbxwidth" value="${gbxwidth}" style="width: 6em;" title="Default Kave width to start with"></td></tr>
             <tr><td align=right><font $fsn>Body Text:</font></td>
	      <td> <input type=color name="gbxtxt" value="${gbxtxt}" title="Body text color for default Kave"></td></tr>
             <tr><td align=right><font $fsn>List Background 1:</font></td>
	      <td> <input type=color name="gbxbg1" value="${gbxbg1}" title="Primary color for body default Kave"></td></tr>
             <tr><td align=right><font $fsn>List Background 2:</font></td>
	      <td> <input type=color name="gbxbg2" value="${gbxbg2}" title="Secondary color for body default Kave. Typically when display is staggered."></td></tr>
             <tr><td align=right><font $fsn>Link Color:</font></td>
	      <td> <input type=color name="gbxlnk" value="${gbxlnk}" title="Default Link color inside a Kave"></td></tr>
             <tr><td align=right><font $fsn>Horizontal Line:</font></td>
	      <td> <input type=color name="gbxhr" value="${gbxhr}" title="Default horizontal rule color"></td></tr>
      
        </table>
      <p><input type=submit  name=update value="Update">
      $hr_line
    ~;

 	$khtx=$gbxframetxt; $kfbg=$gbxframebg; $kbrd=$gbxbord;
	$kwdt=$gbxwidth; $kbkg1=$gbxbg1; $kbkg2=$gbxbg2;
	$kbdybrd=$gbxbdybrd; $khrclr=$gbxhr; 
	$ktxt=$gbxtxt; 
	$klnk=$gbxlnk; 
    kave_sample;
    print qq~
    </td>
    </table>
</font>
  ~;



}

sub display_settings
{
  $accessTYPE="Settings"; $accessID="$act $sact"; &determine_access;
  if ( "$ACCESSLEVEL" ne "admin" ) 
  { 
     $accessTYPE="Settings"; $accessID="$buffer"; 
     &access_denied;
  }
  $WEBFILE="$ETC/itkasm-header.dat"; display_webpage;
  if ( $form{sact} eq "users" ) { display_usermatrix;}
  elsif ( $form{act} eq "accpro") {access_profile; }
  elsif ( $form{act} eq "wrnacct") {write_newuser; }
  elsif ( $form{act} eq "modset") {modify_setting; }
  elsif ( $form{act} eq "catlog") {&cat_logs; }
  elsif ( $form{act} eq "catdoc") {&cat_docs; }
  elsif ( $form{act} eq "ctracker") {&create_tracker; }
  elsif ( $form{act} eq "clonetrk") {&clone_tracker; }
  elsif ( $form{act} eq "listtrk") {&list_trackers; }
  elsif ( $form{act} eq "modtrk") {&mod_tracker; }
  elsif ( $form{act} eq "cfree") {&create_freeform; }
  elsif ( $form{act} eq "listfree") {&list_freeform; }
  elsif ( $form{act} eq "ctask") {&create_task; }
  elsif ( $form{act} eq "listtsk") {&list_tasks; }
  elsif ( $form{act} eq "delpage") {&delete_page; }
  elsif ( $form{act} eq "delmine") {&delete_mine; }
  elsif ( $form{act} eq "delkave") {&delete_kave; }
  elsif ( $form{act} eq "ckave") {&create_kave; }
  elsif ( $form{act} eq "listkaves") {&list_kave; }
  elsif ( $form{act} eq "crlist") {&create_resource; }
  elsif ( $form{act} eq "listres") {&list_resource; }
  elsif ( $form{act} eq "crsearch") {&create_search; }
  elsif ( $form{act} eq "listsearch") {&list_search; }
  elsif ( $form{act} eq "ckpage") {&create_kpage; }
  elsif ( $form{act} eq "listpages") {&list_page; }
  elsif ( $form{act} eq "listkbase") {&list_kbase; }
  elsif ( $form{act} eq "ckbase") {&create_kbase; }
  elsif ( $form{act} eq "listoc") {&list_oncall; }
  elsif ( $form{act} eq "concall") {&create_oncall; }
  elsif ( $form{act} eq "groups") {&display_groups; }
  elsif ( $form{act} eq "sysconfigs") {&display_sysconfigs; }
  #else { display_usermatrix;}

}


1;


#
#
# 		    GNU GENERAL PUBLIC LICENSE
# 		       Version 2, June 1991
# 
#  Copyright (C) 1989, 1991 Free Software Foundation, Inc.
#                        59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#  Everyone is permitted to copy and distribute verbatim copies
#  of this license document, but changing it is not allowed.
# 
# 			    Preamble
# 
#   The licenses for most software are designed to take away your
# freedom to share and change it.  By contrast, the GNU General Public
# License is intended to guarantee your freedom to share and change free
# software--to make sure the software is free for all its users.  This
# General Public License applies to most of the Free Software
# Foundation's software and to any other program whose authors commit to
# using it.  (Some other Free Software Foundation software is covered by
# the GNU Library General Public License instead.)  You can apply it to
# your programs, too.
# 
#   When we speak of free software, we are referring to freedom, not
# price.  Our General Public Licenses are designed to make sure that you
# have the freedom to distribute copies of free software (and charge for
# this service if you wish), that you receive source code or can get it
# if you want it, that you can change the software or use pieces of it
# in new free programs; and that you know you can do these things.
# 
#   To protect your rights, we need to make restrictions that forbid
# anyone to deny you these rights or to ask you to surrender the rights.
# These restrictions translate to certain responsibilities for you if you
# distribute copies of the software, or if you modify it.
# 
#   For example, if you distribute copies of such a program, whether
# gratis or for a fee, you must give the recipients all the rights that
# you have.  You must make sure that they, too, receive or can get the
# source code.  And you must show them these terms so they know their
# rights.
# 
#   We protect your rights with two steps: (1) copyright the software, and
# (2) offer you this license which gives you legal permission to copy,
# distribute and/or modify the software.
# 
#   Also, for each author's protection and ours, we want to make certain
# that everyone understands that there is no warranty for this free
# software.  If the software is modified by someone else and passed on, we
# want its recipients to know that what they have is not the original, so
# that any problems introduced by others will not reflect on the original
# authors' reputations.
# 
#   Finally, any free program is threatened constantly by software
# patents.  We wish to avoid the danger that redistributors of a free
# program will individually obtain patent licenses, in effect making the
# program proprietary.  To prevent this, we have made it clear that any
# patent must be licensed for everyone's free use or not licensed at all.
# 
#   The precise terms and conditions for copying, distribution and
# modification follow.
# 
# 		    GNU GENERAL PUBLIC LICENSE
#    TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
# 
#   0. This License applies to any program or other work which contains
# a notice placed by the copyright holder saying it may be distributed
# under the terms of this General Public License.  The "Program", below,
# refers to any such program or work, and a "work based on the Program"
# means either the Program or any derivative work under copyright law:
# that is to say, a work containing the Program or a portion of it,
# either verbatim or with modifications and/or translated into another
# language.  (Hereinafter, translation is included without limitation in
# the term "modification".)  Each licensee is addressed as "you".
# 
# Activities other than copying, distribution and modification are not
# covered by this License; they are outside its scope.  The act of
# running the Program is not restricted, and the output from the Program
# is covered only if its contents constitute a work based on the
# Program (independent of having been made by running the Program).
# Whether that is true depends on what the Program does.
# 
#   1. You may copy and distribute verbatim copies of the Program's
# source code as you receive it, in any medium, provided that you
# conspicuously and appropriately publish on each copy an appropriate
# copyright notice and disclaimer of warranty; keep intact all the
# notices that refer to this License and to the absence of any warranty;
# and give any other recipients of the Program a copy of this License
# along with the Program.
# 
# You may charge a fee for the physical act of transferring a copy, and
# you may at your option offer warranty protection in exchange for a fee.
# 
#   2. You may modify your copy or copies of the Program or any portion
# of it, thus forming a work based on the Program, and copy and
# distribute such modifications or work under the terms of Section 1
# above, provided that you also meet all of these conditions:
# 
#     a) You must cause the modified files to carry prominent notices
#     stating that you changed the files and the date of any change.
# 
#     b) You must cause any work that you distribute or publish, that in
#     whole or in part contains or is derived from the Program or any
#     part thereof, to be licensed as a whole at no charge to all third
#     parties under the terms of this License.
# 
#     c) If the modified program normally reads commands interactively
#     when run, you must cause it, when started running for such
#     interactive use in the most ordinary way, to print or display an
#     announcement including an appropriate copyright notice and a
#     notice that there is no warranty (or else, saying that you provide
#     a warranty) and that users may redistribute the program under
#     these conditions, and telling the user how to view a copy of this
#     License.  (Exception: if the Program itself is interactive but
#     does not normally print such an announcement, your work based on
#     the Program is not required to print an announcement.)
# 
# These requirements apply to the modified work as a whole.  If
# identifiable sections of that work are not derived from the Program,
# and can be reasonably considered independent and separate works in
# themselves, then this License, and its terms, do not apply to those
# sections when you distribute them as separate works.  But when you
# distribute the same sections as part of a whole which is a work based
# on the Program, the distribution of the whole must be on the terms of
# this License, whose permissions for other licensees extend to the
# entire whole, and thus to each and every part regardless of who wrote it.
# 
# Thus, it is not the intent of this section to claim rights or contest
# your rights to work written entirely by you; rather, the intent is to
# exercise the right to control the distribution of derivative or
# collective works based on the Program.
# 
# In addition, mere aggregation of another work not based on the Program
# with the Program (or with a work based on the Program) on a volume of
# a storage or distribution medium does not bring the other work under
# the scope of this License.
# 
#   3. You may copy and distribute the Program (or a work based on it,
# under Section 2) in object code or executable form under the terms of
# Sections 1 and 2 above provided that you also do one of the following:
# 
#     a) Accompany it with the complete corresponding machine-readable
#     source code, which must be distributed under the terms of Sections
#     1 and 2 above on a medium customarily used for software interchange; or,
# 
#     b) Accompany it with a written offer, valid for at least three
#     years, to give any third party, for a charge no more than your
#     cost of physically performing source distribution, a complete
#     machine-readable copy of the corresponding source code, to be
#     distributed under the terms of Sections 1 and 2 above on a medium
#     customarily used for software interchange; or,
# 
#     c) Accompany it with the information you received as to the offer
#     to distribute corresponding source code.  (This alternative is
#     allowed only for noncommercial distribution and only if you
#     received the program in object code or executable form with such
#     an offer, in accord with Subsection b above.)
# 
# The source code for a work means the preferred form of the work for
# making modifications to it.  For an executable work, complete source
# code means all the source code for all modules it contains, plus any
# associated interface definition files, plus the scripts used to
# control compilation and installation of the executable.  However, as a
# special exception, the source code distributed need not include
# anything that is normally distributed (in either source or binary
# form) with the major components (compiler, kernel, and so on) of the
# operating system on which the executable runs, unless that component
# itself accompanies the executable.
# 
# If distribution of executable or object code is made by offering
# access to copy from a designated place, then offering equivalent
# access to copy the source code from the same place counts as
# distribution of the source code, even though third parties are not
# compelled to copy the source along with the object code.
# 
#   4. You may not copy, modify, sublicense, or distribute the Program
# except as expressly provided under this License.  Any attempt
# otherwise to copy, modify, sublicense or distribute the Program is
# void, and will automatically terminate your rights under this License.
# However, parties who have received copies, or rights, from you under
# this License will not have their licenses terminated so long as such
# parties remain in full compliance.
# 
#   5. You are not required to accept this License, since you have not
# signed it.  However, nothing else grants you permission to modify or
# distribute the Program or its derivative works.  These actions are
# prohibited by law if you do not accept this License.  Therefore, by
# modifying or distributing the Program (or any work based on the
# Program), you indicate your acceptance of this License to do so, and
# all its terms and conditions for copying, distributing or modifying
# the Program or works based on it.
# 
#   6. Each time you redistribute the Program (or any work based on the
# Program), the recipient automatically receives a license from the
# original licensor to copy, distribute or modify the Program subject to
# these terms and conditions.  You may not impose any further
# restrictions on the recipients' exercise of the rights granted herein.
# You are not responsible for enforcing compliance by third parties to
# this License.
# 
#   7. If, as a consequence of a court judgment or allegation of patent
# infringement or for any other reason (not limited to patent issues),
# conditions are imposed on you (whether by court order, agreement or
# otherwise) that contradict the conditions of this License, they do not
# excuse you from the conditions of this License.  If you cannot
# distribute so as to satisfy simultaneously your obligations under this
# License and any other pertinent obligations, then as a consequence you
# may not distribute the Program at all.  For example, if a patent
# license would not permit royalty-free redistribution of the Program by
# all those who receive copies directly or indirectly through you, then
# the only way you could satisfy both it and this License would be to
# refrain entirely from distribution of the Program.
# 
# If any portion of this section is held invalid or unenforceable under
# any particular circumstance, the balance of the section is intended to
# apply and the section as a whole is intended to apply in other
# circumstances.
# 
# It is not the purpose of this section to induce you to infringe any
# patents or other property right claims or to contest validity of any
# such claims; this section has the sole purpose of protecting the
# integrity of the free software distribution system, which is
# implemented by public license practices.  Many people have made
# generous contributions to the wide range of software distributed
# through that system in reliance on consistent application of that
# system; it is up to the author/donor to decide if he or she is willing
# to distribute software through any other system and a licensee cannot
# impose that choice.
# 
# This section is intended to make thoroughly clear what is believed to
# be a consequence of the rest of this License.
# 
#   8. If the distribution and/or use of the Program is restricted in
# certain countries either by patents or by copyrighted interfaces, the
# original copyright holder who places the Program under this License
# may add an explicit geographical distribution limitation excluding
# those countries, so that distribution is permitted only in or among
# countries not thus excluded.  In such case, this License incorporates
# the limitation as if written in the body of this License.
# 
#   9. The Free Software Foundation may publish revised and/or new versions
# of the General Public License from time to time.  Such new versions will
# be similar in spirit to the present version, but may differ in detail to
# address new problems or concerns.
# 
# Each version is given a distinguishing version number.  If the Program
# specifies a version number of this License which applies to it and "any
# later version", you have the option of following the terms and conditions
# either of that version or of any later version published by the Free
# Software Foundation.  If the Program does not specify a version number of
# this License, you may choose any version ever published by the Free Software
# Foundation.
# 
#   10. If you wish to incorporate parts of the Program into other free
# programs whose distribution conditions are different, write to the author
# to ask for permission.  For software which is copyrighted by the Free
# Software Foundation, write to the Free Software Foundation; we sometimes
# make exceptions for this.  Our decision will be guided by the two goals
# of preserving the free status of all derivatives of our free software and
# of promoting the sharing and reuse of software generally.
# 
# 			    NO WARRANTY
# 
#   11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
# FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
# OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
# PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
# OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
# TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
# PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
# REPAIR OR CORRECTION.
# 
#   12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
# WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
# REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
# INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
# OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
# TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
# YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
# PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGES.
# 
# 		     END OF TERMS AND CONDITIONS
# 
# 	    How to Apply These Terms to Your New Programs
# 
#   If you develop a new program, and you want it to be of the greatest
# possible use to the public, the best way to achieve this is to make it
# free software which everyone can redistribute and change under these terms.
# 
#   To do so, attach the following notices to the program.  It is safest
# to attach them to the start of each source file to most effectively
# convey the exclusion of warranty; and each file should have at least
# the "copyright" line and a pointer to where the full notice is found.
# 
#     <one line to give the program's name and a brief idea of what it does.>
#     Copyright (C) 19yy  <name of author>
# 
#     This program is free software; you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation; either version 2 of the License, or
#     (at your option) any later version.
# 
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
# 
#     You should have received a copy of the GNU General Public License
#     along with this program; if not, write to the Free Software
#     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# 
# 
# Also add information on how to contact you by electronic and paper mail.
# 
# If the program is interactive, make it output a short notice like this
# when it starts in an interactive mode:
# 
#     Gnomovision version 69, Copyright (C) 19yy name of author
#     Gnomovision comes with ABSOLUTELY NO WARRANTY; for details type `show w'.
#     This is free software, and you are welcome to redistribute it
#     under certain conditions; type `show c' for details.
# 
# The hypothetical commands `show w' and `show c' should show the appropriate
# parts of the General Public License.  Of course, the commands you use may
# be called something other than `show w' and `show c'; they could even be
# mouse-clicks or menu items--whatever suits your program.
# 
# You should also get your employer (if you work as a programmer) or your
# school, if any, to sign a "copyright disclaimer" for the program, if
# necessary.  Here is a sample; alter the names:
# 
#   Yoyodyne, Inc., hereby disclaims all copyright interest in the program
#   `Gnomovision' (which makes passes at compilers) written by James Hacker.
# 
#   <signature of Ty Coon>, 1 April 1989
#   Ty Coon, President of Vice
# 
# This General Public License does not permit incorporating your program into
# proprietary programs.  If your program is a subroutine library, you may
# consider it more useful to permit linking proprietary applications with the
# library.  If this is what you want to do, use the GNU Library General
# Public License instead of this License.
#
#
