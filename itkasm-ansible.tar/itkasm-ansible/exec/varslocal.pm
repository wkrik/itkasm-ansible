###############
###
### varslocal.pm - all the localvariables needed for branding IT KASM
###
###############
$HTTP="http://itkasm.mycompany.com/";
$COMPANY_NAME="Management Tool";
$COMPANY_DEPT="Throw IT in the KASM";

$LOGOFILE="ITKASM-logo.png";
$logosz="70";

###
###   COLORS - Global Default
###
$bgcolor1="#eeead6";
$bgcolor2="#fffff0";
$txtcolor="#000000";
$lnkcolor="#0000ee";
$attcolor="#a60000";
$hdrcolor="#e0cc9c";

###
### KAVE Defaults
###
$gbxframebg="#e0cc9c";
$gbxframetxt="#000000";
$gbxbord="0";
$gbxwidth="300";
$gbxbdybrd="0";
$gbxbg1="#eeead6";
$gbxbg2="#fffff0";
$gbxtxt="#000000";
$gbxlnk="#0000ee";
$gbxhr="#e0cc9c";

###
### MISC
###
$fontnorm="2";
$fontbig="4";
$fonthdr="3";
$hrclr="#e0cc9c";
$hrsize="1";
$peoplequery="http://peoplesoft.mycompany.com?query=%%%%%";
$mail_prog="/usr/bin/mailx";
$itkasmadmin="itkasm\@mycompany.com";
$acctcreation="no";
$itkasmowner="apache";
$itkasmgroup="apache";
$HIDELOGIN="";   # When set to 1 will hide the login on home page

###############
1;
